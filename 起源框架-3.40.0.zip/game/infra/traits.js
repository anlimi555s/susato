// ==================================================================
//  traits v1.0 -- 技能倍率系统
//  吸收自 DoL Plus AMCTraits (game/base-system/clamp.twee).
//  统一的技能上限倍率控制, 支持突破原生 1000 上限。
//
//  API:
//   SM.traits.init(state)
//     初始化 $AMCTraits 全部默认值 (28 个属性, 默认倍率 1.0).
//     应在 mod 的 variables-modUpdate 等效位置调用。
//
//   SM.traits.get(key) -> number
//     获取指定技能的当前倍率。若未设置返回 1.0。
//
//   SM.traits.set(key, value)
//     设置指定技能的倍率。value 应为正数 (0.5=减半, 1=标准, 2=翻倍)。
//     会自动 clamp 到 [0.1, 100] 防止极端值。
//
//   SM.traits.cap(key, baseValue) -> number
//     计算技能上限: baseValue * 当前倍率。直接用于 clamp。
//     例: SM.traits.cap('brawling', 1000) -> 1000 * AMCTraits.brawling
//
//   SM.traits.getAll() -> object
//     获取所有当前倍率。
//
//   SM.traits.halfGain(on) -> void
//     设置/取消技能获取减半模式。
//     on=true -> 所有技能获取速度减半。
//
//   SM.traits.isHalfGain() -> boolean
//     查询是否处于减半模式。
//
//   可用技能键 (28个):
//     beauty, physique, oralSkill, vaginalSkill, analSkill,
//     handSkill, feetSkill, bottomSkill, thighSkill, chestSkill,
//     penileSkill, milk, semen,
//     willpower, english, maths, science, history,
//     skulduggery, swimming, dancing, athletics, tending, housekeeping,
//     brawling, footwork, striking, kicking
//
//  依赖: 无
//  消费方: 起源框架全部 addon 模块, 隐都潜流, 内容 mod
// ==================================================================
(function () {
  'use strict';

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (SM.traits) return;

  // ================================================================
  //  默认值
  // ================================================================
  var DEFAULTS = {
    beauty: 1,
    physique: 1,
    oralSkill: 1,
    vaginalSkill: 1,
    analSkill: 1,
    handSkill: 1,
    feetSkill: 1,
    bottomSkill: 1,
    thighSkill: 1,
    chestSkill: 1,
    penileSkill: 1,
    milk: 1,
    semen: 1,
    willpower: 1,
    english: 1,
    maths: 1,
    science: 1,
    history: 1,
    skulduggery: 1,
    swimming: 1,
    dancing: 1,
    athletics: 1,
    tending: 1,
    housekeeping: 1,
    brawling: 1,
    footwork: 1,
    striking: 1,
    kicking: 1,
    halfGain: 0
  };

  var ALL_KEYS = Object.keys(DEFAULTS);

  // ================================================================
  //  从 state 获取 AMCTraits 对象 (懒初始化)
  // ================================================================
  function getTraits(state) {
    var V;
    try {
      if (state && state.variables) V = state.variables;
      else if (typeof V !== 'undefined') V = V;
      else return null;
    } catch (e) { return null; }
    if (!V.AMCTraits) V.AMCTraits = {};
    return V.AMCTraits;
  }

  // ================================================================
  //  API
  // ================================================================
  var traits = {
    init: function (state) {
      var t = getTraits(state);
      if (!t) return;
      for (var i = 0; i < ALL_KEYS.length; i++) {
        var k = ALL_KEYS[i];
        if (t[k] === undefined) t[k] = DEFAULTS[k];
      }
    },

    get: function (key) {
      var t;
      try { t = getTraits(); } catch (e) { return 1; }
      if (!t) return 1;
      var v = t[key];
      return (typeof v === 'number') ? v : 1;
    },

    set: function (key, value) {
      if (typeof value !== 'number' || value <= 0) return;
      var t;
      try { t = getTraits(); } catch (e) { return; }
      if (!t) return;
      t[key] = Math.max(0.1, Math.min(100, value));
    },

    cap: function (key, baseValue) {
      return Math.floor((baseValue || 0) * traits.get(key));
    },

    getAll: function () {
      var t;
      try { t = getTraits(); } catch (e) { return {}; }
      if (!t) return {};
      var out = {};
      for (var i = 0; i < ALL_KEYS.length; i++) {
        var k = ALL_KEYS[i];
        out[k] = (typeof t[k] === 'number') ? t[k] : DEFAULTS[k];
      }
      return out;
    },

    halfGain: function (on) {
      var t;
      try { t = getTraits(); } catch (e) { return; }
      if (!t) return;
      t.halfGain = on ? 1 : 0;
    },

    isHalfGain: function () {
      return traits.get('halfGain') === 1;
    }
  };

  SM.traits = traits;

  // ================================================================
  //  自动初始化 (storyready 时)
  // ================================================================
  if (SM.events) {
    SM.events.on(':storyready', function () {
      try {
        if (typeof State !== 'undefined' && State.variables) {
          traits.init(State);
        }
      } catch (e) {}
    });
  }
})();
