// ==================================================================
//  SusatoModel 渲染器核心 v1.1
//  统一入口：图层注入、图层修改、ZIndices 扩展、compile 钩子。
//  不需要 ReplacePatcher、不需要 maplebirch。
//
//  API:
//    SusatoModel.renderer.addLayers({name: {srcfn,showfn,zfn,animation}})
//    SusatoModel.renderer.extendZIndices({key: value})
//    SusatoModel.renderer.patchLayer(name, fn)
//    SusatoModel.renderer.patchLayers(filterFn, fn)
//    SusatoModel.renderer.onCompile(hook)
//    SusatoModel.ui.openPanel(widgetName, opts)
//    SusatoModel.ui.openOverlay(key, title, widgetName)
//    SusatoModel.ui.closePanel()
//    SusatoModel.fame.register({type, name, discount})
//    SusatoModel.onInit(fn)
//    SusatoModel.moduleOff(id)
//
//  依赖: 无外部依赖。ZIndices / Renderer.CanvasModels / CanvasModel (游戏全局)
//  消费方: 起源框架全部 addon 模块、内容包、隐都潜流、人模切换
//
//  CREDITS
//  画家K — 架构 & 核心代码 & 重构
//  Yisic, 画家K, Cicero, 小鼹鼠, Ki, 冰, 枯木枝修, Phantalis — 贴图 & 测试 & 反馈
// ==================================================================
//
//  发现，珍宝总是易逝，
//  欢愉与狂怒交织——我正注视着你。
//  今夜，请小心你的一举一动。
//  我想时机已到，我想鲜血已经凝固，
//  它仍在渴求更多。那我们还在等什么？
//
//  线缆与锁链（我只是厌倦了视而不见），
//  开始褪色消散（我只是厌倦了视而不见），
//  感觉像一场游戏（我只是厌倦了视而不见），
//  你必须入局（我只是厌倦了视而不见）。
//
//  熄灯。这才是真实的你吗？
//  无法直视你的双眼，你那扭曲的心智。
//  好暗，如此黑暗。我们就在此了结，就在此地，此刻。
//  请告诉我你带了家伙，
//  让我们把夜空点燃，再消逝于长夜。
//
//  那些曾经美好的日子已然远逝，
//  我试着看清这一切究竟为何，却永远无法得知。
//  尽管它已死去，我仍听见那召唤。
//
//  线缆与锁链，开始褪色消散，
//  感觉像一场游戏，你无法逃脱。
//
//  我终于发现：珍宝总是易逝。
//  欢愉早已被遗忘。如今的你，究竟是谁？
//
// ==================================================================
(function () {
  'use strict';

  window.SusatoModel = window.SusatoModel || {};
  var SM = window.SusatoModel;
  var SR = SM.renderer = SM.renderer || {};

  // ================================================================
  //  EventEmitter —— sticky 事件总线
  //  解决"外部 mod 脚本在 storyready 之后加载 -> 事件已过 -> 回调永不触发"的整类 bug。
  //  sticky 事件触发后缓存参数，新监听者（once/on）立即回放。
  //  初始化必须在 load-once 守卫之前：第二份 susato-core 副本会触发守卫退出，
  //  但 SM.events 必须留在那里让后续模块继续用。
  // ================================================================
  if (!SM._eventsInited) {
    SM._eventsInited = true;
    var _listeners = {};      // event -> [{fn, once}]
    var _stickyFlags = {};    // event -> bool
    var _stickyArgs = {};     // event -> args array

    SM.events = {
      // 标记事件为 sticky —— 必须在 trigger 之前调用
      sticky: function (event) {
        _stickyFlags[event] = true;
      },

      // 注册持久监听。若事件已 sticky，立即用缓存参数回放一次。
      on: function (event, callback) {
        if (typeof callback !== 'function') return;
        if (!_listeners[event]) _listeners[event] = [];
        _listeners[event].push({ fn: callback, once: false });
        if (_stickyFlags[event] && _stickyArgs[event]) {
          try { callback.apply(null, _stickyArgs[event]); } catch (e) {}
        }
      },

      // 一次性监听。触发后自动移除。若事件已 sticky，立即回放（不走绑定->等触发的路径）。
      once: function (event, callback) {
        if (typeof callback !== 'function') return;
        if (_stickyFlags[event] && _stickyArgs[event]) {
          // 已 sticky：直接回放，不绑定（righthand/model-addon 都靠这条路）
          try { callback.apply(null, _stickyArgs[event]); } catch (e) {}
          return;
        }
        if (!_listeners[event]) _listeners[event] = [];
        _listeners[event].push({ fn: callback, once: true });
      },

      // 移除监听
      off: function (event, callback) {
        var list = _listeners[event];
        if (!list) return;
        for (var i = list.length - 1; i >= 0; i--) {
          if (list[i].fn === callback) list.splice(i, 1);
        }
      },

      // 触发事件。若标记为 sticky，缓存参数供后续监听者回放。
      trigger: function (event) {
        var args = Array.prototype.slice.call(arguments, 1);
        if (_stickyFlags[event]) _stickyArgs[event] = args;
        var list = _listeners[event];
        if (!list) return;
        // 复制一份再遍历：once 回调会在执行中 splice 自己
        var copy = list.slice();
        for (var i = 0; i < copy.length; i++) {
          try { copy[i].fn.apply(null, args); } catch (e) {}
          if (copy[i].once) {
            var idx = list.indexOf(copy[i]);
            if (idx >= 0) list.splice(idx, 1);
          }
        }
      }
    };
  }

  // ================================================================
  //  load-once 守卫 —— susato-core 可能被多个子 mod 各打包一份而加载多次。
  //  只让第一份生效，后续加载直接退出。否则第二份会重置内部钩子/队列，
  //  而 compile 包装器（_susatoCompileHooked 守卫，只装一次）仍读第一份的
  //  钩子数组 → 第二份之后注册的 onCompile 钩子永不执行（时装叠穿失效的真因）。
  //  这道守卫是"稳定抽象层"的前提：被复用几次都保持单例、行为一致。
  // ================================================================
  if (SR._coreLoaded) {
    // 已有一份 core 抢先生效(残留的旧大包/旧管理器 zip)。旧核心带新模块跑风险不可控,
    // 大红警告提示清理 —— canLoadThisMod 拦不到排在自己之前的 mod, 只能靠人清。
    try {
      if (SR._coreVersion !== '3.0.0') {
        console.error('[susato-core] 检测到旧版核心已抢先加载(版本 ' + (SR._coreVersion || '未知(<3.0)') + '), 本副本(3.0.0)退让。请从 Mod Loader 移除旧的 起源框架-寿里美化包(<=2.8) 或 寿里美化拓展-起源管理器 包, 否则新功能可能异常。' +
          '\n[susato-core] Old core detected (v' + (SR._coreVersion || 'unknown(<3.0)') + '), this copy (3.0.0) yielding. Remove old packages from Mod Loader or new features may malfunction.');
        try { window.modSC2DataManager.getModLoadController().getLog().error('[susato-core] 旧版核心抢占单例, 请清理旧包'); } catch (e2) {}
      }
    } catch (e) {}
    return;
  }
  SR._coreLoaded = true;
  SR._coreVersion = '3.0.0';

  // ================================================================
  //  模块开关 —— 起源管理器写 localStorage 键 susato_modules_off
  //  (JSON 字符串数组, 如 ["decorations","model-addon"]), 各功能模块
  //  IIFE 顶部用 SusatoModel.moduleOff('<id>') 守卫, 刷新页面后生效。
  //  读一次缓存: 开关翻转本来就要求刷新, 不需要动态重读。
  // ================================================================
  var _modulesOff = (function () {
    try {
      var arr = JSON.parse(localStorage.getItem('susato_modules_off'));
      return Array.isArray(arr) ? arr : [];
    } catch (e) { return []; }
  })();

  window.SusatoModel.moduleOff = function (id) {
    return _modulesOff.indexOf(id) >= 0;
  };
  window.SusatoModel.moduleOffList = function () {
    return _modulesOff.slice();
  };

  // ================================================================
  //  共享初始化钩子 —— SM.onInit 现在是 SM.events.once(':storyready',...)
  //  的别名。自动获得 sticky 回放：storyready 之后注册也能立即执行。
  // ================================================================
  SM._initHooks = SM._initHooks || [];
  SM.onInit = function (fn) {
    if (typeof fn === 'function') SM.events.once(':storyready', fn);
  };
  // 兼容旧代码中直接 push 到 _initHooks 的用法（已弃用，保留迁移期）
  var _oldInitHooks = SM._initHooks;
  for (var _oi = 0; _oi < _oldInitHooks.length; _oi++) {
    SM.events.once(':storyready', _oldInitHooks[_oi]);
  }
  SM._initHooks = []; // 已迁移到 events，清掉旧的防止重复

  // ================================================================
  //  ZIndices 扩展 —— 运行时动态给 ZIndices 对象加属性
  //  const ZIndices = {...} 只阻止变量重赋值，不阻止属性修改，
  //  所以这里直接赋值即可，不需要 ReplacePatcher 文本替换。
  // ================================================================

  var _zQueue = [];

  function _applyZ(map) {
    var keys = Object.keys(map);
    for (var i = 0; i < keys.length; i++) {
      var k = keys[i];
      if (!(k in ZIndices)) ZIndices[k] = map[k];
    }
  }

  SR.extendZIndices = function (map) {
    if (typeof ZIndices !== 'undefined') {
      _applyZ(map);
    } else {
      _zQueue.push(map);
    }
  };

  // ================================================================
  //  addLayers —— 注入新图层 { name: {srcfn,showfn,zfn,animation} }
  //  在 :storyready 统一注入，自动去重
  // ================================================================

  var _layerQueue = [];

  function _injectLayers(layers) {
    var model;
    try { model = Renderer.CanvasModels && Renderer.CanvasModels.main; } catch (e) { return; }
    if (!model || !model.layers) return;

    var keys = Object.keys(layers);
    for (var i = 0; i < keys.length; i++) {
      var name = keys[i];
      if (model.layers[name]) continue;
      model.layers[name] = layers[name];
    }
  }

  SR.addLayers = function (layers) {
    if (_flushed) { _injectLayers(layers); } else { _layerQueue.push(layers); }
  };

  // ================================================================
  //  patchLayer / patchLayers —— 修改已有图层属性（不改名）
  //  patchLayer("rightarm", fn) 或 patchLayers(filterFn, fn)
  //  自动排队 + 去重（同名只 patch 一次）
  // ================================================================

  var _patchedNames = {};
  var _patchQueue = [];

  function _applyPatch(name, patchFn) {
    if (_patchedNames[name]) return; // 去重
    var model;
    try { model = Renderer.CanvasModels && Renderer.CanvasModels.main; } catch (e) { return; }
    if (!model || !model.layers || !model.layers[name]) return;
    patchFn(model.layers[name], name);
    _patchedNames[name] = true;
  }

  function _applyPatchAll(filterFn, patchFn) {
    var model;
    try { model = Renderer.CanvasModels && Renderer.CanvasModels.main; } catch (e) { return; }
    if (!model || !model.layers) return;

    var keys = Object.keys(model.layers);
    for (var i = 0; i < keys.length; i++) {
      var k = keys[i];
      if (_patchedNames[k]) continue;
      if (!filterFn(k, model.layers[k])) continue;
      patchFn(model.layers[k], k);
      _patchedNames[k] = true;
    }
  }

  // 修改单个命名图层
  SR.patchLayer = function (name, patchFn) {
    if (typeof patchFn !== 'function') return;
    if (_flushed) { _applyPatch(name, patchFn); } else { _patchQueue.push({ name: name, fn: patchFn }); }
  };

  // 按过滤函数批量修改（如匹配所有右臂相关图层）
  SR.patchLayers = function (filterFn, patchFn) {
    if (typeof patchFn !== 'function' || typeof filterFn !== 'function') return;
    if (_flushed) { _applyPatchAll(filterFn, patchFn); } else { _patchQueue.push({ filter: filterFn, fn: patchFn }); }
  };

  // ================================================================
  //  onCompile —— 注册 compile 钩子
  //  hook(layerSpecs, options, model)，返回修改后的 layerSpecs
  //  多个钩子按注册顺序执行。任一个返回 null/undefined 则保留原样。
  // ================================================================

  var _compileHooks = [];

  SR.onCompile = function (hook) {
    _compileHooks.push(hook);
  };

  function _setupCompileHook() {
    if (typeof CanvasModel === 'undefined') return;
    if (CanvasModel.prototype._susatoCompileHooked) return;

    var _originalCompile = CanvasModel.prototype.compile;

    CanvasModel.prototype.compile = function (options) {
      var specs = _originalCompile.call(this, options);

      for (var i = 0; i < _compileHooks.length; i++) {
        try {
          var result = _compileHooks[i](specs, options, this);
          if (result) specs = result;
        } catch (e) {}
      }

      return specs;
    };

    CanvasModel.prototype._susatoCompileHooked = true;
  }

  // 提早安装 compile 包装器 —— 和"能用的直接覆写"同时机：加载时就装，不等 :storyinit。
  // DoL 的 Renderer 可能在 :storyinit 之前/之时就捕获 compile，迟到的包装器不生效。
  // 包装器按引用读 _compileHooks，稍后（如 clothing-layering 加载时）注册的钩子也能被读到。
  (function _earlyCompileHook() {
    if (typeof CanvasModel !== 'undefined') { _setupCompileHook(); return; }
    var n = 0;
    var t = setInterval(function () {
      n++;
      if (typeof CanvasModel !== 'undefined') { _setupCompileHook(); clearInterval(t); return; }
      if (n > 200) clearInterval(t);
    }, 25);
  })();

  // 标记 :storyready 为 sticky：触发后新绑定的监听者立即回放
  SM.events.sticky(':storyready');

  // ================================================================
  //  统一注入时机：:storyready 一次性处理所有排队 + 挂载 compile 钩子
  //  （:storyinit 在 SugarCube/DoL 里并不存在，绝不能用作触发点）
  // ================================================================

  var _flushed = false;

  function _flush() {
    // ZIndices
    for (var i = 0; i < _zQueue.length; i++) { _applyZ(_zQueue[i]); }
    _zQueue = [];

    // 新增图层
    for (var i = 0; i < _layerQueue.length; i++) { _injectLayers(_layerQueue[i]); }
    _layerQueue = [];

    // 修改已有图层
    for (var i = 0; i < _patchQueue.length; i++) {
      var p = _patchQueue[i];
      if (p.name) { _applyPatch(p.name, p.fn); } else { _applyPatchAll(p.filter, p.fn); }
    }
    _patchQueue = [];

    // compile 钩子：在所有图层就绪后挂载
    _setupCompileHook();

    _flushed = true;

    // 切换渲染器为直接执行模式
    SR.addLayers = function (layers) { _injectLayers(layers); };
    SR.extendZIndices = function (map) { _applyZ(map); };
    SR.patchLayer = function (name, fn) { _applyPatch(name, fn); };
    SR.patchLayers = function (filter, fn) { _applyPatchAll(filter, fn); };

    // 触发 sticky 事件。ModuleSystem 通过 SM.events.once(':storyready')
    // 注册了 runAll 处理器，会按拓扑序执行全部注册模块（含旧 SM.onInit 回调）。
    // 此后任何 SM.onInit(fn) 检测到已 sticky，立即回放 fn。
    SM.events.trigger(':storyready');
  }

  // ================================================================
  //  UI：可复用面板框架（基于 SugarCube 原生 Dialog）
  //
  //  openPanel(widgetName, opts) 把一个 <<widget>> 渲染进游戏原生 Dialog：
  //  自带主题化标题栏 + 关闭键 + Esc/点遮罩关闭，外观跟随玩家主题，
  //  不依赖 maplebirch、不手搓样式。任何子 mod 都能直接复用。
  //    opts.title      标题栏文字（默认空）
  //    opts.className  附加到 dialog 的 CSS 类
  //    opts.width      仅在原生 Dialog 不可用、回退手搓面板时生效（默认 400px）
  //
  //  触发按钮由 boot.json 的 TweeReplacer 注入 StoryCaption 源码
  //  （Story = Object.freeze，运行时注不进去，只能改 passage 源码）：
  //    <<button ...>><<run SusatoModel.ui.openPanel('某widget')>><</button>>
  //  或注入 <div data-susato-panel="某widget">，由下方文档级委托接管。
  // ================================================================

  var SU = window.SusatoModel.ui = window.SusatoModel.ui || {};

  var PANEL_ID = 'susato-panel';      // 回退 off-canvas 面板的 DOM id
  var PANEL_CLASS = 'susato-panel';   // 打到原生 dialog 上的标记类，用于只关自己的面板

  function _dialogUsable() {
    return typeof Dialog !== 'undefined' && Dialog.setup && Dialog.wiki && Dialog.open;
  }

  SU.closePanel = function () {
    // 原生 dialog 只关带 susato-panel 标记类的那个，避免误关游戏其它弹窗。
    // SugarCube 把 setup 的 class 加在 #ui-dialog 或 #ui-dialog-body 上（版本而异），两处都查。
    try {
      if (_dialogUsable() && Dialog.close) {
        var open = (typeof Dialog.isOpen === 'function') ? Dialog.isOpen() : true;
        var dlg = document.getElementById('ui-dialog');
        var body = document.getElementById('ui-dialog-body');
        var mine = /\bsusato-panel\b/.test((dlg && dlg.className) || '') ||
                   /\bsusato-panel\b/.test((body && body.className) || '');
        if (open && mine) Dialog.close();
      }
    } catch (e) {}
    // 回退面板也清一下
    var panel = document.getElementById(PANEL_ID);
    if (panel && panel.parentNode) panel.parentNode.removeChild(panel);
  };

  // 打开一个渲染 <<widgetName>> 的面板。优先用原生 Dialog。
  SU.openPanel = function (widgetName, opts) {
    opts = opts || {};
    if (_dialogUsable()) {
      try {
        Dialog.setup(opts.title || '', (PANEL_CLASS + ' ' + (opts.className || '')).trim());
        Dialog.wiki('<<' + widgetName + '>>');
        Dialog.open();
        return;
      } catch (e) {}
    }
    _openFallback(widgetName, opts);   // 原生 Dialog 不可用时兜底
  };

  // 兜底：原生 Dialog 缺席时用一个跟随主题的 off-canvas 侧板
  function _openFallback(widgetName, opts) {
    var existing = document.getElementById(PANEL_ID);
    if (existing) {
      var same = existing.getAttribute('data-widget') === widgetName;
      if (existing.parentNode) existing.parentNode.removeChild(existing);
      if (same) return; // 再点同一触发 = 关闭
    }

    var panel = document.createElement('div');
    panel.id = PANEL_ID;
    panel.setAttribute('data-widget', widgetName);
    var width = opts.width || 400;
    panel.style.cssText =
      'position:fixed;top:0;right:0;width:' + width + 'px;max-width:100vw;height:100vh;' +
      'overflow-y:auto;background:var(--900);border-left:2px solid var(--700);z-index:9999;' +
      'padding:16px;color:var(--000);box-shadow:-4px 0 20px rgba(0,0,0,0.5);';

    var closeBtn = document.createElement('span');
    closeBtn.textContent = '关闭';
    closeBtn.style.cssText =
      'position:sticky;top:0;float:right;cursor:pointer;font-size:18px;color:var(--red);z-index:1;';
    closeBtn.onclick = SU.closePanel;
    panel.appendChild(closeBtn);

    var content = document.createElement('div');
    content.style.clear = 'both';
    panel.appendChild(content);

    document.body.appendChild(panel);

    // 渲染 widget 到目标元素：用 jQuery.wiki（wikifyEval 不接收目标元素）
    try {
      if (typeof $ !== 'undefined') { $(content).wiki('<<' + widgetName + '>>'); }
      else { new Wikifier(content, '<<' + widgetName + '>>'); }
    } catch (e) {}
  }

  // ================================================================
  //  openPopup — 多窗口可拖拽弹窗 (吸收自 Simple Framework CustomPopup)
  //  支持同时打开多个窗口，自动层叠偏移，可选拖拽。
  //  用法: SM.ui.openPopup('widgetName', { id, title, x, y, width, draggable })
  // ================================================================
  var _popupCount = 0;

  SU.openPopup = function (widgetName, opts) {
    opts = opts || {};
    var id = opts.id || ('susato-popup-' + (++_popupCount));
    var existing = document.getElementById(id);
    if (existing) {
      // 已存在：切换关闭
      if (existing.parentNode) existing.parentNode.removeChild(existing);
      return;
    }

    var win = document.createElement('div');
    win.id = id;
    win.className = 'susato-popup';
    win.style.cssText =
      'position:fixed;z-index:10000;min-width:280px;max-width:90vw;' +
      'background:var(--900,#1a1a1a);border:1px solid var(--700,#444);border-radius:8px;' +
      'box-shadow:0 4px 24px rgba(0,0,0,0.6);overflow:hidden;' +
      (opts.width ? 'width:' + opts.width + 'px;' : '');

    // 自动偏移：每个新窗口向右下偏移 20px
    var offset = (document.querySelectorAll('.susato-popup').length) * 20;
    win.style.top = (opts.y || 60 + offset) + 'px';
    win.style.left = (opts.x || (window.innerWidth - 440 - offset) / 2) + 'px';
    if (win.style.left < 0) win.style.left = (10 + offset) + 'px';

    // 标题栏
    var header = document.createElement('div');
    header.style.cssText =
      'display:flex;justify-content:space-between;align-items:center;' +
      'padding:8px 12px;background:var(--800,#222);border-bottom:1px solid var(--700,#444);' +
      'cursor:' + (opts.draggable !== false ? 'move' : 'default') + ';';
    header.innerHTML = '<span style="font-weight:bold;font-size:0.9rem;">' +
      (opts.title || '') + '</span>' +
      '<span style="cursor:pointer;color:var(--red,#e44);font-size:1.1rem;padding:0 4px;" ' +
      'onclick="var e=document.getElementById(\'' + id + '\');if(e&&e.parentNode)e.parentNode.removeChild(e);">x</span>';
    win.appendChild(header);

    // 内容区
    var content = document.createElement('div');
    content.style.cssText = 'padding:12px;max-height:70vh;overflow-y:auto;';
    win.appendChild(content);

    // 拖拽 (简易实现，不依赖 jQuery UI)
    if (opts.draggable !== false) {
      var dragging = false, startX, startY, origX, origY;
      header.addEventListener('mousedown', function (e) {
        dragging = true;
        startX = e.clientX; startY = e.clientY;
        origX = win.offsetLeft; origY = win.offsetTop;
        e.preventDefault();
      });
      document.addEventListener('mousemove', function (e) {
        if (!dragging) return;
        win.style.left = (origX + e.clientX - startX) + 'px';
        win.style.top = (origY + e.clientY - startY) + 'px';
      });
      document.addEventListener('mouseup', function () { dragging = false; });
    }

    document.body.appendChild(win);

    // 渲染 widget
    try {
      if (typeof $ !== 'undefined') { $(content).wiki('<<' + widgetName + '>>'); }
      else { new Wikifier(content, '<<' + widgetName + '>>'); }
    } catch (e) {}
  };

  SU.closePopup = function (id) {
    var el = document.getElementById(id);
    if (el && el.parentNode) el.parentNode.removeChild(el);
  };

  // 向后兼容：deco 面板
  SU.closeDecoPanel = SU.closePanel;
  SU.openDecoPanel = function () { SU.openOverlay('susatoDeco', '前景背景', 'decoPanel'); };

  // ================================================================
  //  原生覆盖层：与本体 属性/社交 完全同一套窗口 UI（#customOverlay）
  //  复刻本体 overlayReplace widget（switch 写死 key 进不去，只能自己驱动）：
  //  - 再点同一按钮 = 关闭（toggle）
  //  - 收起当前选中的侧栏 Tab（T.buttons）
  //  - 标题栏完整复刻本体 titleXxx widget 结构：
  //      <<setupTabs>> + #overlayTabs 标签按钮 + <<closeButtonMobile>> + <<closeButton>>
  //    （右上角关闭键与移动端关闭按钮都来自本体 widget，随玩家选项走）
  //  原生容器不可用时回退 Dialog 面板。
  //    SusatoModel.ui.openOverlay('susatoEcon', '账本', 'susatoEconPanel')
  // ================================================================
  SU.openOverlay = function (key, title, widgetName) {
    try {
      var overlay = document.getElementById('customOverlay');
      if (overlay && typeof $ !== 'undefined') {
        // 再点同一按钮 = 关闭
        if (!overlay.classList.contains('hidden') && overlay.getAttribute('data-overlay') === key) {
          if (typeof window.closeOverlay === 'function') window.closeOverlay();
          return;
        }
        var T = (typeof State !== 'undefined' && State.temporary) ? State.temporary : null;
        try {
          if (T && T.buttons && T.buttons.activeTab != -1) {
            T.buttons.toggle();
            if (typeof window.updateOptions === 'function') window.updateOptions();
          }
        } catch (e) {}
        if (T) T.currentOverlay = key;
        $('#customOverlay').removeClass('hidden').parent().removeClass('hidden');
        $('#customOverlay').attr('data-overlay', key);
        // 标题栏 = 本体 titleXxx widget 同款结构（单标签）
        var titleBar =
          '<<setupTabs>>' +
          '<div id="overlayTabs" class="tab">' +
            '<<closeButtonMobile>>' +
            '<<button "' + (title || '') + '">>' +
              '<<toggleTab>>' +
              '<<replace #customOverlayContent>><<' + widgetName + '>><</replace>>' +
            '<</button>>' +
          '</div>' +
          '<<closeButton>>';
        $('#customOverlayTitle').empty().wiki(titleBar);
        $('#customOverlayContent').empty().wiki('<<' + widgetName + '>>');
        return;
      }
    } catch (e) {}
    SU.openPanel(widgetName, { title: title || '' });
  };

  // 文档级事件委托：任何带 data-susato-panel="widget" 的元素点击/回车都触发对应面板。
  // 绑在 document 上，扛住 StoryCaption 每回合重渲染。兼容旧的 #susato-deco-btn。
  function _bindClicks() {
    if (typeof $ === 'undefined') return;
    if (SU._panelClickBound) return;
    SU._panelClickBound = true;

    function widgetOf(el) {
      var w = el.getAttribute && el.getAttribute('data-susato-panel');
      if (w) return w;
      if (el.id === 'susato-deco-btn') return 'decoPanel'; // 兼容旧触发
      return null;
    }
    $(document).on('click', '[data-susato-panel], #susato-deco-btn', function (ev) {
      var w = widgetOf(this); if (!w) return;
      ev.preventDefault(); SU.openPanel(w);
    });
    $(document).on('keydown', '[data-susato-panel], #susato-deco-btn', function (ev) {
      if (ev.key !== 'Enter' && ev.key !== ' ') return;
      var w = widgetOf(this); if (!w) return;
      ev.preventDefault(); SU.openPanel(w);
    });
  }

  if (typeof $ !== 'undefined') {
    _bindClicks();
    $(document).one(':storyready', _bindClicks);
  }

  // ================================================================
  //  自定义名望框架
  //  子 mod 可注册新的 fame 类型，自动获得：
  //  - $fame[type] 变量初始化
  //  - allure 折扣（若配置 discount 阶梯）
  //  - Social 页面 UI 渲染（框架通过 SusatoTextAddon 注入 <<customFame>>）
  //
  //  SusatoModel.fame.register({ type:'order', name:'秩序', discount:[...] })
  //
  //  内容 mod 场景中使用 <<fameorder amount>>（或自定义 <<fameXXX amount>>）增减声望值。
  // ================================================================

  var _fameTypes = {};

  window.SusatoModel.fame = {
    register: function (config) {
      if (!config || !config.type) return;
      if (_fameTypes[config.type]) return;
      _fameTypes[config.type] = config;
      // 如果 $fame 已存在，立即初始化
      try {
        if (typeof State !== 'undefined' && State.variables) {
          var V = State.variables;
          if (typeof V.fame !== 'object') V.fame = {};
          if (V.fame[config.type] === undefined) V.fame[config.type] = 0;
        }
      } catch (e) {}
    },

    // 获取已注册的所有 fame 类型名
    getTypes: function () {
      return Object.keys(_fameTypes);
    },

    // 获取已注册的完整配置（供渲染用）
    getAll: function () {
      return Object.keys(_fameTypes).map(function (k) { return _fameTypes[k]; });
    }
  };

  // 初始化所有已注册 fame 类型的 $fame[type] 变量
  function _initFameVars() {
    try {
      if (typeof State === 'undefined' || !State.variables) return;
      var V = State.variables;
      if (typeof V.fame !== 'object') V.fame = {};
      var types = Object.keys(_fameTypes);
      for (var i = 0; i < types.length; i++) {
        var t = types[i];
        if (V.fame[t] === undefined) V.fame[t] = 0;
      }
    } catch (e) {}
  }

  // allure 折扣：对配置了 discount 阶梯的 fame 类型生效
  // 取所有已注册 fame 类型的最大折扣（百分比）。每次 passageend 先还原旧折扣再应用
  // 新折扣，杜绝复利叠加（V.allure 跨 passage 持久存在，直接乘会指数衰减）。
  var _fameDiscountApplied = 0;

  function _applyAllureDiscount() {
    try {
      if (typeof State === 'undefined' || !State.variables) return;
      var V = State.variables;
      if (typeof V.allure === 'undefined') return;
      if (typeof V.fame !== 'object') return;

      // 计算当前应享折扣（取所有注册 fame 类型的最大 pct）
      var newPct = 0;
      var types = Object.keys(_fameTypes);
      for (var i = 0; i < types.length; i++) {
        var cfg = _fameTypes[types[i]];
        if (!cfg.discount) continue;
        var val = V.fame[types[i]] || 0;
        for (var d = cfg.discount.length - 1; d >= 0; d--) {
          if (val >= cfg.discount[d].threshold) { newPct = Math.max(newPct, cfg.discount[d].pct); break; }
        }
      }

      // 折扣率没变则跳过，避免每 passageend 做无意义的还原+重乘
      if (newPct === _fameDiscountApplied) return;

      // 还原旧折扣（除以旧折扣因子，恢复原始值）
      if (_fameDiscountApplied > 0) {
        V.allure = Math.floor(V.allure / (1 - _fameDiscountApplied / 100));
      }

      // 应用新折扣
      _fameDiscountApplied = newPct;
      if (newPct > 0) {
        V.allure = Math.floor(V.allure * (1 - newPct / 100));
      }
    } catch (e) {}
  }

  // 挂事件（只挂一次，jQuery 就绪后）
  function _setupFameHooks() {
    if (typeof $ === 'undefined') return;
    if (window.SusatoModel.fame._hooksSetup) return;
    window.SusatoModel.fame._hooksSetup = true;

    _initFameVars();

    $(document).on(':passageend', function () {
      _initFameVars();
      _applyAllureDiscount();
    });
  }

  // SugarCube 宏: <<customFame>> — 返回 HTML, 由 SusatoTextAddon 注入到 Social
  // 等级名用中文，阈值/颜色与本体 6 级制完全一致（正面声望绿端=高）。
  // 0-29 也显示最低有效等级（本体行为: 只要 fame 类型存在就不用 None）。
  function _defineFameMacro() {
    try {
      if (typeof DefineMacroS !== 'function') return;
      DefineMacroS('customFame', function () {
        var all = window.SusatoModel.fame.getAll();
        if (!all.length) return '';
        var h = '';
        for (var i = 0; i < all.length; i++) {
          var cfg = all[i], val = 0;
          try { if (typeof V !== 'undefined' && V.fame) val = V.fame[cfg.type] || 0; } catch (e) {}
          // 中文 mod：正面声望配色。0=最坏(red)，逐级上升到 1000+=最好(green)
          var grade = '默默无闻', color = 'red';
          if (val >= 1000)      { grade = '家喻户晓';  color = 'green'; }
          else if (val >= 600)  { grade = '声名远播';  color = 'teal'; }
          else if (val >= 400)  { grade = '引人瞩目';  color = 'lblue'; }
          else if (val >= 200)  { grade = '小有名气';  color = 'blue'; }
          else if (val >= 100)  { grade = '鲜为人知';  color = 'purple'; }
          else if (val >= 30)   { grade = '默默无闻';  color = 'pink'; }
          h += '<div class=\"relation-box\"><div class=\"relation-description\">' + cfg.name + '： <span class=\"' + color + '\">' + grade + '</span></div></div>';
        }
        return h;
      });
    } catch (e) {}
  }

  // 消费 onInit 管道：在 _flush 时初始化变量+挂 allure 折扣钩子+注册宏
  window.SusatoModel.onInit(function () {
    _setupFameHooks();
    _initFameVars();
    _defineFameMacro();
  });

  // ================================================================
  //  zonesManager —— 声明式注入区域
  //  定义一次 zone（passage+anchor+position），消费者一行 addTo 注入。
  //  对标 maplebirch 的 zonesManager.addTo()，但更轻——直接复用
  //  SusatoTextAddon 的 addOps 管道（afterPreload 前有效）或
  //  运行时 DOM 注入（afterPreload 之后走 passageend 委托）。
  // ================================================================

  var _zoneDefs = {};

  SM.text = {
    // 定义一个注入区域
    defineZone: function (name, passage, anchor, position) {
      if (!name || !passage) return;
      _zoneDefs[name] = { passage: passage, anchor: anchor || '', position: position || 'after' };
    },

    // 声明式注入：SM.text.addTo('sidebarButtons', '<<button "新功能">>...')
    addTo: function (zoneName, content) {
      var zone = _zoneDefs[zoneName];
      if (!zone) {
        try { console.warn('[susato-core] addTo: 未知区域 "' + zoneName + '"'); } catch (e) {}
        return false;
      }
      // 优先走 SusatoTextAddon 编译期注入（最可靠，在 SugarCube 加载前改 passage 源码）
      try {
        if (window.SusatoTextAddon && typeof window.SusatoTextAddon.addOps === 'function') {
          window.SusatoTextAddon.addOps('zones:' + zoneName, [{
            passage: zone.passage,
            anchor: zone.anchor,
            position: zone.position,
            content: content
          }]);
          return true;
        }
      } catch (e) {}
      // 兜底：运行时注入（SusatoTextAddon 不可用时）
      try {
        SM.text._runtimeAdd(zone.passage, zone.anchor, zone.position, content);
        return true;
      } catch (e) { return false; }
    },

    // 运行时兜底：直接在 passage 文本中做 indexOf+slice 替换
    // （不如 SusatoTextAddon 可靠——ModI18N 翻译后的文本可能不匹配——仅作最后手段）
    _runtimeAdd: function (passageName, anchor, position, content) {
      if (typeof $ === 'undefined' || typeof Story === 'undefined') return;
      try {
        var passage = Story.get(passageName);
        if (!passage) return;
        var text = passage.text;
        if (!text) return;
        var at = text.indexOf(anchor);
        if (at < 0) return;
        var newText;
        if (position === 'replace') newText = content;
        else if (position === 'after') newText = anchor + '\n' + content;
        else newText = content + '\n' + anchor;
        // 注意：passage.text 是 getter，修改 passage 源码只能走 ModLoader 层。
        // 这里只做 DOM 级注入（往当前已渲染的 passage 追加），仅供 storyready 后使用。
        // 对于已经渲染的 DOM，在 passageend 做一次性注入。
        _runtimeInjectOnce(passageName, content, position === 'after' ? 'afterend' : 'beforebegin', anchor);
      } catch (e) {}
    }
  };

  // runtime 注入的 DOM 辅助：查找 DOM 中匹配 anchor 文本的节点并在其旁插入
  var _runtimeInjected = {};
  function _runtimeInjectOnce(passageName, html, domPos, anchor) {
    var key = passageName + '|' + anchor.substring(0, 80);
    if (_runtimeInjected[key]) return;
    _runtimeInjected[key] = true;
    $(document).on(':passageend', function () {
      try {
        var el = document.getElementById('passage-' + passageName.toLowerCase().replace(/\s+/g, '-'));
        if (!el) return;
        var tmp = document.createElement('div');
        tmp.innerHTML = html;
        if (domPos === 'afterend') el.appendChild(tmp);
        else el.insertBefore(tmp, el.firstChild);
      } catch (e) {}
    });
  }

  // jQuery 已就绪则提前挂事件（_setupFameHooks 有守卫，不会重复）

  // ================================================================
  //  htmlTools Builder —— 链式 DOM 构建
  //  对标 maplebirch htmlTools.Builder。
  //  用法: SM.dom.build(function(b) { b.box('...', 'card'); b.text('标题', 'bold'); })
  // ================================================================

  SM.dom = {
    build: function (builderFn) {
      var frag = document.createDocumentFragment();
      function Builder() {
        this.frag = frag;
        this._current = null;
      }
      Builder.prototype.text = function (content, style) {
        var span = document.createElement('span');
        if (style) span.style.cssText = style;
        span.textContent = (content === undefined || content === null) ? '' : String(content);
        this.frag.appendChild(span);
        this._current = span;
        return this;
      };
      Builder.prototype.line = function (content, style) {
        this.text(content, style);
        this.frag.appendChild(document.createElement('br'));
        return this;
      };
      Builder.prototype.raw = function (node) {
        if (node instanceof Node) { this.frag.appendChild(node); this._current = node; }
        return this;
      };
      Builder.prototype.box = function (content, className, style) {
        var div = document.createElement('div');
        if (className) div.className = className;
        if (style) div.style.cssText = style;
        if (content instanceof Node) div.appendChild(content);
        else if (content !== undefined) div.textContent = String(content);
        this.frag.appendChild(div);
        this._current = div;
        return this;
      };
      Builder.prototype.wikify = function (wikiText) {
        var span = document.createElement('span');
        try {
          if (typeof Wikifier !== 'undefined') { new Wikifier(span, String(wikiText)); }
          else { span.textContent = String(wikiText); }
        } catch (e) { span.textContent = String(wikiText); }
        this.frag.appendChild(span);
        return this;
      };
      try { builderFn.call(null, new Builder()); } catch (e) {}
      return frag;
    },

    // 轻量模板：html`<div class="${cls}">${text}</div>` 替代手写 createElement。
    // ES5 环境没有 tagged template literal，用函数调：SM.dom.tmpl('<div class="{{cls}}">{{text}}</div>', {cls:'x', text:'y'})
    tmpl: function (str, data) {
      var div = document.createElement('div');
      div.innerHTML = str.replace(/\{\{(\w+)\}\}/g, function (_, key) {
        var v = (data && key in data) ? data[key] : '';
        return String(v === undefined || v === null ? '' : v).replace(/</g, '&lt;').replace(/>/g, '&gt;');
      });
      // 如果只有一个子元素，返回它；否则包在 fragment 里
      if (div.childNodes.length === 1) return div.firstChild;
      var frag = document.createDocumentFragment();
      while (div.firstChild) frag.appendChild(div.firstChild);
      return frag;
    },
    // 快捷方法
    el: function (tag, className, text) {
      var e = document.createElement(tag || 'div');
      if (className) e.className = className;
      if (text !== undefined) e.textContent = String(text);
      return e;
    }
  };

  // ================================================================
  //  DynamicManager 统一入口 —— 对标 maplebirch DynamicManager
  //  SM.dynamic.time / SM.dynamic.state / SM.dynamic.weather
  //  别名：SM.time / SM.vars / SM.notify 保持不变（向后兼容）
  // ================================================================

  SM.dynamic = {
    get time() { return SM.time; },
    get vars() { return SM.vars; },
    get notify() { return SM.notify; },
    get notifyFlush() { return SM.notifyFlush; },
    get location() { return SM.location; }
  };

  // jQuery 已就绪则提前挂事件（_setupFameHooks 有守卫，不会重复）
  if (typeof $ !== 'undefined') {
    _setupFameHooks();
  }

  if (typeof $ !== 'undefined') {
    $(document).one(':storyready', _flush);
  } else {
    var _attempts = 0;
    var _t = setInterval(function () {
      _attempts++;
      if (typeof $ !== 'undefined') {
        clearInterval(_t);
        $(document).one(':storyready', _flush);
      } else if (_attempts > 200) { // 10s timeout
        clearInterval(_t);
      }
    }, 50);
  }

  // ================================================================
  //  SM.location.virtual — 虚拟地点 (v3.20+, 吸收自 SmartPhone PhoneTo/PhoneBack)
  //  允许 mod 注册虚拟地点，进入时保存真实 passage/location，
  //  退出时恢复。游戏将虚拟地点视为真实地点。
  //
  //  SM.location.virtual('bank', { enter: fn, leave: fn })
  //  SM.location.enter('bank')   // V.location = 'bank'
  //  SM.location.leave('bank')   // 恢复真实位置
  //  SM.location.active()        // 当前虚拟地点名, 无则 null
  // ================================================================
  var _virtLocations = {};  // name -> { enter, leave }
  var _virtStack = [];      // [{ name, passage, location, outside }]

  SM.location = SM.location || {};
  SM.location.virtual = function (name, opts) {
      if (!name || typeof name !== 'string') return;
      _virtLocations[name] = {
        enter: (opts && typeof opts.enter === 'function') ? opts.enter : null,
        leave: (opts && typeof opts.leave === 'function') ? opts.leave : null
      };
    };

  SM.location.enter = function (name) {
      var vloc = _virtLocations[name];
      if (!vloc) return false;
      var V = (typeof State !== 'undefined' && State.variables) ? State.variables : null;
      if (!V) return false;

      // 保存当前状态
      var ctx = {
        name: name,
        passage: V.passage,
        location: V.location,
        outside: V.outside
      };
      _virtStack.push(ctx);

      // 切换到虚拟地点
      V.location = name;
      if (vloc.enter) { try { vloc.enter(ctx); } catch (e) {} }
      return true;
    };

  SM.location.leave = function (name) {
      if (_virtStack.length === 0) return false;
      var V = (typeof State !== 'undefined' && State.variables) ? State.variables : null;
      if (!V) return false;

      // 找到栈中最近的匹配项并恢复
      var idx = -1;
      for (var i = _virtStack.length - 1; i >= 0; i--) {
        if (!name || _virtStack[i].name === name) { idx = i; break; }
      }
      if (idx < 0) return false;

      var ctx = _virtStack[idx];
      var vloc = _virtLocations[ctx.name];

      // 恢复真实位置
      if (ctx.passage !== undefined) V.passage = ctx.passage;
      if (ctx.location !== undefined) V.location = ctx.location;
      if (ctx.outside !== undefined) V.outside = ctx.outside;

      if (vloc && vloc.leave) { try { vloc.leave(ctx); } catch (e) {} }

      // 从栈中移除
      _virtStack.splice(idx, 1);
      return true;
    };

  SM.location.active = function () {
      return _virtStack.length > 0 ? _virtStack[_virtStack.length - 1].name : null;
    };

  // ================================================================
  //  SM.defer — 智能延迟执行 (v3.21+, 吸收自 DoL Plus Utils.defer)
  //  引擎空闲时立即执行，引擎忙时等待 :passageend。
  //  避免在 passage 渲染期间做 DOM 操作导致的竞态问题。
  //
  //  SM.defer(fn)              -- 智能延迟执行
  //  SM.defer(fn, 100)         -- 指定延迟 ms (引擎忙时等待 passageend 后)
  // ================================================================
  SM.defer = function (fn, ms) {
    if (typeof fn !== 'function') return;
    try {
      if (typeof Engine !== 'undefined' && Engine.isIdle && Engine.isIdle()) {
        if (ms) { setTimeout(fn, ms); } else { setTimeout(fn, 10); }
      } else {
        if (typeof $ !== 'undefined') {
          if (ms) {
            $(document).one(':passageend', function () { setTimeout(fn, ms); });
          } else {
            $(document).one(':passageend', fn);
          }
        } else {
          setTimeout(fn, ms || 50);
        }
      }
    } catch (e) { setTimeout(fn, ms || 10); }
  };

  // ================================================================
  //  SM.loadCrypt — 加密模组解密加载 (v3.18+)
  //  接收解密后的原始 zip 数据，通过 ModLoader 懒加载接口注入。
  //  配合 _encrypt-mod.js 加密工具使用。
  //
  //  参数: { name: "模组名", data: ArrayBuffer (解密后的 zip) }
  // ================================================================
  SM.loadCrypt = function (opts) {
    if (!opts || !opts.name || !opts.data) return false;
    try {
      var modUtils = window.modUtils || (window.modSC2DataManager && window.modSC2DataManager.getModUtils && window.modSC2DataManager.getModUtils());
      if (!modUtils) { console.warn('[susato-core] loadCrypt: modUtils 不可用'); return false; }

      var modLoader = modUtils.getModLoader && modUtils.getModLoader();
      if (!modLoader) { console.warn('[susato-core] loadCrypt: modLoader 不可用'); return false; }

      // 使用 ModLoader 的懒加载接口注入解密后的 mod zip
      if (typeof modLoader.loadModZip === 'function') {
        modLoader.loadModZip(opts.name, opts.data);
        try { console.log('[susato-core] loadCrypt: ' + opts.name + ' 已注入'); } catch(e) {}
        return true;
      }

      // 回退: 通过 addonPlugin 机制注册
      if (typeof modLoader.registerMod === 'function') {
        modLoader.registerMod(opts.name, opts.data);
        return true;
      }

      console.warn('[susato-core] loadCrypt: ModLoader 不支持 loadModZip 或 registerMod');
      return false;
    } catch (e) {
      console.warn('[susato-core] loadCrypt 失败: ' + (e.message || e));
      return false;
    }
  };
})();
