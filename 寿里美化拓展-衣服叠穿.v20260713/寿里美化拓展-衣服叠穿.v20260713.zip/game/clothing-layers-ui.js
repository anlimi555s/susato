// ==================================================================
// 寿里美化拓展 — 衣服叠穿 UI v2.0
// 衣柜开关按钮（DOM 注入）
// ==================================================================
(function () {
  'use strict';

  function renderToggle() {
    try {
      var existing = document.getElementById('susato-layering-toggle');
      if (existing) {
        existing.innerHTML = buildToggleHTML();
        bindToggleEvents(existing);
        return;
      }

      var anchor = document.getElementById('wardrobewear');
      if (!anchor) return;

      var div = document.createElement('div');
      div.id = 'susato-layering-toggle';
      div.style.cssText = 'margin:4px 0;padding:6px 10px;border:1px solid var(--700);display:inline-block;border-radius:4px;';
      div.innerHTML = buildToggleHTML();

      anchor.parentNode.insertBefore(div, anchor);
      bindToggleEvents(div);
    } catch (e) {}
  }

  function buildToggleHTML() {
    var enabled = (typeof V !== 'undefined') && V.susato_layering_enabled;
    if (enabled) {
      var total = countAllLayers();
      var html = '<span style="color:#4c4">叠穿：开</span> ' +
        '<a class="link-internal susato-layering-off" role="button">关闭叠穿</a>';
      if (total > 0) {
        html += ' &nbsp;<a class="link-internal susato-layering-stripall" role="button" style="color:#c44;">一键褪光(' + total + ')</a>';
      }
      return html;
    }
    return '<span style="color:#c44">叠穿：关</span> ' +
      '<a class="link-internal susato-layering-on" role="button">开启叠穿</a>';
  }

  function countAllLayers() {
    try {
      var n = 0;
      if (V.worn_layers) {
        Object.keys(V.worn_layers).forEach(function (s) {
          var arr = V.worn_layers[s];
          if (Array.isArray(arr)) n += arr.length;
        });
      }
      return n;
    } catch (e) { return 0; }
  }

  function bindToggleEvents(el) {
    var onLink = el.querySelector('.susato-layering-on');
    var offLink = el.querySelector('.susato-layering-off');
    var stripAll = el.querySelector('.susato-layering-stripall');

    if (onLink) {
      onLink.addEventListener('click', function (e) {
        e.preventDefault();
        V.susato_layering_enabled = true;
        updateToggle(el);
      });
    }
    if (offLink) {
      offLink.addEventListener('click', function (e) {
        e.preventDefault();
        var total = countAllLayers();
        if (total > 0) {
          if (!confirm('还有 ' + total + ' 件叠穿衣服未脱下。\n关闭叠穿功能会将它们全部送回衣柜。\n\n确定关闭？')) {
            updateToggle(el);
            return;
          }
        }
        if (typeof SusatoModel !== 'undefined' && SusatoModel.clothingLayers) {
          SusatoModel.clothingLayers.removeAll();
        }
        V.susato_layering_enabled = false;
        updateToggle(el);
      });
    }
    if (stripAll) {
      stripAll.addEventListener('click', function (e) {
        e.preventDefault();
        var total = countAllLayers();
        if (total > 0 && confirm('确定将所有 ' + total + ' 件叠穿衣服褪回衣柜？')) {
          if (typeof SusatoModel !== 'undefined' && SusatoModel.clothingLayers) {
            SusatoModel.clothingLayers.removeAll();
          }
          updateToggle(el);
        }
      });
    }
  }

  function updateToggle(el) {
    el.innerHTML = buildToggleHTML();
    bindToggleEvents(el);
  }

  // ========== 事件 ==========
  if (typeof $ !== 'undefined') {
    $(document).on(':passagedisplay', function (ev) {
      try {
        var title = ev.passage && ev.passage.title;
        if (title && isWardrobe(title)) {
          setTimeout(renderToggle, 100);
        }
      } catch (e) {}
    });
  }

  function isWardrobe(title) {
    return title === 'Wardrobe' || title === 'Changing Room' ||
           title === 'Eden Wardrobe' || title === 'Asylum Wardrobe' ||
           title === 'Farm Wardrobe' || title === 'Katherine House Wardrobe' ||
           title === 'Clothing Shop';
  }
})();
