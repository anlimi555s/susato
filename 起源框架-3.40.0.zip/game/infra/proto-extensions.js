// ==================================================================
//  proto-extensions v1.0 -- Object / Array 原型安全扩展
//  吸收自 DoL Plus (modules/02-array-extensions.js + modules/05-object-extensions.js).
//  所有扩展通过 Object.defineProperty 安装, configurable:true 允许后续移除。
//  只扩展缺失的方法, 不覆盖已有实现。
//
//  Array 扩展:
//   arr.select(index)           -- 安全索引 (越界 clamp 到 [0, length-1])
//   arr.except(...values)       -- 排除指定值返回新数组
//   arr.formatList(opts)        -- 格式化列表 ("A, B and C")
//   arr.isEqual(other)          -- 浅比较相等
//   arr.isEqualByProperty(other, prop) -- 按属性浅比较
//
//  Object 扩展:
//   obj.deepMerge(...sources, arrayBehaviour, filterFn)
//     -- 深度合并, arrayBehaviour: replace|merge|merge-deduplicate|strict-replace
//   obj.deepCopy()              -- 深拷贝
//   obj.find(callbackFn)        -- 嵌套对象递归查找
//   obj.clearProperties()       -- 递归清除非对象属性保留结构
//   obj.isEqual(other)          -- 深度相等比较
//
//  依赖: 无 (纯 JS)
//  消费方: 全部模块 (基础工具)
// ==================================================================
(function () {
  'use strict';

  // ================================================================
  //  Array 扩展
  // ================================================================

  if (typeof Array.prototype.select !== 'function') {
    Object.defineProperty(Array.prototype, 'select', {
      configurable: true,
      writable: true,
      value: function (index) {
        if (this == null) throw new TypeError('Array.prototype.select called on null or undefined');
        if (typeof index !== 'number') return this[0];
        var safe = Math.max(0, Math.min(this.length - 1, index));
        return this[safe];
      }
    });
  }

  if (typeof Array.prototype.except !== 'function') {
    Object.defineProperty(Array.prototype, 'except', {
      configurable: true,
      writable: true,
      value: function () {
        if (this == null) throw new TypeError('Array.prototype.except called on null or undefined');
        var needles = Array.prototype.concat.apply([], arguments);
        if (needles.length === 0) return this.slice();
        return this.filter(function (obj) {
          for (var i = 0; i < needles.length; i++) {
            if (obj === needles[i]) return false;
          }
          return true;
        });
      }
    });
  }

  if (typeof Array.prototype.formatList !== 'function') {
    Object.defineProperty(Array.prototype, 'formatList', {
      configurable: true,
      writable: true,
      value: function (options) {
        if (this == null) throw new TypeError('Array.prototype.formatList called on null or undefined');
        if (this.length === 0) return '';
        var opts = options || {};
        var conjunction = (opts.conjunction || 'and') + ' ';
        var useOxford = opts.useOxfordComma === true;
        var sep = opts.separator || ', ';
        if (this.length <= 1) return String(this[0]);
        if (this.length === 2) return this[0] + ' ' + conjunction + this[1];
        var ox = (useOxford ? sep : ' ') + conjunction;
        return this.slice(0, -1).join(sep) + ox + this[this.length - 1];
      }
    });
  }

  if (typeof Array.prototype.isEqual !== 'function') {
    Object.defineProperty(Array.prototype, 'isEqual', {
      configurable: true,
      writable: true,
      value: function (other) {
        if (this == null) throw new TypeError('Array.prototype.isEqual called on null or undefined');
        if (!Array.isArray(other)) return false;
        if (this.length !== other.length) return false;
        for (var i = 0; i < this.length; i++) {
          if (this[i] !== other[i]) return false;
        }
        return true;
      }
    });
  }

  if (typeof Array.prototype.isEqualByProperty !== 'function') {
    Object.defineProperty(Array.prototype, 'isEqualByProperty', {
      configurable: true,
      writable: true,
      value: function (other, property) {
        if (this == null) throw new TypeError('Array.prototype.isEqualByProperty called on null or undefined');
        if (!Array.isArray(other)) return false;
        if (this.length !== other.length) return false;
        for (var i = 0; i < this.length; i++) {
          if (this[i][property] !== other[i][property]) return false;
        }
        return true;
      }
    });
  }

  // ================================================================
  //  Object 扩展 -- deepMerge / deepCopy (来自 DoL Plus ObjectAssignDeep)
  // ================================================================

  var _deepMerge;
  (function () {
    function getTypeOf(input) {
      return Object.prototype.toString.call(input).slice(8, -1).toLowerCase();
    }

    function cloneValue(value) {
      switch (getTypeOf(value)) {
        case 'object': return cloneObject(value);
        case 'array': return value.map(cloneValue);
        case 'date': return new Date(value.getTime());
        case 'regexp': return new RegExp(value.source, value.flags);
        case 'map': return new Map(value);
        case 'set': return new Set(value);
        case 'function': return value.bind({});
        default: return value;
      }
    }

    function cloneObject(input) {
      return Object.keys(input).reduce(function (obj, key) {
        obj[key] = cloneValue(input[key]);
        return obj;
      }, {});
    }

    function mergeObjects(target, source, options, filterFn, depth) {
      return Object.keys(source).reduce(function (obj, key) {
        if (filterFn && !filterFn(key, source[key], depth)) return obj;

        var sourceValue = source[key];
        var targetValue = target[key];

        if (getTypeOf(sourceValue) === 'object' && getTypeOf(targetValue) === 'object') {
          obj[key] = mergeObjects(targetValue, sourceValue, options, filterFn, depth + 1);
        } else if (getTypeOf(sourceValue) === 'array' && getTypeOf(targetValue) === 'array') {
          obj[key] = mergeArrays(targetValue, sourceValue, options);
        } else {
          obj[key] = cloneValue(sourceValue);
        }
        return obj;
      }, Object.assign({}, target));
    }

    function mergeArrays(target, source, options) {
      switch (options.arrayBehaviour) {
        case 'merge-deduplicate':
          return Array.from(new Set(target.concat(source)));
        case 'merge':
          return target.concat(source);
        default:
          return source.slice();
      }
    }

    _deepMerge = function (target, objects, arrayBehaviour, filterFn, depth) {
      depth = depth || 1;
      objects.forEach(function (object) {
        if (arrayBehaviour === 'strict-replace' && depth === 1) {
          Object.keys(target).forEach(function (key) {
            if (!(key in object)) delete target[key];
          });
        }
        Object.keys(object).forEach(function (key) {
          if (filterFn && !filterFn(key, object[key], depth)) return;
          var valueType = getTypeOf(object[key]);
          var targetValue = target[key];
          if (valueType === 'object' && getTypeOf(targetValue) === 'object') {
            target[key] = mergeObjects(targetValue, object[key], { arrayBehaviour: arrayBehaviour }, filterFn, depth + 1);
          } else if (valueType === 'array' && getTypeOf(targetValue) === 'array') {
            target[key] = mergeArrays(targetValue, object[key], { arrayBehaviour: arrayBehaviour });
          } else {
            target[key] = cloneValue(object[key]);
          }
        });
      });
      return target;
    };
  })();

  if (typeof Object.prototype.deepMerge !== 'function') {
    Object.defineProperty(Object.prototype, 'deepMerge', {
      configurable: true,
      writable: true,
      value: function () {
        var args = Array.prototype.slice.call(arguments);
        var lastArg = args[args.length - 1];
        var arrayBehaviour = typeof lastArg === 'string' ? args.pop() : 'replace';
        var filterFn = typeof args[args.length - 1] === 'function' ? args.pop() : null;
        return _deepMerge(this, args, arrayBehaviour, filterFn);
      }
    });
  }

  if (typeof Object.prototype.deepCopy !== 'function') {
    Object.defineProperty(Object.prototype, 'deepCopy', {
      configurable: true,
      writable: true,
      value: function () {
        return _deepMerge({}, [this], 'replace', null);
      }
    });
  }

  // ---- find (嵌套递归查找) ----

  if (typeof Object.prototype.find !== 'function') {
    Object.defineProperty(Object.prototype, 'find', {
      configurable: true,
      writable: true,
      value: function (callbackFn) {
        var search = function (obj) {
          var keys = Object.keys(obj);
          for (var i = 0; i < keys.length; i++) {
            var key = keys[i];
            var value = obj[key];
            if (callbackFn(key, value)) return value;
            if (typeof value === 'object' && value !== null) {
              var result = search(value);
              if (result) return result;
            }
          }
        };
        return search(this);
      }
    });
  }

  // ---- clearProperties (递归清除非对象属性保留结构) ----

  if (typeof Object.prototype.clearProperties !== 'function') {
    Object.defineProperty(Object.prototype, 'clearProperties', {
      configurable: true,
      writable: true,
      value: function () {
        var clear = function (obj) {
          var keys = Object.keys(obj);
          for (var i = 0; i < keys.length; i++) {
            var key = keys[i];
            if (typeof obj[key] === 'object' && obj[key] !== null) {
              clear(obj[key]);
            } else if (typeof obj[key] !== 'object') {
              delete obj[key];
            }
          }
        };
        clear(this);
      }
    });
  }

  // ---- isEqual (深度相等) ----

  if (typeof Object.prototype.isEqual !== 'function') {
    Object.defineProperty(Object.prototype, 'isEqual', {
      configurable: true,
      writable: true,
      value: function (b) {
        var a = this;
        if (a === b) return true;

        if (a && b && typeof a === 'object' && typeof b === 'object') {
          if (a.constructor !== b.constructor) return false;

          // Array
          if (Array.isArray(a)) {
            if (a.length !== b.length) return false;
            for (var i = a.length - 1; i >= 0; i--) {
              if (!a[i].isEqual(b[i])) return false;
            }
            return true;
          }

          // Map
          if (a instanceof Map && b instanceof Map) {
            if (a.size !== b.size) return false;
            var entriesA = a.entries();
            var entryA = entriesA.next();
            while (!entryA.done) {
              if (!b.has(entryA.value[0])) return false;
              entryA = entriesA.next();
            }
            entriesA = a.entries();
            entryA = entriesA.next();
            while (!entryA.done) {
              if (!entryA.value[1].isEqual(b.get(entryA.value[0]))) return false;
              entryA = entriesA.next();
            }
            return true;
          }

          // Set
          if (a instanceof Set && b instanceof Set) {
            if (a.size !== b.size) return false;
            var valsA = a.values();
            var valA = valsA.next();
            while (!valA.done) {
              if (!b.has(valA.value)) return false;
              valA = valsA.next();
            }
            return true;
          }

          // ArrayBuffer
          if (ArrayBuffer.isView(a) && ArrayBuffer.isView(b)) {
            if (a.length !== b.length) return false;
            for (var j = a.length - 1; j >= 0; j--) {
              if (a[j] !== b[j]) return false;
            }
            return true;
          }

          if (a.constructor === RegExp) return a.source === b.source && a.flags === b.flags;

          // Plain Object
          var keysA = Object.keys(a);
          if (keysA.length !== Object.keys(b).length) return false;
          for (var k = keysA.length - 1; k >= 0; k--) {
            if (!Object.prototype.hasOwnProperty.call(b, keysA[k])) return false;
          }
          for (var l = keysA.length - 1; l >= 0; l--) {
            var key = keysA[l];
            var va = a[key];
            var vb = b[key];
            if (va === vb) continue;
            if (va === null || vb === null) return false;
            if (typeof va === 'object' && typeof vb === 'object') {
              if (!va.isEqual(vb)) return false;
            } else if (va !== vb) {
              return false;
            }
          }
          return true;
        }
        // NaN === NaN
        return Number.isNaN(a) && Number.isNaN(b);
      }
    });
  }
})();
