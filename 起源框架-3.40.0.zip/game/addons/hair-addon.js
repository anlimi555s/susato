// ==================================================================
//  hair-addon v1.0 — 发型运行时注册框架
//  与 clothing-addon 同构设计。
//
//  API:
//    SusatoModel.hair.add(section, {variable, name_cap, type, shop})
//    section = fringe | sides
//
//  依赖: susato-core.js (SusatoModel.onInit)
//  消费方: clothing-data.js (飞仙发型)
// ==================================================================
(function () {
  'use strict';

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (SM.hair) return; // load-once 守卫

  var _queue = [];   // {section, spec}
  var _flushed = false;

  function _normalize(section, spec) {
    var item = {
      name: spec.name || spec.variable,
      name_cap: spec.name_cap || spec.variable,
      variable: spec.variable,
      type: Array.isArray(spec.type) ? spec.type : ['short'],
      shop: Array.isArray(spec.shop) ? spec.shop : ['mirrorhair'],
    };
    for (var k in spec) if (Object.prototype.hasOwnProperty.call(spec, k) && !(k in item)) item[k] = spec[k];
    return item;
  }

  function _inject(section, spec) {
    try {
      if (typeof setup === 'undefined' || !setup.hairstyles) return false;
      if (!Array.isArray(setup.hairstyles[section])) setup.hairstyles[section] = [];
      var arr = setup.hairstyles[section];
      for (var i = 0; i < arr.length; i++) {
        if (arr[i] && arr[i].variable === spec.variable) return false; // 去重
      }
      arr.push(_normalize(section, spec));
      return true;
    } catch (e) { return false; }
  }

  // 本体 widget 汇总的全部发型 type 集合, 注入新类型后需要重算
  function _recomputeTraits() {
    try {
      if (typeof setup === 'undefined' || !setup.hairstyles) return;
      var all = [];
      for (var k in setup.hairstyles) {
        if (!Array.isArray(setup.hairstyles[k])) continue;
        for (var i = 0; i < setup.hairstyles[k].length; i++) {
          var t = setup.hairstyles[k][i] && setup.hairstyles[k][i].type;
          if (Array.isArray(t)) all = all.concat(t);
        }
      }
      var seen = {};
      setup.hairTraits = all.filter(function (x) { if (seen[x]) return false; seen[x] = 1; return true; });
    } catch (e) {}
  }

  SM.hair = {
    add: function (section, spec) {
      if ((section !== 'fringe' && section !== 'sides') || !spec || !spec.variable) return false;
      if (_flushed) { var ok = _inject(section, spec); if (ok) _recomputeTraits(); return ok; }
      _queue.push({ section: section, spec: spec });
      return true;
    },
  };

  function _flush() {
    var changed = false;
    for (var i = 0; i < _queue.length; i++) {
      if (_inject(_queue[i].section, _queue[i].spec)) changed = true;
    }
    _queue.length = 0;
    _flushed = true;
    if (changed) _recomputeTraits();
  }

  // ---- 发色注册 (吸收自 CustomHair) ----
  // 向 setup.colours.hair 和 setup.colours.hair_map 注册自定义发色。
  // 和发型注册(add)一样支持队列→flush 模式。
  var _colorQueue = [];

  function _injectColor(spec) {
    try {
      if (typeof setup === 'undefined' || !setup.colours || !setup.colours.hair) return false;
      if (!Array.isArray(setup.colours.hair)) return false;

      var item = {
        variable: spec.variable,
        name: spec.name || spec.variable,
        name_cap: spec.name_cap || spec.name || spec.variable,
        csstext: spec.csstext || (spec.variable + 'hair'),
        natural: spec.natural !== undefined ? spec.natural : false,
        dye: spec.dye !== undefined ? spec.dye : true,
        canvasfilter: {
          blend: spec.blend || '#FFFFFF',
          blendMode: spec.blendMode || 'hard-light'
        }
      };
      if (spec.brightness) item.canvasfilter.brightness = spec.brightness;

      // 去重
      for (var i = 0; i < setup.colours.hair.length; i++) {
        if (setup.colours.hair[i] && setup.colours.hair[i].variable === item.variable) return false;
      }

      setup.colours.hair.push(item);

      // 同步 hair_map
      if (setup.colours.hair_map) {
        setup.colours.hair_map[item.variable] = {
          variable: item.variable,
          name: item.name,
          name_cap: item.name_cap,
          csstext: item.csstext,
          natural: item.natural,
          dye: item.dye,
          canvasfilter: {
            blend: item.canvasfilter.blend,
            blendMode: item.canvasfilter.blendMode
          }
        };
        if (spec.brightness) setup.colours.hair_map[item.variable].canvasfilter.brightness = spec.brightness;
      }

      return true;
    } catch (e) { return false; }
  }

  SM.hair.addColor = function (spec) {
    if (!spec || !spec.variable) return false;
    if (_flushed) return _injectColor(spec);
    _colorQueue.push(spec);
    return true;
  };

  var _origFlush = _flush;
  _flush = function () {
    _origFlush();
    var changed = false;
    for (var i = 0; i < _colorQueue.length; i++) {
      if (_injectColor(_colorQueue[i])) changed = true;
    }
    _colorQueue.length = 0;
  };

  SM._initHooks = SM._initHooks || [];
  SM._initHooks.push(_flush);
})();
