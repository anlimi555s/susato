// ==================================================================
//  migration v2.1 -- 存档版本迁移系统
//  吸收 DoL Plus Versions 系统(register/stepper/auto-trigger/logging) +
//  Realistic Childbirth 的版本迁移链模式(guard/patches/eject).
//
//  API:
//   SM.migration.register(versionId, fn)
//     ...(不变)...
//   SM.migration.stepper(versionId)
//     ...(不变)...
//   SM.migration.run(state)
//     ...(不变)...
//   SM.migration.latest()
//     ...(不变)...
//
//   SM.migration.guard(obj, versionKey, patches, opts)
//     [v2.1 新增] 通用嵌套对象版本迁移链。
//     吸收 Realistic Childbirth init.js 的 birthPatches 模式。
//     obj:         要迁移的对象(会被原地修改)
//     versionKey:  obj 中存储版本号的字段名 (如 'version')
//     patches:     { 0: fn, 1: fn, ... } 逐版本升级函数注册表
//                  每个 fn 接收 obj 并原地修改，返回 undefined
//     opts.currentVersion: 当前代码期望的版本号
//     opts.locationResolver: 可选，当对象损坏时推断安全回退位置
//     opts.fallbackLocation: 可选，硬编码兜底位置
//     返回 { action: 'ok' } | { action: 'eject', location, reason }
//     -- ok 表示对象通过安全校验可以继续使用
//     -- eject 表示对象已损坏/版本不兼容/迁移失败，应走安全退出路径
//
// 自动触发: (不变)
//
// 存档变量: V._schemaVersion (number)
//
// 依赖: susato-core.js (SM.events)
// ==================================================================

(function () {
  'use strict';

  var SM = window.SusatoModel;
  if (!SM || !SM.events) return;
  if (SM._migrationV2) return;
  SM._migrationV2 = true;

  var _registry = []; // [{versionId, fn}], index = versionId - 1
  var _latest = 0;
  var _log = [];      // [{stepId, name, ok, error}]

  function _recordLog(stepId, name, ok, error) {
    _log.push({ stepId: stepId, name: name || '', ok: ok, error: error || null });
  }

  // ================================================================
  //  Stepper -- 链式分步迁移构建器
  // ================================================================
  function Stepper(versionId) {
    this._versionId = versionId;
    this._steps = [];
    this._stepIdx = 0;
    this._ok = true;
  }

  Stepper.prototype.step = function (fn, opts) {
    opts = opts || {};
    this._steps.push({
      fn: fn,
      critical: opts.critical === true,
      name: opts.name || ('step-' + (this._stepIdx++))
    });
    return this;
  };

  Stepper.prototype._run = function () {
    var ok = true;
    for (var i = 0; i < this._steps.length; i++) {
      var s = this._steps[i];
      var stepOk = true;
      var err = null;
      try {
        var r = s.fn();
        if (r === false) { stepOk = false; err = 'fn returned false'; }
      } catch (e) {
        stepOk = false;
        err = e.message || String(e);
      }
      _recordLog('v' + this._versionId + '-' + s.name, s.name, stepOk, err);
      if (!stepOk) {
        ok = false;
        if (s.critical) break;
      }
    }
    return ok;
  };

  // guard() 辅助: 解析安全回退位置
  function _guardResolve(obj, resolver, fallback) {
    if (typeof resolver === 'function') {
      try { var loc = resolver(obj); if (loc) return loc; } catch (e) {}
    }
    if (obj && typeof obj.location === 'string' && obj.location) return obj.location;
    return fallback;
  }

  // ================================================================
  //  API
  // ================================================================
  SM.migration = {
    register: function (versionId, fn) {
      if (typeof versionId !== 'number' || versionId < 1) return false;
      if (typeof fn !== 'function') return false;
      if (versionId !== _registry.length + 1) {
        try { console.warn('[migration] 版本号跳跃: 期望 ' + (_registry.length + 1) + ' 收到 ' + versionId); } catch (e) {}
      }
      _registry[versionId - 1] = { versionId: versionId, fn: fn };
      _latest = Math.max(_latest, versionId);
      return true;
    },

    stepper: function (versionId) {
      return new Stepper(versionId);
    },

    latest: function () {
      return _latest;
    },

    run: function (state) {
      _log = [];
      if (!state || typeof state.variables !== 'object') {
        return { from: -1, to: -1, log: _log, ok: false, error: 'invalid state' };
      }

      var V = state.variables;
      var from = (typeof V._schemaVersion === 'number') ? V._schemaVersion : 0;
      var to = from;
      var allOk = true;

      for (var i = from; i < _latest; i++) {
        var entry = _registry[i];
        if (!entry) {
          _recordLog('v' + (i + 1), 'missing-registration', false, 'no migration registered for version ' + (i + 1));
          allOk = false;
          break;
        }
        var ok = true;
        var err = null;
        try {
          var result = entry.fn(state);
          if (result === false) { ok = false; err = 'migration returned false'; }
        } catch (e) {
          ok = false;
          err = e.message || String(e);
        }
        _recordLog('v' + entry.versionId, 'migrate-to-v' + entry.versionId, ok, err);
        if (ok) {
          to = entry.versionId;
          V._schemaVersion = to;
        } else {
          allOk = false;
          break;
        }
      }

      if (allOk && to < _latest) {
        to = _latest;
        V._schemaVersion = to;
      }

      if (_log.length === 0) {
        _recordLog('noop', 'already-at-v' + from, true, null);
      }

      return { from: from, to: to, log: _log.slice(), ok: allOk };
    },

    // v2.1 吸收 Realistic Childbirth init.js 版本迁移链模式
    // 通用嵌套对象安全校验 + 逐版本 patch + 安全弹出
    guard: function (obj, versionKey, patches, opts) {
      opts = opts || {};
      var currentVersion = opts.currentVersion || 1;
      var locationResolver = opts.locationResolver || null;
      var fallbackLocation = opts.fallbackLocation || 'default';

      if (!obj || typeof obj !== 'object') {
        return { action: 'eject', location: fallbackLocation, reason: 'obj is null or not an object' };
      }

      var objVersion = obj[versionKey];
      if (typeof objVersion !== 'number') {
        return { action: 'eject', location: fallbackLocation, reason: versionKey + ' is undefined or not a number' };
      }

      if (objVersion > currentVersion) {
        return { action: 'eject', location: _guardResolve(obj, locationResolver, fallbackLocation),
          reason: versionKey + ' ' + objVersion + ' > current ' + currentVersion + ' (newer save, cannot downgrade)' };
      }

      if (objVersion === currentVersion) {
        return { action: 'ok' };
      }

      var v = objVersion;
      while (v < currentVersion) {
        var patch = patches[v];
        if (typeof patch !== 'function') {
          return { action: 'eject', location: _guardResolve(obj, locationResolver, fallbackLocation),
            reason: 'no patch registered for version ' + v + ' -> ' + (v + 1) };
        }
        try {
          patch(obj);
        } catch (e) {
          return { action: 'eject', location: _guardResolve(obj, locationResolver, fallbackLocation),
            reason: 'patch ' + v + ' threw: ' + (e.message || String(e)) };
        }
        if (obj[versionKey] === v) obj[versionKey] = v + 1;
        if (obj[versionKey] !== v + 1) {
          return { action: 'eject', location: _guardResolve(obj, locationResolver, fallbackLocation),
            reason: 'patch ' + v + ' left ' + versionKey + ' at ' + obj[versionKey] + ' (expected ' + (v + 1) + ')' };
        }
        v = obj[versionKey];
      }

      return { action: 'ok' };
    }
  };

  // ================================================================
  //  自动触发: storyready 时检查并迁移
  // ================================================================
  SM.events.on(':storyready', function () {
    try {
      if (typeof State === 'undefined' || !State.variables) return;
      if (_latest === 0) return;

      var current = State.variables._schemaVersion;
      if (typeof current !== 'number') current = 0;
      if (current >= _latest) return;

      var result = SM.migration.run(State);
      if (!result.ok) {
        try { console.warn('[migration] ' + result.from + '->' + result.to + ' 失败, 查看 SM.migration._lastLog'); } catch (e) {}
        try { console.warn(JSON.stringify(result.log)); } catch (e) {}
      }
      SM.migration._lastLog = result.log;
    } catch (e) {
      try { console.error('[migration] auto-trigger error: ' + (e.message || e)); } catch (ignore) {}
    }
  });
})();
