// ==================================================================
// 寿里美化拓展-时装系统 v2.3
// CanvasModel.compile 覆写 + TweeReplacer 衣柜注入
//
// 我不想修复了，要是能看到大概率是被独立出来了。
// 那你该遭罪啦，哈哈哈哈O(∩_∩)O
// ==================================================================
(function () {
  'use strict';

  window.SusatoModel = window.SusatoModel || {};
  var SL = window.SusatoModel.clothingLayers = window.SusatoModel.clothingLayers || {};

  // 全部槽位（现在可以正确渲染所有子图层了）
  var ALL_SLOTS = [
    'upper', 'lower', 'under_upper', 'under_lower',
    'over_upper', 'over_lower', 'head', 'over_head',
    'face', 'neck', 'hands', 'handheld', 'legs', 'feet'
  ];

  // ========== 初始化 ==========
  function init() {
    if (typeof V === 'undefined') return;
    if (!V.worn_layers) V.worn_layers = {};
    ALL_SLOTS.forEach(function (s) {
      if (!V.worn_layers[s]) V.worn_layers[s] = [];
    });
  }

  // ========== API ==========
  SL.removeAll = function () {
    if (!V.worn_layers) return;
    Object.keys(V.worn_layers).forEach(function (slot) {
      var layers = V.worn_layers[slot];
      if (!layers || !layers.length) return;
      for (var i = layers.length - 1; i >= 0; i--) {
        if (layers[i] && layers[i].index > 0) {
          if (!V.wardrobe[slot]) V.wardrobe[slot] = [];
          V.wardrobe[slot].push(layers[i]);
        }
      }
      V.worn_layers[slot] = [];
    });
  };

  // 从 setup 克隆并回写颜色/图案
  function cloneWithColor(slot, original) {
    var id = original.index;
    try {
      if (typeof clothesIndex === 'function') {
        var cid = clothesIndex(slot, original);
        if (cid >= 0) id = cid;
      }
    } catch (e) {}
    var fresh = clone(setup.clothes[slot][id]);
    if (!fresh || fresh.name === 'naked') return null;
    if (original.colour) fresh.colour = original.colour;
    if (original.pattern) fresh.pattern = original.pattern;
    if (original.accessory_colour) fresh.accessory_colour = original.accessory_colour;
    return fresh;
  }

  // 直接按位置删——和参考 mod 一样：原物品推回衣柜，不克隆
  SL.removeAt = function (slot, pos) {
    try {
      var layers = V.worn_layers[slot];
      if (!layers || pos < 0 || pos >= layers.length) return null;
      var item = layers[pos];
      // 直接用 V.wardrobe 而非 selectWardrobe()，和参考 mod 一致
      if (!V.wardrobe[slot]) V.wardrobe[slot] = [];
      V.wardrobe[slot].push(item);
      layers.splice(pos, 1);
      return item;
    } catch (e) { return null; }
  };

  // 我绝对没有忘记把衣服换给你们，是凯拉尔偷的，绝对是！！！
  SL.remove = function (slot, itemIndex) {
    try {
      var layers = V.worn_layers[slot];
      if (!layers || !layers.length) return null;
      var found = -1;
      for (var i = 0; i < layers.length; i++) {
        if (layers[i] && layers[i].index == itemIndex) { found = i; break; }
      }
      if (found === -1) return null;
      var original = layers[found];
      // 先克隆再 splice——克隆失败不动层栈
      var fresh = cloneWithColor(slot, original);
      if (!fresh) return null;
      var w = selectWardrobe();
      if (!w) return null;
      if (!w[slot]) w[slot] = [];
      w[slot].push(fresh);
      layers.splice(found, 1);
      return fresh;
    } catch (e) { return null; }
  };

  SL.togglePrimaryHidden = function (slot) {
    try {
      var item = V.worn[slot];
      if (!item || item.index === 0) return;
      item._hidden = !item._hidden;
    } catch (e) {}
  };

  SL.toggleHidden = function (slot, pos) {
    try {
      var layers = V.worn_layers[slot];
      if (!layers || pos < 0 || pos >= layers.length) return;
      layers[pos]._hidden = !layers[pos]._hidden;
    } catch (e) {}
  };

  // 套装存取：只存物品名，恢复时从衣柜匹配
  SL.getStackingOutfit = function () {
    var stacking = {};
    try {
      Object.keys(V.worn_layers || {}).forEach(function (slot) {
        var layers = V.worn_layers[slot];
        if (!layers || !layers.length) return;
        stacking[slot] = [];
        for (var i = 0; i < layers.length; i++) {
          if (layers[i] && layers[i].name) stacking[slot].push(layers[i].name);
        }
      });
    } catch (e) {}
    return stacking;
  };

  SL.restoreStackingFromOutfit = function (outfit) {
    try {
      if (!outfit || !outfit.stacking) return;
      SL.removeAll();
      var w = V.wardrobe;
      if (!w) return;
      Object.keys(outfit.stacking).forEach(function (slot) {
        var names = outfit.stacking[slot];
        if (!names || !names.length) return;
        if (!V.worn_layers[slot]) V.worn_layers[slot] = [];
        for (var i = 0; i < names.length; i++) {
          var name = names[i];
          var idx = -1;
          if (w[slot]) {
            for (var j = 0; j < w[slot].length; j++) {
              if (w[slot][j] && w[slot][j].name === name) { idx = j; break; }
            }
          }
          if (idx >= 0) {
            V.worn_layers[slot].push(clone(w[slot][idx]));
            w[slot].splice(idx, 1);
          }
        }
      });
    } catch (e) {}
  };

  SL.getCount = function (slot) {
    var layers = V.worn_layers && V.worn_layers[slot];
    return layers ? layers.length : 0;
  };

  function selectWardrobe() {
    try {
      var loc = V.wardrobe_location || 'wardrobe';
      if (V.wardrobes && V.wardrobes[loc]) return V.wardrobes[loc];
      return V.wardrobe || null;
    } catch (e) { return null; }
  }

  // ========== 深拷贝图层 ==========
  function deepCopyLayer(layer) {
    if (typeof jQuery !== 'undefined') return jQuery.extend(true, {}, layer);
    return JSON.parse(JSON.stringify(layer));
  }

  // ========== 核心：覆写 CanvasModel.compile ==========
  function setupCompileOverride() {
    if (typeof CanvasModel === 'undefined') return false;
    if (CanvasModel.prototype._layeringPatched) return true;

    var originalCompile = CanvasModel.prototype.compile;

    CanvasModel.prototype.compile = function (options) {
      var layerSpecs = originalCompile.call(this, options);

      if (options.lights) return layerSpecs;
      if (options.root === 'img/sex/') return layerSpecs;
      // 只处理主立绘，跳过战斗/NPC/光照等模型
      if (this.name && this.name !== 'main') return layerSpecs;
      if (!V || !V.worn_layers) return layerSpecs;
      if (!V.susato_layering_enabled) return layerSpecs;

      try {
        // 过滤主装备隐藏的槽位
        var visibleSpecs = layerSpecs;
        ALL_SLOTS.forEach(function (s) {
          if (V.worn[s] && V.worn[s]._hidden) {
            visibleSpecs = visibleSpecs.filter(function (l) {
              if (!l || !l.name) return true;
              return l.name !== s && l.name.indexOf(s + '_') !== 0;
            });
          }
        });

        // 建索引
        var specIndex = {};
        for (var i = 0; i < visibleSpecs.length; i++) {
          if (visibleSpecs[i] && visibleSpecs[i].name) {
            specIndex[visibleSpecs[i].name] = i;
          }
        }

        var result = visibleSpecs.slice();
        var slots = Object.keys(V.worn_layers);

        for (var si = 0; si < slots.length; si++) {
          var slot = slots[si];
          var items = V.worn_layers[slot];
          if (!Array.isArray(items) || items.length === 0) continue;

          // 收集该槽位的所有子图层名
          var subLayerNames = [];
          for (var k = 0; k < layerSpecs.length; k++) {
            var ls = layerSpecs[k];
            if (!ls || !ls.name) continue;
            var ln = ls.name;
            if (ln === slot || (ln.length > slot.length + 1 && ln.indexOf(slot + '_') === 0)) {
              subLayerNames.push(ln);
            }
          }
          if (subLayerNames.length === 0) continue;

        for (var ii = 0; ii < items.length; ii++) {
          var item = items[ii];
          if (item._hidden) continue;  // 玩家选择不渲染

          // 准备 wornEntry
          var wornEntry;
          try {
            wornEntry = getClothingOptionsItem(slot, item);
          } catch (e) {
            if (!item.setup || !item.setup.variable) {
              item.setup = (setup.clothes[slot] && setup.clothes[slot][item.index]) || {};
            }
            if (typeof item.integrity !== 'string') item.integrity = 'full';
            if (!item.colour) item.colour = 'white';
            var fallback = {};
            fallback[slot] = item;
            wornEntry = fallback;
          }
          if (!wornEntry || !wornEntry[slot]) continue;

          var originalWorn = options.worn[slot];
          var filterKey = 'worn_' + slot;
          var accFilterKey = filterKey + '_acc';
          var originalFilter = options.filters[filterKey];
          var originalAccFilter = options.filters[accFilterKey];

          options.worn[slot] = wornEntry[slot];

          // 主装备锁胸 → 层栈物品的 breasts 子图层应隐藏
          var primaryBreastOff = false;
          if (slot === 'upper' || slot === 'under_upper' || slot === 'over_upper') {
            var pw = V.worn[slot];
            if (pw && pw.setup && pw.setup.breast_img !== undefined) {
              var pbi = pw.setup.breast_img;
              if (pbi === 0) {
                primaryBreastOff = true;
              } else if (typeof pbi === 'object') {
                var allNull = true;
                var pbiVals = Object.values(pbi);
                for (var pv = 0; pv < pbiVals.length; pv++) {
                  if (pbiVals[pv] !== null) { allNull = false; break; }
                }
                if (allNull) primaryBreastOff = true;
              }
            }
          }

          // 生成颜色 filter（对主 filter 和 acc filter 各算一次，缓存复用）
          var colourFilter = null;
          var accColourFilter = null;
          if (typeof setClothingFilter === 'function') {
            setClothingFilter(options, slot, options.worn[slot], options.worn[slot].setup, '', 'colour_sidebar', 'colour');
            colourFilter = options.filters[filterKey];
            setClothingFilter(options, slot, options.worn[slot], options.worn[slot].setup, '_acc', 'accessory_colour_sidebar', 'accColour');
            accColourFilter = options.filters[accFilterKey];
          }

          // 遍历该槽位所有子图层
          for (var sl = 0; sl < subLayerNames.length; sl++) {
            var origName = subLayerNames[sl];

            // 主装备锁胸 → 跳过 breasts 相关子图层
            if (primaryBreastOff && origName.indexOf('breast') !== -1) continue;

            var specPos = specIndex[origName];
            if (specPos === undefined) continue;

            var templateLayer = layerSpecs[specPos];
            var baseLayer = this.layers[origName];
            if (!baseLayer) continue;

            var newLayer = deepCopyLayer(templateLayer);
            newLayer.name = origName + '_stack_' + (item.variable || ii);
            newLayer.z = (templateLayer.z || 0) + (ii + 1) * 0.01;

            // ★ 调用原图层 showfn 决定可见性，不复用模板的 show 值
            var shouldShow = true;
            if (typeof baseLayer.showfn === 'function') {
              try {
                shouldShow = baseLayer.showfn(options);
              } catch (e) { shouldShow = true; }
            }
            newLayer.show = !!shouldShow;

            // 不显示的图层只设 show=false，其余保持原样即可
            if (!newLayer.show) {
              // 至少保留 src 引用，防止引擎报缺图
              newLayer.src = templateLayer.src || '';
              result.push(newLayer);
              continue;
            }

            // filtersfn
            if (typeof baseLayer.filtersfn === 'function') {
              newLayer.filters = baseLayer.filtersfn(options);
            }
            // wornfn
            if (typeof baseLayer.wornfn === 'function') {
              newLayer.worn = baseLayer.wornfn(options);
            }
            // srcfn
            if (typeof baseLayer.srcfn === 'function') {
              newLayer.src = baseLayer.srcfn(options);
            }

            // 颜色烘焙
            var isAccLayer = origName.indexOf('_acc') !== -1;
            var cf = isAccLayer ? accColourFilter : colourFilter;
            if (cf && cf.blend && typeof Renderer !== 'undefined' && Renderer.mergeLayerData) {
              Renderer.mergeLayerData(newLayer, cf, true);
            }

            result.push(newLayer);
          }

          // 还原
          options.worn[slot] = originalWorn;
          options.filters[filterKey] = originalFilter;
          options.filters[accFilterKey] = originalAccFilter;
        }
      }

        return result;
      } catch (e) {
        // 任何异常都回退到原版渲染
        return layerSpecs;
      }
    };

    CanvasModel.prototype._layeringPatched = true;
    return true;
  }

  // ========== 启动 ==========
  if (typeof $ !== 'undefined') {
    $(document).one(':storyinit', init);
    $(document).one(':storyready', function () { setupCompileOverride(); });
    if (typeof CanvasModel !== 'undefined') setupCompileOverride();
  } else {
    init();
    setupCompileOverride();
  }
})();
