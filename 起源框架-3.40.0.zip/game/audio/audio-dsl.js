// ==================================================================
//  audio-dsl v1.0 -- DSL 条件解析引擎
//  吸收 Breeze of Lewdity 表达式解析系统:
//    tokenizeQuery 状态机分词器
//    evaluateString 表达式求值器
//    translateOperand 操作数解析
//    getProperty 游戏状态变量映射
//    evaluateOperation 比较运算
//
//  不包含: 音频播放/YouTube播放器/音频包管理
//  (分别由 audio-core.js / audio-youtube.js / audio-packs.js 提供)
//
//  API:
//    SM.audio.dsl.getProperty(token)      -- 获取游戏状态变量值
//    SM.audio.dsl.tokenize(str)           -- 将表达式分词为令牌数组
//    SM.audio.dsl.evaluate(str)           -- 求值表达式返回布尔值
//    SM.audio.dsl.evaluateCondition(str, ctx) -- 安全求值含错误处理
//    SM.audio.dsl.evaluateString(str)     -- 直接求值(无安全包装)
//
//  依赖: SM.audio (audio-core)
//  消费方: audio-packs.js / audio-youtube.js
// ==================================================================
(function () {
  'use strict';

  if (window.SusatoModel && window.SusatoModel.moduleOff && window.SusatoModel.moduleOff('audio')) return;

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (!SM.audio) return; // audio-core must load first
  if (SM.audio.dsl) return;

  SM.audio.dsl = {};

  // ==================================================================
  //  getProperty -- 游戏状态变量映射表
  //  将字符串属性名映射到游戏运行时状态值
  // ==================================================================
  function getProperty(token) {
    switch (token) {
      case 'pain':    return State.variables.pain;
      case 'arousal': return State.variables.arousal;
      case 'fatigue': return State.variables.fatigue;
      case 'stress':  return State.variables.stress;
      case 'trauma':  return State.variables.trauma;
      case 'control': return State.variables.control;
      case 'alcohol':     return State.variables.drunk;
      case 'drugs':       return State.variables.drugged;
      case 'hallucinogens': return State.variables.hallucinogen;
      case 'gender': return State.variables.player.gender;
      case 'combat':     return State.variables.combat;
      case 'consensual': return State.variables.consensual;
      case 'masturbating': return State.variables.masturbating;
      case 'orgasmStart':  return State.variables.orgasmdown === 3;
      case 'orgasming':    return State.variables.orgasmdown > 0;
      case 'orgasmRounds': return State.variables.orgasmdown;
      case 'passage':      return State.variables.passage;
      case 'lastPassage':  return State.variables.passagePrev;
      case 'location':     return State.variables.location;
      case 'lastLocation': return State.variables.lastLocation;
      case 'mapLocation': return State.variables.map.location;
      case 'inside':  return State.variables.outside <= 0;
      case 'outside': return State.variables.outside > 0;
      case 'forestDepth': return State.variables.forest / 5;
      case 'npcPresent':  return State.variables.npc;
      case 'rentMoney':   return State.variables.rentmoney / 100;
      case 'rentDaysLeft':  return State.variables.renttime;
      case 'orphanageHope': return State.variables.orphan_hope;
      case 'orphanageReb':  return State.variables.orphan_reb;
      case 'hunted':    return State.variables.foresthunt;
      case 'possessed': return State.variables.possessed;
      case 'underwater': return State.variables.underwater;
      case 'money': return State.variables.money / 100;
      case 'enemyCount':       return State.variables.enemynomax;
      case 'enemiesRemaining': return State.variables.enemyno;
      case 'enemyType':        return State.variables.enemytype;
      case 'combatAnim':       return document.querySelector('.combat-main') !== null;
      case 'combatPosition':
        return State.variables.position ? State.variables.position : 'none';
      case 'stalked': return State.variables.position === 'stalk';
      case 'voreStage':    return State.variables.vorestage;
      case 'stomachStage': return State.variables.vorestomach;
      case 'struggleCreature':
        return State.variables.struggle ? State.variables.struggle.creature : null;
      case 'weather':
        if (Weather.name.indexOf('Clouds') !== -1) return 'none';
        if (Weather.precipitation === 'rain' && !Weather.isOvercast) return 'none';
        if (Weather.precipitation === 'snow' && !Weather.isFreezing) return 'none';
        return Weather.precipitation;
      case 'weatherType': return Weather.name;
      case 'dayState': return Time.dayState;
      case 'season':   return Time.season;
      case 'clock': {
        var cd = new Date();
        cd.setHours(Time.hour, Time.minute, 0, 0);
        cd.setFullYear(Time.date.year, Time.date.month - 1, Time.date.day);
        return cd.getTime();
      }
      case 'calendar': {
        var ca = new Date();
        ca.setHours(0, 0, 0, 0);
        ca.setFullYear(Time.date.year, Time.date.month - 1, Time.date.day);
        return ca.getTime();
      }
      case 'isWeekEnd':    return Time.isWeekEnd();
      case 'isSchoolDay':  return Time.isSchoolDay(Time.date);
      case 'isSchoolTime': return Time.isSchoolTime(Time.date);
      case 'isBloodMoon':  return Time.isBloodMoon(Time.date);
      case 'cafeUpgraded': return State.variables.chef_state >= 8;
    }

    // 嵌套属性: npcData.robin.love, time.hour, V.someVariable
    var parts = token.split('.');
    if (parts.length < 2) return false;

    switch (parts[0]) {
      case 'npcData':
        var searchKey = parts[1].toLowerCase().replace(/\s/g, '');
        var npcResult = null;
        if (State.variables.NPCName) {
          for (var ni = 0; ni < State.variables.NPCName.length; ni++) {
            var npc = State.variables.NPCName[ni];
            if (npc.nam && npc.nam.toLowerCase().replace(/\s/g, '') === searchKey) {
              npcResult = npc;
              break;
            }
          }
        }
        if (npcResult) return getSubProperty(npcResult, parts.slice(2));
        return false;
      case 'npcInfo':
        return getSubProperty(State.variables.NPCList, parts.slice(1));
      case 'time':
        return getSubProperty(Time, parts.slice(1));
      case 'V':
        return getSubProperty(State.variables, parts.slice(1));
    }

    return false;
  }

  // ==================================================================
  //  getSubProperty -- 递归读取深层属性
  //  支持数组遍历聚合
  // ==================================================================
  function getSubProperty(baseNode, list) {
    var node = baseNode;
    for (var i = 0; i < list.length; i++) {
      if (!node) return null;
      if (node instanceof Array) {
        if (list[i] in node) {
          node = node[list[i]];
        } else {
          var agg = [];
          for (var j = 0; j < node.length; j++) {
            var item = getSubProperty(node[j], list.slice(i));
            if (item !== null) agg.push(item);
          }
          node = agg;
        }
      } else {
        if (list[i] in node) {
          node = node[list[i]];
        } else {
          return null;
        }
      }
    }
    return node;
  }

  // ==================================================================
  //  tokenizeQuery -- 状态机分词器
  //  将条件字符串解析为令牌数组
  //  支持: 引号字符串/括号分组/数组/取反/标识符
  // ==================================================================
  function tokenizeQuery(str) {
    var SPACE = 0, NEUTRAL = 1, QUOTE = 2, PARENS = 3, ARRAY = 4, EXCL = 5;

    var state = SPACE;
    var quoteType = '"';
    var parenCount = 0;
    var arrayCount = 0;
    var tokenBegin = 0;
    var tokens = [];

    for (var i = 0; i < str.length; i++) {
      var ch = str.charAt(i);

      switch (state) {
        case SPACE:
          if (ch === '"' || ch === "'" || ch === '`') {
            state = QUOTE; quoteType = ch; tokenBegin = i;
          } else if (ch === '(') {
            state = PARENS; parenCount = 1; tokenBegin = i;
          } else if (ch === '[') {
            state = ARRAY; arrayCount = 1; tokenBegin = i;
          } else if (ch === '!') {
            state = EXCL; tokenBegin = i;
          } else if (ch !== ' ') {
            state = NEUTRAL; tokenBegin = i;
          }
          break;

        case NEUTRAL:
          if (ch === ' ') {
            tokens.push(str.substring(tokenBegin, i));
            state = SPACE;
          }
          break;

        case QUOTE:
          if (ch === quoteType) {
            if (parenCount > 0) {
              state = PARENS;
            } else if (arrayCount > 0) {
              state = ARRAY;
            } else {
              tokens.push(str.substring(tokenBegin, i + 1));
              state = SPACE;
            }
          }
          break;

        case PARENS:
          if (ch === '(') {
            parenCount++;
          } else if (ch === ')') {
            parenCount--;
            if (parenCount === 0) {
              tokens.push(str.substring(tokenBegin, i + 1));
              state = SPACE;
            }
          } else if (ch === '"' || ch === "'" || ch === '`') {
            state = QUOTE;
            quoteType = ch;
          }
          break;

        case ARRAY:
          if (ch === '[') {
            arrayCount++;
          } else if (ch === ']') {
            arrayCount--;
            if (arrayCount === 0) {
              tokens.push(str.substring(tokenBegin, i + 1));
              state = SPACE;
            }
          } else if (ch === '"' || ch === "'" || ch === '`') {
            state = QUOTE;
            quoteType = ch;
          }
          break;

        case EXCL:
          if (ch === ' ') {
            tokens.push(str.substring(tokenBegin, i));
            state = SPACE;
          } else if (ch === '(') {
            state = PARENS;
            parenCount = 1;
          } else if (ch === '"' || ch === "'" || ch === '`') {
            state = QUOTE;
            quoteType = ch;
          } else if (ch === '!') {
            state = EXCL;
          } else {
            state = NEUTRAL;
          }
          break;
      }
    }

    if (state !== SPACE) {
      tokens.push(str.substring(tokenBegin));
    }

    return tokens;
  }

  // ==================================================================
  //  translateOperand -- 解析单个操作数为实际值
  //  处理: 布尔/简写/字符串/数组/随机范围/时间/日期/变量/数字/属性
  // ==================================================================
  function translateOperand(token) {
    if (token === 'true') return true;
    if (token === 'false') return false;

    var first = token.charAt(0);
    var last  = token.charAt(token.length - 1);

    // 简写引用 (stub, packs.js 提供简写表)
    if (first === '#') {
      return token;
    }

    // 字符串常量
    if (first === last && (first === '"' || first === "'" || first === '`')) {
      return token.slice(1, -1);
    }

    // 数组 [a, b, c]
    if (first === '[') {
      return parseArrayString(token.slice(1, -1));
    }

    // 随机范围: 1~5
    if (token.indexOf('~') !== -1) {
      var rp = token.split('~');
      var rMin = Math.min(Number(rp[0]), Number(rp[1]));
      var rMax = Math.max(Number(rp[0]), Number(rp[1]));
      return Math.random() * (rMax - rMin) + rMin;
    }

    // 时间格式 HH:MM
    if (token.indexOf(':') !== -1) {
      var tv = token.split(':');
      var td = new Date();
      td.setHours(tv[0], tv[1], 0, 0);
      td.setFullYear(Time.date.year, Time.date.month - 1, Time.date.day);
      return td.getTime();
    }

    // 日期格式 DD/MM[/YYYY]
    if (token.indexOf('/') !== -1) {
      var dv = token.split('/');
      var dd = new Date();
      dd.setHours(0, 0, 0, 0);
      dd.setFullYear(dv[2] ? Number(dv[2]) : Time.date.year, Number(dv[1]) - 1, Number(dv[0]));
      return dd.getTime();
    }

    // 变量引用: $pain, $npcData.robin.love
    if (first === '$') {
      var path = token.slice(1);
      var pp = path.split('.');
      var node = State.variables;
      for (var pi = 0; pi < pp.length; pi++) {
        if (pp[pi] in node) {
          node = node[pp[pi]];
        } else {
          return null;
        }
      }
      return node;
    }

    // 纯数字
    if (!isNaN(token)) {
      return Number(token);
    }

    // 尝试作为属性名解析
    try {
      return getProperty(token);
    } catch (e) {
      return false;
    }
  }

  // ==================================================================
  //  parseArrayString -- 解析数组字符串 [a, b, c]
  // ==================================================================
  function parseArrayString(str) {
    var SPACE = 0, NEUTRAL = 1, QUOTE = 2, PARENS = 3;

    var state = SPACE;
    var quoteType = '"';
    var parenCount = 0;
    var tokenBegin = 0;
    var tokens = [];

    for (var i = 0; i < str.length; i++) {
      var ch = str.charAt(i);

      switch (state) {
        case SPACE:
          if (ch === '"' || ch === "'" || ch === '`') {
            state = QUOTE; quoteType = ch; tokenBegin = i;
          } else if (ch === '(') {
            state = PARENS; parenCount = 1; tokenBegin = i;
          } else if (ch !== ',') {
            state = NEUTRAL; tokenBegin = i;
          }
          break;

        case NEUTRAL:
          if (ch === ',') {
            tokens.push(str.substring(tokenBegin, i));
            state = SPACE;
          }
          break;

        case QUOTE:
          if (ch === quoteType) {
            state = (parenCount > 0) ? PARENS : NEUTRAL;
          }
          break;

        case PARENS:
          if (ch === '(') {
            parenCount++;
          } else if (ch === ')') {
            parenCount--;
            if (parenCount === 0) { state = NEUTRAL; }
          } else if (ch === '"' || ch === "'" || ch === '`') {
            state = QUOTE;
            quoteType = ch;
          }
          break;
      }
    }

    if (state !== SPACE) {
      tokens.push(str.substring(tokenBegin));
    }

    var result = [];
    for (var ti = 0; ti < tokens.length; ti++) {
      var val = tokens[ti].trim();
      if (val.length > 0) {
        result.push(translateOperand(val));
      }
    }
    return result;
  }

  // ==================================================================
  //  normalizeEqual -- 比较时数值化
  //  将值转为数字再比较, 非数字保持原值
  // ==================================================================
  function normalizeEqual(val) {
    var f = parseFloat(val);
    return isNaN(f) ? val : f;
  }

  // ==================================================================
  //  arraySplit -- 按分隔符分割数组
  //  用于解析 or/and 逻辑分组
  // ==================================================================
  function arraySplit(input, delimiters) {
    var result = [];
    var current = [];

    for (var i = 0; i < input.length; i++) {
      var item = input[i];
      var isDelim = false;
      for (var d = 0; d < delimiters.length; d++) {
        if (item === delimiters[d]) { isDelim = true; break; }
      }
      if (isDelim) {
        if (current.length) { result.push(current); current = []; }
      } else {
        current.push(item);
      }
    }

    if (current.length) { result.push(current); }
    return result;
  }

  // ==================================================================
  //  evaluateOperation -- 比较运算
  //  支持: eq/neq/gte/lte/gt/lt/has/nas/in
  //  自动处理数组操作数
  // ==================================================================
  function evaluateOperation(left, op, right) {
    switch (op) {
      case 'has':
        try {
          if (left instanceof Array && !(right instanceof Array)) {
            for (var hi = 0; hi < left.length; hi++) {
              if (String(left[hi]).indexOf(String(right)) !== -1) return true;
            }
            return false;
          }
          if (!(left instanceof Array) && right instanceof Array) {
            for (var hi = 0; hi < right.length; hi++) {
              if (String(right[hi]).indexOf(String(left)) !== -1) return true;
            }
            return false;
          }
          return String(left).indexOf(String(right)) !== -1;
        } catch (e) { return false; }

      case 'nas':
        try {
          if (left instanceof Array && !(right instanceof Array)) {
            for (var ni = 0; ni < left.length; ni++) {
              if (String(left[ni]).indexOf(String(right)) !== -1) return false;
            }
            return true;
          }
          if (!(left instanceof Array) && right instanceof Array) {
            for (var ni = 0; ni < right.length; ni++) {
              if (String(right[ni]).indexOf(String(left)) !== -1) return false;
            }
            return true;
          }
          return String(left).indexOf(String(right)) === -1;
        } catch (e) { return false; }

      case '=':
      case '==':
      case 'eq':
      case 'is':
        try {
          if (left instanceof Array && !(right instanceof Array)) {
            for (var ei = 0; ei < left.length; ei++) {
              if (normalizeEqual(left[ei]) === normalizeEqual(right)) return true;
            }
            return false;
          }
          if (!(left instanceof Array) && right instanceof Array) {
            for (var ei = 0; ei < right.length; ei++) {
              if (normalizeEqual(right[ei]) === normalizeEqual(left)) return true;
            }
            return false;
          }
          return left === right;
        } catch (e) { return false; }

      case '!=':
      case '!==':
      case 'neq':
        try {
          if (left instanceof Array && !(right instanceof Array)) {
            for (var nei = 0; nei < left.length; nei++) {
              if (left[nei] === right) return false;
            }
            return true;
          }
          if (!(left instanceof Array) && right instanceof Array) {
            for (var nei = 0; nei < right.length; nei++) {
              if (right[nei] === left) return false;
            }
            return true;
          }
          return left !== right;
        } catch (e) { return false; }

      case 'gte':
      case 'gteq':
      case '>=':
        return left >= right;

      case 'gt':
      case '>':
        return left > right;

      case 'lte':
      case 'lteq':
      case '<=':
        return left <= right;

      case 'lt':
      case '<':
        return left < right;

      case 'in':
        try {
          if (right instanceof Array) {
            for (var ii = 0; ii < right.length; ii++) {
              if (right[ii] === left) return true;
            }
            return false;
          }
          if (typeof right === 'string') {
            return right.indexOf(String(left)) !== -1;
          }
          return false;
        } catch (e) { return false; }
    }

    return false;
  }

  // ==================================================================
  //  evaluateString -- 完整表达式求值
  //  分词 -> or/and 逻辑分组 -> 递归求值
  // ==================================================================
  function evaluateString(str) {
    var tokens = tokenizeQuery(str);

    // 单一 token 直接求值 (非括号/非取反)
    if (tokens.length === 1) {
      var t0 = tokens[0];
      if (t0.charAt(0) !== '(' && t0.charAt(0) !== '!') {
        return translateOperand(t0);
      }
    }

    // 按 or 分割
    var orGroups = arraySplit(tokens, ['or', '||', '|']);

    for (var o = 0; o < orGroups.length; o++) {
      // 按 and 分割
      var andGroups = arraySplit(orGroups[o], ['and', '&&', '&']);
      var allTrue = true;

      for (var a = 0; a < andGroups.length; a++) {
        var expr = andGroups[a];
        var exprResult;

        switch (expr.length) {
          case 3:
            exprResult = evaluateOperation(
              translateOperand(expr[0]),
              expr[1],
              translateOperand(expr[2])
            );
            break;

          case 2:
            exprResult = translateOperand(expr[0]) === translateOperand(expr[1]);
            break;

          case 1:
            if (expr[0].charAt(0) === '(') {
              exprResult = evaluateString(expr[0].slice(1, -1));
            } else if (expr[0].charAt(0) === '!') {
              exprResult = !evaluateString(expr[0].slice(1));
            } else {
              exprResult = translateOperand(expr[0]);
            }
            break;

          default:
            exprResult = false;
            break;
        }

        if (!exprResult) { allTrue = false; break; }
      }

      if (allTrue) return true;
    }

    return false;
  }

  // ==================================================================
  //  evaluateCondition -- 安全求值 (含错误处理)
  //  可选的 context 参数提供额外变量绑定
  // ==================================================================
  function evaluateCondition(conditionStr, context) {
    if (typeof conditionStr !== 'string' || conditionStr.trim().length === 0) {
      return false;
    }

    try {
      return !!evaluateString(conditionStr.trim());
    } catch (e) {
      return false;
    }
  }

  // ==================================================================
  //  公共 API
  // ==================================================================
  SM.audio.dsl.getProperty = getProperty;
  SM.audio.dsl.tokenize = tokenizeQuery;
  SM.audio.dsl.evaluate = evaluateString;
  SM.audio.dsl.evaluateCondition = evaluateCondition;
  SM.audio.dsl.evaluateString = evaluateString;
})();
