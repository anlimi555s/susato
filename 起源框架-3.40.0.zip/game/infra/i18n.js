// ==================================================================
//  i18n v1.0 -- 起源框架轻量国际化
//  框架 UI 字符串中英双份，按 V.language 选择。
//  不替代 ModI18N，只让框架自有 UI 不依赖外部翻译 mod。
//
//  API:
//   SusatoModel.i18n.t(key) -- 取当前语言的翻译
//   SusatoModel.i18n.define(key, zh, en) -- 注册翻译对
//   SusatoModel.i18n.defineAll({ key: [zh, en], ... })
//
// 依赖: susato-core.js (SM.onInit)
// 消费方: 管理器 UI / 主题工坊 / 框架错误提示
// ==================================================================

(function () {
  'use strict';

  var SM = window.SusatoModel;
  if (!SM || SM.i18n) return;

  var _dict = {}; // key -> {zh, en}

  function _lang() {
    try {
      // ModI18N 把当前语言存在 V.language 或 V.lang
      if (typeof V !== 'undefined' && V.language === 'CN') return 'zh';
      if (typeof V !== 'undefined' && V.language === 'EN') return 'en';
    } catch (e) {}
    return 'zh'; // 默认中文
  }

  SM.i18n = {
    t: function (key) {
      var entry = _dict[key];
      if (!entry) return key; // 未注册的 key 原样返回
      return _lang() === 'en' ? (entry.en || entry.zh || key) : (entry.zh || key);
    },

    define: function (key, zh, en) {
      if (!key) return;
      _dict[key] = { zh: zh || key, en: en || zh || key };
    },

    defineAll: function (map) {
      if (!map || typeof map !== 'object') return;
      for (var k in map) {
        if (Object.prototype.hasOwnProperty.call(map, k)) {
          var v = map[k];
          if (Array.isArray(v)) _dict[k] = { zh: v[0] || k, en: v[1] || v[0] || k };
          else if (typeof v === 'string') _dict[k] = { zh: v, en: v };
        }
      }
    },

    lang: _lang,

    // 批量注册框架 UI 字符串（在 storyready 时调用）
    init: function () {
      SM.i18n.defineAll({
        'manager.title':           ['mod管理', 'Mod Manager'],
        'manager.tab.diag':       ['诊断', 'Diagnosis'],
        'manager.tab.modules':    ['模块开关', 'Modules'],
        'manager.tab.update':     ['更新', 'Update'],
        'manager.tab.shop':       ['下载', 'Download'],
        'manager.tab.console':    ['控制台', 'Console'],
        'manager.btn.apply':      ['应用并刷新', 'Apply & Reload'],
        'manager.btn.reset':      ['恢复默认并刷新', 'Reset & Reload'],
        'manager.btn.check':      ['检查更新', 'Check Updates'],
        'manager.btn.install':    ['下载并安装', 'Download & Install'],
        'manager.btn.reload':     ['立即刷新', 'Reload Now'],
        'manager.msg.saved':      ['设置已保存, 正在刷新页面', 'Settings saved, reloading...'],
        'manager.msg.installed':  ['已安装, 刷新页面生效', 'Installed, reload to apply'],
        'manager.msg.writeFail':  ['写入失败, 浏览器可能处于隐私模式', 'Write failed, private mode?'],
        'manager.msg.uninstall':  ['已卸载, 正在刷新', 'Uninstalled, reloading...'],
        'manager.msg.allLatest':  ['全部 mod 均为最新版本。', 'All mods are up to date.'],
        'manager.msg.noMods':     ['未在清单中找到已安装的 mod。', 'No installed mods found in manifest.'],
        'manager.msg.repoUnset':  ['仓库未配置', 'Repository not configured'],
        'manager.empty.diag':     ['无告警。', 'No alerts.'],
        'manager.empty.modules':  ['暂无可配置模块。', 'No configurable modules.'],
        'manager.empty.update':   ['检查更新以查看可用版本。', 'Check for updates to see available versions.'],
        'manager.warn.oldCore':   ['生效的框架核心是旧版, 微调不可用。请在 Mod Loader 中移除旧包。', 'Old core detected, module tuning unavailable. Remove old packages in Mod Loader.'],
        'palette.title':          ['主题工坊', 'Theme Workshop'],
        'palette.btn.apply':      ['应用主题', 'Apply Theme'],
        'palette.btn.save':       ['保存', 'Save'],
        'palette.btn.export':     ['导出', 'Export'],
        'palette.btn.import':     ['导入', 'Import'],
        'console.title':          ['开发者控制台', 'Dev Console'],
        'console.btn.js':         ['执行 JS', 'Run JS'],
        'console.btn.twine':      ['执行 Twine', 'Run Twine'],
        'close':                  ['关闭', 'Close'],
      });
    }
  };

  // ---- 从 mod zip 加载翻译文件 (吸收自 PhoneMod readData.js) ----
  // 用法: SM.i18n.loadFromMod("隐都潜流", "translations/zh.json")
  SM.i18n.loadFromMod = function (modName, filePath) {
    try {
      var modUtils = window.modUtils || (window.modSC2DataManager && window.modSC2DataManager.getModUtils && window.modSC2DataManager.getModUtils());
      if (!modUtils) return false;

      var mod = modUtils.getMod && modUtils.getMod(modName);
      if (!mod || !mod.zip) return false;

      var entry = mod.zip.file && mod.zip.file(filePath);
      if (!entry) {
        try { console.warn('[i18n] 翻译文件未找到: ' + modName + '/' + filePath); } catch (e) {}
        return false;
      }

      var text = entry.async ? null : (typeof entry.getData === 'function' ? entry.getData().toString('utf8') : null);
      if (!text && entry.async) {
        // 异步加载：立即返回 true，异步注册
        entry.async('string').then(function (text) {
          try {
            var dict = JSON.parse(text);
            SM.i18n.defineAll(dict);
            try { console.log('[i18n] 已加载: ' + modName + '/' + filePath); } catch (e) {}
          } catch (e) {
            try { console.warn('[i18n] JSON 解析失败: ' + modName + '/' + filePath); } catch (ignore) {}
          }
        }).catch(function (e) {
          try { console.warn('[i18n] 加载失败: ' + modName + '/' + filePath + ' - ' + (e.message || e)); } catch (ignore) {}
        });
        return true; // 异步，已发起
      }

      if (text) {
        var dict = JSON.parse(text);
        SM.i18n.defineAll(dict);
        return true;
      }
    } catch (e) {
      try { console.warn('[i18n] loadFromMod 失败: ' + (e.message || e)); } catch (ignore) {}
    }
    return false;
  };

  // storyready 时初始化翻译表
  SM.onInit(function () { SM.i18n.init(); });
})();
