// ==================================================================
//  audio-menu v1.0 -- 音频设置面板
//  吸收 Breeze of Lewdity 设置菜单的思路，用框架 Dialog 重写。
//  提供音量滑块、分类控制、Pack 管理、导入导出。
//
//  API:
//    SM.audio.menu.open()        -- 打开设置面板
//    SM.audio.menu.close()       -- 关闭设置面板
//    SM.audio.menu.toggle()      -- 切换面板显示
//
//  依赖: SM.audio (audio-core), SM.ui (openPanel)
//  消费方: 管理器 (可选集成), 玩家
// ==================================================================
(function () {
  'use strict';

  if (window.SusatoModel && window.SusatoModel.moduleOff && window.SusatoModel.moduleOff('audio')) return;

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (SM.audio && SM.audio._menuV1) return;

  var _panelEl = null;
  var _panelOpen = false;

  // ================================================================
  //  渲染 Volume 滑块区域
  // ================================================================
  function renderVolumeSection() {
    var masterVol = SM.audio.getMasterVol();
    var musicVol = SM.audio.getCategoryVol(SM.audio.Type.MUSIC);
    var ambienceVol = SM.audio.getCategoryVol(SM.audio.Type.AMBIENCE);
    var sfxVol = SM.audio.getCategoryVol(SM.audio.Type.SFX);
    var enabled = SM.audio.isEnabled();

    var html = '<div class="audio-menu-section">';
    html += '<div class="audio-menu-section-title">音量控制</div>';

    // 主开关
    html += '<label class="audio-menu-row">';
    html += '<span>启用音频</span>';
    html += '<input type="checkbox" class="audio-menu-enabled" ' + (enabled ? 'checked' : '') + '>';
    html += '</label>';

    // 主音量
    html += '<label class="audio-menu-row">';
    html += '<span>主音量: <output class="audio-menu-master-val">' + Math.round(masterVol * 100) + '</output>%</span>';
    html += '<input type="range" class="audio-menu-master" min="0" max="100" value="' + Math.round(masterVol * 100) + '" step="5">';
    html += '</label>';

    // 音乐
    html += '<label class="audio-menu-row">';
    html += '<span>音乐: <output class="audio-menu-music-val">' + Math.round(musicVol * 100) + '</output>%</span>';
    html += '<input type="range" class="audio-menu-music" min="0" max="100" value="' + Math.round(musicVol * 100) + '" step="5">';
    html += '</label>';

    // 环境音
    html += '<label class="audio-menu-row">';
    html += '<span>环境音: <output class="audio-menu-ambience-val">' + Math.round(ambienceVol * 100) + '</output>%</span>';
    html += '<input type="range" class="audio-menu-ambience" min="0" max="100" value="' + Math.round(ambienceVol * 100) + '" step="5">';
    html += '</label>';

    // 音效
    html += '<label class="audio-menu-row">';
    html += '<span>音效: <output class="audio-menu-sfx-val">' + Math.round(sfxVol * 100) + '</output>%</span>';
    html += '<input type="range" class="audio-menu-sfx" min="0" max="100" value="' + Math.round(sfxVol * 100) + '" step="5">';
    html += '</label>';

    html += '</div>';
    return html;
  }

  // ================================================================
  //  渲染 Pack 列表区域
  // ================================================================
  function renderPacksSection() {
    var packs = SM.audio.packs ? SM.audio.packs.list() : [];
    var html = '<div class="audio-menu-section">';
    html += '<div class="audio-menu-section-title">音频包 (' + packs.length + ')</div>';

    if (packs.length === 0) {
      html += '<div class="audio-menu-empty">暂无音频包。通过菜单导入或放置在 mod 目录。</div>';
    } else {
      for (var i = 0; i < packs.length; i++) {
        var pack = packs[i];
        html += '<label class="audio-menu-row audio-menu-pack-row">';
        html += '<span>' + pack.name + ' <small>v' + pack.version + '</small></span>';
        html += '<input type="checkbox" class="audio-menu-pack-toggle" data-pack="' + pack.name + '" ' + (pack.enabled ? 'checked' : '') + '>';
        html += '</label>';
      }
    }

    html += '</div>';
    return html;
  }

  // ================================================================
  //  渲染底部按钮
  // ================================================================
  function renderFooter() {
    return '<div class="audio-menu-section audio-menu-footer">' +
      '<button class="audio-menu-btn audio-menu-btn-import">导入 Pack (JSON)</button>' +
      '<button class="audio-menu-btn audio-menu-btn-export">导出配置</button>' +
      '<button class="audio-menu-btn audio-menu-btn-reset">恢复默认</button>' +
      '</div>';
  }

  // ================================================================
  //  构建完整面板
  // ================================================================
  function buildPanel() {
    var container = document.createElement('div');
    container.className = 'audio-menu-container';
    container.innerHTML = renderVolumeSection() + renderPacksSection() + renderFooter();
    return container;
  }

  // ================================================================
  //  事件绑定
  // ================================================================
  function bindEvents() {
    if (!_panelEl) return;

    // 主开关
    var enabledCb = _panelEl.querySelector('.audio-menu-enabled');
    if (enabledCb) {
      enabledCb.onchange = function () {
        SM.audio.setEnabled(enabledCb.checked);
      };
    }

    // 主音量滑块
    var masterSlider = _panelEl.querySelector('.audio-menu-master');
    var masterOutput = _panelEl.querySelector('.audio-menu-master-val');
    if (masterSlider && masterOutput) {
      masterSlider.oninput = function () { masterOutput.textContent = masterSlider.value; };
      masterSlider.onchange = function () {
        SM.audio.setMasterVol(parseInt(masterSlider.value, 10) / 100);
      };
    }

    // 分类音量滑块
    var types = [
      { cls: 'music', type: SM.audio.Type.MUSIC },
      { cls: 'ambience', type: SM.audio.Type.AMBIENCE },
      { cls: 'sfx', type: SM.audio.Type.SFX }
    ];
    types.forEach(function (t) {
      var slider = _panelEl.querySelector('.audio-menu-' + t.cls);
      var output = _panelEl.querySelector('.audio-menu-' + t.cls + '-val');
      if (slider && output) {
        slider.oninput = function () { output.textContent = slider.value; };
        slider.onchange = function () {
          SM.audio.setCategoryVol(t.type, parseInt(slider.value, 10) / 100);
        };
      }
    });

    // Pack 开关
    var packToggles = _panelEl.querySelectorAll('.audio-menu-pack-toggle');
    for (var i = 0; i < packToggles.length; i++) {
      packToggles[i].onchange = function () {
        var name = this.dataset.pack;
        if (name && SM.audio.packs) SM.audio.packs.enable(name, this.checked);
      };
    }

    // 导入
    var importBtn = _panelEl.querySelector('.audio-menu-btn-import');
    if (importBtn) {
      importBtn.onclick = function () {
        var input = document.createElement('input');
        input.type = 'file';
        input.accept = '.json';
        input.onchange = function () {
          var file = input.files[0];
          if (!file) return;
          var reader = new FileReader();
          reader.onload = function () {
            try {
              var json = JSON.parse(reader.result);
              if (SM.audio.packs) {
                SM.audio.packs.load(json);
                refreshPanel();
              }
            } catch (e) {
              console.error('[SM.audio] 导入 pack 失败:', e);
            }
          };
          reader.readAsText(file);
        };
        input.click();
      };
    }

    // 导出
    var exportBtn = _panelEl.querySelector('.audio-menu-btn-export');
    if (exportBtn) {
      exportBtn.onclick = function () {
        var config = {
          enabled: SM.audio.isEnabled(),
          masterVol: SM.audio.getMasterVol(),
          categoryVol: {
            music: SM.audio.getCategoryVol(SM.audio.Type.MUSIC),
            ambience: SM.audio.getCategoryVol(SM.audio.Type.AMBIENCE),
            sfx: SM.audio.getCategoryVol(SM.audio.Type.SFX)
          },
          packs: SM.audio.packs ? SM.audio.packs.list() : []
        };
        var blob = new Blob([JSON.stringify(config, null, 2)], { type: 'application/json' });
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = 'susato_audio_config.json';
        a.click();
        URL.revokeObjectURL(url);
      };
    }

    // 重置
    var resetBtn = _panelEl.querySelector('.audio-menu-btn-reset');
    if (resetBtn) {
      resetBtn.onclick = function () {
        SM.audio.setEnabled(true);
        SM.audio.setMasterVol(1.0);
        SM.audio.setCategoryVol(SM.audio.Type.MUSIC, 1.0);
        SM.audio.setCategoryVol(SM.audio.Type.AMBIENCE, 1.0);
        SM.audio.setCategoryVol(SM.audio.Type.SFX, 1.0);
        refreshPanel();
      };
    }
  }

  function refreshPanel() {
    if (!_panelEl) return;
    _panelEl.innerHTML = '';
    var newPanel = buildPanel();
    while (newPanel.firstChild) {
      _panelEl.appendChild(newPanel.firstChild);
    }
    bindEvents();
  }

  // ================================================================
  //  公开 API
  // ================================================================
  var menu = {
    open: function () {
      if (_panelOpen) return;

      if (SM.ui && typeof SM.ui.openPanel === 'function') {
        // 使用框架 Dialog
        _panelEl = buildPanel();
        bindEvents();
        _panelOpen = true;
        SM.ui.openPanel('susatoAudioPanel', {
          title: '音频设置',
          content: _panelEl,
          onClose: function () { _panelOpen = false; _panelEl = null; }
        });
      } else {
        // 兜底: 直接 append 到 body
        var overlay = document.createElement('div');
        overlay.className = 'audio-menu-overlay';
        overlay.onclick = function (e) { if (e.target === overlay) { overlay.remove(); _panelOpen = false; } };

        _panelEl = buildPanel();
        _panelEl.className += ' audio-menu-standalone';
        overlay.appendChild(_panelEl);
        document.body.appendChild(overlay);
        bindEvents();
        _panelOpen = true;
      }
    },

    close: function () {
      if (!_panelOpen) return;
      if (_panelEl && _panelEl.parentNode) {
        _panelEl.parentNode.remove();
      }
      _panelOpen = false;
      _panelEl = null;
    },

    toggle: function () {
      if (_panelOpen) menu.close();
      else menu.open();
    }
  };

  SM.audio.menu = menu;
  SM.audio._menuV1 = true;

  // 模块注册
  if (typeof SM.modules === 'object' && typeof SM.modules.register === 'function') {
    SM.modules.register('audio-menu', function () {
      return menu;
    }, { deps: ['audio-core', 'audio-packs'], phase: 'postInit' });
  }

})();
