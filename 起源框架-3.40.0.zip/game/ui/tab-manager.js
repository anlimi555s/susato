// ==================================================================
//  tab-manager v1.0 -- 标签页管理系统
//  吸收 Cheat Extended CE_TabManager:
//  注册/渲染/排序/收藏/隐藏/持久化，完整的标签页组织方案。
//
//  API:
//    SM.tab.register(id, config)     -- 注册标签页
//      config: { title, onClick, condition, group }
//      title:     显示文本 (string)
//      onClick:   点击回调 (function)
//      condition: 可见条件 (function, 可选)
//      group:     分组名 (string, 可选, 用于互斥组等扩展)
//    SM.tab.unregister(id)           -- 移除标签页
//    SM.tab.render(containerEl)       -- 渲染全部标签按钮到容器
//    SM.tab.restore()                 -- 恢复上次选中的标签页
//    SM.tab.openSorter()              -- 打开排序/管理对话框
//    SM.tab.list()                    -- 列出全部已注册标签页
//
//  持久化 (State.variables):
//    V.SM_TabOrder    -- 标签页排列顺序 (id[])
//    V.SM_TabHidden   -- 隐藏的标签页 ( {id: true} )
//    V.SM_TabFavorite -- 收藏的标签页 ( {id: true} )
//    V.SM_LastTab     -- 上次选中的标签页 id
//
//  依赖: susato-core.js (SM.events, SM.onInit)
//  消费方: manager.js (管理器面板), 内容 mod 设置面板
// ==================================================================
(function () {
  'use strict';

  if (window.SusatoModel && window.SusatoModel.moduleOff && window.SusatoModel.moduleOff('tab-manager')) return;

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (SM.tab) return;

  var _tabs = [];        // [{id, title, onClick, condition, group}]
  var _btnMap = {};      // id -> button DOM
  var _sortWrap = null;  // 排序 UI 容器
  var _defaultOrder = null; // 初始注册顺序快照

  // 安全取持久化状态 (V. 可能在 storyready 后才存在)
  function _ensureVars() {
    try {
      if (typeof V === 'undefined') return false;
      if (V.SM_TabOrder === undefined) V.SM_TabOrder = [];
      if (V.SM_TabHidden === undefined) V.SM_TabHidden = {};
      if (V.SM_TabFavorite === undefined) V.SM_TabFavorite = {};
      return true;
    } catch (e) { return false; }
  }

  SM.tab = {
    register: function (id, config) {
      if (!id || !config || !config.title || typeof config.onClick !== 'function') return false;
      // 防重复
      for (var i = 0; i < _tabs.length; i++) {
        if (_tabs[i].id === id) {
          _tabs[i] = { id: id, title: config.title, onClick: config.onClick, condition: config.condition || null, group: config.group || null };
          return true;
        }
      }
      _tabs.push({ id: id, title: config.title, onClick: config.onClick, condition: config.condition || null, group: config.group || null });
      if (!_defaultOrder) _defaultOrder = _tabs.map(function (t) { return t.id; });
      return true;
    },

    unregister: function (id) {
      var idx = -1;
      for (var i = 0; i < _tabs.length; i++) {
        if (_tabs[i].id === id) { idx = i; break; }
      }
      if (idx < 0) return false;
      _tabs.splice(idx, 1);
      delete _btnMap[id];
      return true;
    },

    list: function () {
      return _tabs.slice();
    },

    // 套用持久化排序 -> 返回渲染用的有序列表 (不包含隐藏/条件不符的)
    _getVisible: function () {
      _ensureVars();
      var map = {};
      for (var i = 0; i < _tabs.length; i++) {
        map[_tabs[i].id] = _tabs[i];
      }

      // 按 V.SM_TabOrder 排序，未排序的放在末尾
      var ordered = [];
      var unseen = {};
      for (var j = 0; j < _tabs.length; j++) { unseen[_tabs[j].id] = true; }

      if (Array.isArray(V.SM_TabOrder)) {
        for (var k = 0; k < V.SM_TabOrder.length; k++) {
          var tid = V.SM_TabOrder[k];
          if (map[tid]) { ordered.push(map[tid]); delete unseen[tid]; }
        }
      }
      for (var m = 0; m < _tabs.length; m++) {
        if (unseen[_tabs[m].id]) ordered.push(_tabs[m]);
      }

      // 过滤隐藏 + 条件不符
      var hidden = V.SM_TabHidden || {};
      var visible = [];
      for (var n = 0; n < ordered.length; n++) {
        var t = ordered[n];
        if (hidden[t.id]) continue;
        if (t.condition && !t.condition()) continue;
        visible.push(t);
      }
      return visible;
    },

    render: function (container) {
      if (!container) return;
      _ensureVars();
      container.innerHTML = '';
      _btnMap = {};

      var favorites = [];
      var normals = [];
      var visible = SM.tab._getVisible();
      var fav = V.SM_TabFavorite || {};

      for (var i = 0; i < visible.length; i++) {
        if (visible[i].id === 'tab-sort') continue;
        if (fav[visible[i].id]) favorites.push(visible[i]);
        else normals.push(visible[i]);
      }

      function _renderOne(tab) {
        var btn = document.createElement('button');
        btn.textContent = fav[tab.id] ? tab.title + ' *' : tab.title;
        btn.dataset.tabId = tab.id;
        btn.className = 'sm-tab-btn';
        if (fav[tab.id]) btn.style.fontWeight = 'bold';

        btn.onclick = function () {
          try { tab.onClick(); } catch (e) {}
          V.SM_LastTab = tab.id;
        };
        _btnMap[tab.id] = btn;
        container.appendChild(btn);
      }

      // 先渲染收藏
      for (var f = 0; f < favorites.length; f++) { _renderOne(favorites[f]); }

      // 分隔线
      if (favorites.length > 0 && normals.length > 0) {
        var sep = document.createElement('span');
        sep.className = 'sm-tab-sep';
        sep.style.cssText = 'margin:0 2px;color:#555;';
        sep.textContent = '|';
        container.appendChild(sep);
      }

      // 渲染普通
      for (var g = 0; g < normals.length; g++) { _renderOne(normals[g]); }

      // 排序按钮 (始终在最后)
      var sortTab = null;
      for (var s = 0; s < _tabs.length; s++) {
        if (_tabs[s].id === 'tab-sort') { sortTab = _tabs[s]; break; }
      }
      if (sortTab && (!sortTab.condition || sortTab.condition())) {
        if (favorites.length + normals.length > 0) {
          var sep2 = document.createElement('span');
          sep2.className = 'sm-tab-sep';
          sep2.style.cssText = 'margin:0 2px;color:#555;';
          sep2.textContent = '|';
          container.appendChild(sep2);
        }
        _renderOne(sortTab);
      }
    },

    restore: function () {
      _ensureVars();
      var tabId = V.SM_LastTab;
      if (!tabId || !_btnMap[tabId]) {
        // 选第一个可见的
        var visible = SM.tab._getVisible();
        if (visible.length > 0) {
          tabId = visible[0].id;
          // 跳过排序按钮
          if (tabId === 'tab-sort' && visible.length > 1) tabId = visible[1].id;
        } else {
          return;
        }
      }
      if (_btnMap[tabId]) {
        try { _btnMap[tabId].click(); } catch (e) {}
      }
    },

    openSorter: function () {
      _ensureVars();
      if (_sortWrap) {
        try { if (typeof Dialog !== 'undefined') Dialog.close(); } catch (e) {}
        _sortWrap = null;
      }
      if (typeof Dialog === 'undefined') return;

      Dialog.setup('标签页管理');
      Dialog.wiki('');

      // 修复 Dialog 关闭按钮 (游戏 0.5.7.x 偶发丢失)
      setTimeout(function () {
        var btn = document.getElementById('ui-dialog-close');
        if (!btn) return;
        btn.textContent = 'X';
        btn.style.display = 'inline-flex';
        btn.style.alignItems = 'center';
        btn.style.justifyContent = 'center';
        btn.style.visibility = 'visible';
        btn.style.opacity = '1';
        btn.style.pointerEvents = 'auto';
      }, 0);

      var body = Dialog.body();
      if (!body) return;

      var wrap = document.createElement('div');
      wrap.style.maxHeight = '400px';
      wrap.style.overflowY = 'auto';
      body.appendChild(wrap);
      _sortWrap = wrap;

      // 说明文字
      var info = document.createElement('div');
      info.style.cssText = 'margin-bottom:8px;font-size:0.85rem;color:#888;';
      info.textContent = '勾选收藏的标签页会优先显示，取消勾选可隐藏标签页，使用上下按钮调整顺序';
      wrap.appendChild(info);

      // 还原默认排序
      var restoreBtn = document.createElement('button');
      restoreBtn.textContent = '还原默认顺序';
      restoreBtn.onclick = function () {
        if (_defaultOrder) {
          V.SM_TabOrder = _defaultOrder.slice();
        }
        _sortWrap = null;
        SM.tab.openSorter();
      };
      wrap.appendChild(restoreBtn);

      // 每个标签页一行
      for (var i = 0; i < _tabs.length; i++) {
        var tab = _tabs[i];
        if (tab.id === 'tab-sort') continue;

        var row = document.createElement('div');
        row.style.cssText = 'display:flex;align-items:center;gap:4px;margin-bottom:4px;';

        // 收藏
        var favCb = document.createElement('input');
        favCb.type = 'checkbox';
        favCb.title = '收藏 (优先显示)';
        favCb.checked = !!(V.SM_TabFavorite || {})[tab.id];
        favCb.onchange = function () {
          if (favCb.checked) V.SM_TabFavorite[tab.id] = true;
          else delete V.SM_TabFavorite[tab.id];
        };
        row.appendChild(favCb);

        // 显示/隐藏
        var visCb = document.createElement('input');
        visCb.type = 'checkbox';
        visCb.title = '显示';
        visCb.checked = !(V.SM_TabHidden || {})[tab.id];
        visCb.onchange = function () {
          V.SM_TabHidden[tab.id] = !visCb.checked;
        };
        row.appendChild(visCb);

        // 标签名
        var label = document.createElement('span');
        label.textContent = tab.title;
        label.style.flex = '1';
        row.appendChild(label);

        // 上移
        var upBtn = document.createElement('button');
        upBtn.textContent = '^';
        upBtn.onclick = function () {
          var order = V.SM_TabOrder || [];
          var idx = order.indexOf(tab.id);
          if (idx <= 0) {
            // 不在 order 中或已在首位
            if (idx < 0) {
              // 插入到 order 头部
              order.unshift(tab.id);
              V.SM_TabOrder = order;
            }
            return;
          }
          var tmp = order[idx - 1];
          order[idx - 1] = order[idx];
          order[idx] = tmp;
          V.SM_TabOrder = order;
          var prev = row.previousElementSibling;
          if (prev) wrap.insertBefore(row, prev);
        };
        row.appendChild(upBtn);

        // 下移
        var downBtn = document.createElement('button');
        downBtn.textContent = 'v';
        downBtn.onclick = function () {
          var order = V.SM_TabOrder || [];
          var idx = order.indexOf(tab.id);
          if (idx < 0) {
            order.push(tab.id);
            V.SM_TabOrder = order;
            return;
          }
          if (idx >= order.length - 1) return;
          var tmp = order[idx + 1];
          order[idx + 1] = order[idx];
          order[idx] = tmp;
          V.SM_TabOrder = order;
          var next = row.nextElementSibling;
          if (next && next.nextElementSibling) {
            wrap.insertBefore(row, next.nextElementSibling);
          }
        };
        row.appendChild(downBtn);

        wrap.appendChild(row);
      }

      Dialog.open(function () {
        _sortWrap = null;
      });
    }
  };

  // 注册排序管理标签页
  SM.tab.register('tab-sort', {
    title: '标签页管理',
    onClick: function () { SM.tab.openSorter(); }
  });
})();
