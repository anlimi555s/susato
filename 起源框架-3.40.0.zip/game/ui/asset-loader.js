// ==================================================================
//  asset-loader v1.0 — 自定义 Mod 图片加载器
//  将 img/misc/icon/ 下的自定义 mod 图片解析为 base64 data URI。
//
//  API:
//    SusatoModel.assets.add(path1, path2, ...)
//    SusatoModel.assets.get(path) — 返回 base64 字符串
//    SusatoModel.assets.render(path, w, h) — 返回 <img> HTML
//    SusatoModel.assets.loaded() — 全部图片是否就绪
//
//  依赖: modSC2DataManager.getHtmlTagSrcHook().requestImageBySrc()
//  消费方: 隐都潜流 (拳击/黑市图标)
// ==================================================================
(function () {
  'use strict';

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (SM.assets) return;

  var _store = {};    // path -> dataUri (filled as loaded)
  var _pending = [];  // paths registered but not yet loaded
  var _resolving = false;

  function _resolveOne(path) {
    try {
      var hook = window.modSC2DataManager &&
                 window.modSC2DataManager.getHtmlTagSrcHook &&
                 window.modSC2DataManager.getHtmlTagSrcHook();
      if (!hook || typeof hook.requestImageBySrc !== 'function') return Promise.resolve('');
      return hook.requestImageBySrc(path).then(function (b64) {
        return b64 ? ('data:image/png;base64,' + b64) : '';
      }, function () { return ''; });
    } catch (e) { return Promise.resolve(''); }
  }

  function _resolveAll() {
    if (_resolving || !_pending.length) return;
    _resolving = true;
    var batch = _pending.slice();
    _pending = [];
    Promise.all(batch.map(function (path) {
      return _resolveOne(path).then(function (uri) {
        _store[path] = uri || '';
      });
    })).then(function () {
      _resolving = false;
      // 如果有晚注册的, 继续处理
      if (_pending.length) _resolveAll();
    });
  }

  SM.assets = {
    add: function () {
      for (var i = 0; i < arguments.length; i++) {
        var p = arguments[i];
        if (typeof p !== 'string' || !p || p in _store) continue;
        _store[p] = '';  // placeholder, to be filled
        _pending.push(p);
      }
      _resolveAll();
    },

    get: function (path) {
      return _store[path] || '';
    },

    render: function (path, width, height) {
      var src = _store[path] || '';
      if (!src) return '<!-- asset not ready: ' + (path || '') + ' -->';
      var w = width ? ' width="' + width + '"' : '';
      var h = height ? ' height="' + height + '"' : '';
      return '<img src="' + src + '"' + w + h + '>';
    },

    loaded: function () {
      if (_pending.length) return false;
      for (var k in _store) {
        if (Object.prototype.hasOwnProperty.call(_store, k) && !_store[k]) return false;
      }
      return true;
    },

    _store: _store,
    _forceRefresh: _resolveAll,
  };
})();
