// ==================================================================
//  tool-collection v1.0 -- 工具集统一入口
//  对标 maplebirch ToolCollection: console / rand / migration / macro 集中管理。
//  不新建工具，只是把散落的已有工具收进 SM.tool.*。
//
//  API:
//    SM.tool.console     -- 控制台 (cheat-console.js)
//    SM.tool.rand        -- 可控随机数 (rand.js)
//    SM.tool.migration   -- 数据迁移 (migration.js)
//    SM.tool.macro       -- 宏注册 (DefineMacroS)
//    SM.tool.zone        -- 区域注入 (zonesManager)
//    SM.tool.log         -- 分级日志 (log-hook)
//
//  依赖: 各工具模块已独立加载
//  消费方: 开发调试 / 内容 mod
// ==================================================================
(function () {
  'use strict';

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (SM.tool) return;

  SM.tool = {
    // 控制台 (cheat-console.js 挂到 SM 上)
    get console() { return SM._cheatConsole || null; },

    // 随机数 (rand.js 挂到 SM.rand 上)
    get rand() { return SM.rand; },

    // 数据迁移 (migration.js)
    get migration() { return SM._migration || null; },

    // 宏注册 (DefineMacroS -- skill-addon 提供)
    get macro() { return typeof DefineMacroS !== 'undefined' ? DefineMacroS : null; },

    // 区域注入 (zonesManager 在 susato-core SM.text 上)
    get zone() { return SM.text || null; },

    // 分级日志
    get log() { return (typeof window !== 'undefined' && window.__susatoLogHook) || null; }
  };
})();
