// ==================================================================
//  audio-core v1.0 -- 音频播放核心引擎
//  吸收 Breeze of Lewdity 音频播放系统核心:
//    IAudioPlayer/HTMLAudioPlayer 架构
//    多类型音频管理 (Music/Ambience/SFX)
//    淡入淡出/音高渐变/循环播放
//    音量分层 (主音量 x 分类音量)
//    设置持久化
//
//  不包含: YouTube播放器/DSL解析/音频包管理
//  (分别由 audio-youtube.js / audio-dsl.js / audio-packs.js 提供)
//
//  API:
//    SM.audio.Type                -- 音频类型枚举
//    SM.audio.play(type, url, params) -> IAudioPlayer
//    SM.audio.stop(url)           -- 停止指定音频 (淡出后移除)
//    SM.audio.stopAll()           -- 停止全部音频
//    SM.audio.stopCategory(type)  -- 停止指定分类全部音频
//    SM.audio.setMasterVol(v)     -- 设置主音量 (0-1)
//    SM.audio.getMasterVol()      -- 获取主音量
//    SM.audio.setCategoryVol(t,v) -- 设置分类音量
//    SM.audio.getCategoryVol(t)   -- 获取分类音量
//    SM.audio.isEnabled()         -- 音频是否启用
//    SM.audio.setEnabled(bool)    -- 启用/禁用音频
//    SM.audio.getEffectiveVolume(type) -- 获取有效音量值
//    SM.audio._init()             -- 初始化 (加载设置+启动清理)
//
//  依赖: SM.modules (module-system)
//  消费方: audio-dsl.js / audio-packs.js / audio-youtube.js
// ==================================================================
(function () {
  'use strict';

  if (window.SusatoModel && window.SusatoModel.moduleOff && window.SusatoModel.moduleOff('audio')) return;

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (SM.audio) return;

  // ---- 枚举 ----
  SM.audio = {};
  SM.audio.Type = Object.freeze({
    MUSIC: 'music', AMBIENCE: 'ambience', SFX: 'sfx'
  });
  var AT = SM.audio.Type;

  // ---- 工具函数 ----
  function clamp(val, min, max) { return Math.min(Math.max(val, min), max); }

  function assignIfNotNull(original, value) {
    return (value !== null && value !== undefined) ? value : original;
  }

  function getEffectiveVolume(type) {
    if (!_enabled) return 0;
    var catVol = _categoryVol[type];
    if (catVol === undefined) catVol = 1.0;
    return _masterVol * catVol;
  }

  // ==================================================================
  //  IAudioPlayer 基类
  // ==================================================================
  function IAudioPlayer(player, type, params) {
    this.player = player;
    this.type = type;
    this.isReady = false;
    this.recent = true;
    this.initialized = false;
    this.dirty = false;
    this.unusable = false;

    this.volume = assignIfNotNull(params.volume, 1.0);
    this.pitch  = assignIfNotNull(params.pitch, 1.0);
    this.loop     = assignIfNotNull(params.loop, (type !== AT.SFX));
    this.loopStart = assignIfNotNull(params.loopStart, 0);

    this.start   = params.start   || 0;
    this.end     = params.end     || 0;
    this.offset  = params.offset  || 0;
    this.delay   = params.delay   || 0;
    this.fadeIn  = assignIfNotNull(params.fadeIn, (type === AT.SFX) ? 0 : 1000);
    this.fadeOut = assignIfNotNull(params.fadeOut, (type === AT.SFX) ? 0 : 1000);
    this.fadePitchTime = assignIfNotNull(params.fadePitch, 1000);
    this.repeat  = params.repeat  || 0;

    this.fadeTimer     = null;
    this.fadePitchTimer = null;
    this._stepTick = 0; this._stepTicks = 0;
    this._stepFrom = 0; this._stepDelta = 0; this._stepStop = false;
    this._stepPitchFrom = 0; this._stepPitchDelta = 0;
    this._stepPitchTicks = 0; this._stepPitchTick = 0;
  }

  IAudioPlayer.prototype.markForRemoval = function (fadeout) {
    this.dirty = true;
    var dur = (fadeout !== undefined && fadeout > 0) ? fadeout : this.fadeOut;
    if (dur > 0) { this.fadeVolume(this.volume, 0, dur, true); }
    else { this._stop(); }
  };

  IAudioPlayer.prototype.finalize = function () {
    this.setVolume(this.volume);
    this.setPitch(this.pitch);
    if (this.fadeIn > 0 && this.volume > 0) {
      this.fadeVolume(0, this.volume, this.fadeIn, false);
    }
  };

  IAudioPlayer.prototype.setVolume = function (v) { this.volume = clamp(v, 0, 1); };
  IAudioPlayer.prototype.setPitch = function (v) { this.pitch = v; };

  IAudioPlayer.prototype.fadeVolume = function (from, to, duration, stopAfter) {
    if (this.fadeTimer) { clearInterval(this.fadeTimer); this.fadeTimer = null; }
    var interval = 50;
    var ticks = Math.max(1, Math.floor(duration / interval));
    var self = this;
    this._stepFrom = from; this._stepDelta = to - from;
    this._stepTicks = ticks; this._stepTick = 0; this._stepStop = !!stopAfter;
    this.fadeTimer = setInterval(function () { self.step(); }, interval);
  };

  IAudioPlayer.prototype.fadePitch = function (from, to, duration) {
    if (this.fadePitchTimer) { clearInterval(this.fadePitchTimer); this.fadePitchTimer = null; }
    var interval = 50;
    var ticks = Math.max(1, Math.floor(duration / interval));
    var self = this;
    this._stepPitchFrom = from; this._stepPitchDelta = to - from;
    this._stepPitchTicks = ticks; this._stepPitchTick = 0;
    this.fadePitchTimer = setInterval(function () {
      self._stepPitchTick++;
      var progress = self._stepPitchTick / self._stepPitchTicks;
      self.setPitch(self._stepPitchFrom + self._stepPitchDelta * Math.min(progress, 1));
      if (self._stepPitchTick >= self._stepPitchTicks) {
        clearInterval(self.fadePitchTimer);
        self.fadePitchTimer = null;
      }
    }, interval);
  };

  IAudioPlayer.prototype.step = function () {
    this._stepTick++;
    var progress = this._stepTick / this._stepTicks;
    this.setVolume(this._stepFrom + this._stepDelta * Math.min(progress, 1));
    if (this._stepTick >= this._stepTicks) {
      clearInterval(this.fadeTimer);
      this.fadeTimer = null;
      if (this._stepStop) { this._stop(); }
    }
  };

  IAudioPlayer.prototype._stop = function () {
    if (this.fadeTimer) { clearInterval(this.fadeTimer); this.fadeTimer = null; }
    if (this.fadePitchTimer) { clearInterval(this.fadePitchTimer); this.fadePitchTimer = null; }
    if (this.player && typeof this.player.pause === 'function') { this.player.pause(); }
  };

  // ==================================================================
  //  HTMLAudioPlayer
  // ==================================================================
  function HTMLAudioPlayer(type, url, params) {
    var audio = new Audio();
    audio.preload = 'auto';
    audio.crossOrigin = 'anonymous';

    IAudioPlayer.call(this, audio, type, params);
    this.url = url;

    audio.addEventListener('canplay', function () {
      this.isReady = true;
      if (!this.initialized) { this.initialized = true; this.finalize(); }
    }.bind(this));

    audio.addEventListener('error', function () {
      this.unusable = true;
      console.warn('[SM.audio] 加载失败:', url);
    }.bind(this));

    audio.addEventListener('ended', function () {
      if (this.unusable) return;
      if (this.repeat > 0) {
        this.repeat--;
        if (this.repeat <= 0) { this.markForRemoval(0); return; }
      }
      if (this.loop) {
        audio.currentTime = this.loopStart > 0 ? this.loopStart : 0;
        audio.play().catch(function () {});
      }
    }.bind(this));

    audio.src = url;
    audio.load();
    audio.volume = 0;
  }

  HTMLAudioPlayer.prototype = Object.create(IAudioPlayer.prototype);
  HTMLAudioPlayer.prototype.constructor = HTMLAudioPlayer;

  HTMLAudioPlayer.prototype.setVolume = function (v) {
    IAudioPlayer.prototype.setVolume.call(this, v);
    if (!this.player) return;
    this.player.volume = this.volume * getEffectiveVolume(this.type);
  };

  HTMLAudioPlayer.prototype.setPitch = function (v) {
    IAudioPlayer.prototype.setPitch.call(this, v);
    if (!this.player) return;
    this.player.playbackRate = clamp(this.pitch, 0.25, 4);
  };

  HTMLAudioPlayer.prototype._stop = function () {
    IAudioPlayer.prototype._stop.call(this);
    if (this.player) { this.player.removeAttribute('src'); this.player.load(); }
  };

  // ==================================================================
  //  音量系统
  // ==================================================================
  var _masterVol = 1.0;
  var _categoryVol = {};
  _categoryVol[AT.MUSIC] = 1.0;
  _categoryVol[AT.AMBIENCE] = 1.0;
  _categoryVol[AT.SFX] = 1.0;
  var _enabled = true;

  function _applyVolumeToAll() {
    _audioList.forEach(function (player) {
      if (player.setVolume && !player.unusable) { player.setVolume(player.volume); }
    });
  }

  SM.audio.setMasterVol = function (v) { _masterVol = clamp(v, 0, 1); _applyVolumeToAll(); saveSettings(); };
  SM.audio.getMasterVol = function () { return _masterVol; };
  SM.audio.setCategoryVol = function (type, v) { _categoryVol[type] = clamp(v, 0, 1); _applyVolumeToAll(); saveSettings(); };
  SM.audio.getCategoryVol = function (type) { return _categoryVol[type] !== undefined ? _categoryVol[type] : 1.0; };
  SM.audio.isEnabled = function () { return _enabled; };
  SM.audio.setEnabled = function (bool) { _enabled = !!bool; _applyVolumeToAll(); saveSettings(); };
  SM.audio.getEffectiveVolume = function (type) { return getEffectiveVolume(type); };

  // ==================================================================
  //  播放管理
  // ==================================================================
  var _audioList = new Map();
  var _cleanupTimer = null;

  SM.audio.play = function (type, url, params) {
    if (!url) return null;
    params = params || {};

    if (_audioList.has(url)) {
      var existing = _audioList.get(url);
      if (!existing.unusable) {
        existing.dirty = false;
        existing.unusable = false;
        existing.volume = assignIfNotNull(params.volume, existing.volume);
        existing.pitch  = assignIfNotNull(params.pitch, existing.pitch);
        existing.loop   = assignIfNotNull(params.loop, existing.loop);
        existing.loopStart = assignIfNotNull(params.loopStart, existing.loopStart);
        if (existing.initialized) { existing.finalize(); }
        return existing;
      }
      existing._stop();
      _audioList.delete(url);
    }

    var player = new HTMLAudioPlayer(type, url, params);
    _audioList.set(url, player);
    return player;
  };

  SM.audio.stop = function (url) {
    if (!url || !_audioList.has(url)) return;
    _audioList.get(url).markForRemoval();
  };

  SM.audio.stopAll = function () {
    _audioList.forEach(function (player) { player.markForRemoval(); });
  };

  SM.audio.stopCategory = function (type) {
    _audioList.forEach(function (player) {
      if (player.type === type) { player.markForRemoval(); }
    });
  };

  function _startCleanupLoop() {
    if (_cleanupTimer) return;
    _cleanupTimer = setInterval(function () {
      _audioList.forEach(function (player, url) {
        if (player.dirty && !player.fadeTimer && !player.fadePitchTimer) {
          player._stop();
          _audioList.delete(url);
        }
      });
    }, 1000);
  }

  // ==================================================================
  //  设置持久化
  // ==================================================================
  var SETTINGS_KEY = 'susato_audio_settings';

  function loadSettings() {
    try {
      var raw = window.localStorage.getItem(SETTINGS_KEY);
      if (!raw) return;
      var data = JSON.parse(raw);
      if (typeof data.enabled === 'boolean') _enabled = data.enabled;
      if (data.masterVol !== undefined) _masterVol = clamp(data.masterVol, 0, 1);
      if (data.categoryVol) {
        if (typeof data.categoryVol.music === 'number')    _categoryVol[AT.MUSIC]    = clamp(data.categoryVol.music, 0, 1);
        if (typeof data.categoryVol.ambience === 'number') _categoryVol[AT.AMBIENCE] = clamp(data.categoryVol.ambience, 0, 1);
        if (typeof data.categoryVol.sfx === 'number')      _categoryVol[AT.SFX]      = clamp(data.categoryVol.sfx, 0, 1);
      }
    } catch (e) { console.warn('[SM.audio] 设置加载失败:', e); }
  }

  function saveSettings() {
    try {
      window.localStorage.setItem(SETTINGS_KEY, JSON.stringify({
        enabled: _enabled,
        masterVol: _masterVol,
        categoryVol: {
          music: _categoryVol[AT.MUSIC],
          ambience: _categoryVol[AT.AMBIENCE],
          sfx: _categoryVol[AT.SFX]
        }
      }));
    } catch (e) { console.warn('[SM.audio] 设置保存失败:', e); }
  }

  // ==================================================================
  //  初始化 + 模块注册
  // ==================================================================
  SM.audio._init = function () {
    loadSettings();
    _startCleanupLoop();
  };

  if (typeof SM.modules === 'object' && typeof SM.modules.register === 'function') {
    SM.modules.register('audio-core', function () {
      SM.audio._init();
      return SM.audio;
    }, { deps: ['susato-core'], phase: 'preInit' });
  }

  SM.audio._init();
})();
