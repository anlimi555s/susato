// ==================================================================
//  state-bar v1.0 -- 双元素 lag-fill 动画状态条
//  吸收 Cheat Extended CE_EnemyState animateFillLag:
//  lagDiv(背景滞后层) + fillDiv(前景平滑层) 双元素动画，
//  实现扣血时旧值滞留、恢复时新值预览的视觉反馈。
//
//  API:
//    SM.ui.stateBar(container, bars)
//      bars: [{ label, value, max, color, key?, debug? }]
//      label:  显示文本 (string)
//      value:  当前值 (number)
//      max:    最大值 (number, 用于计算百分比)
//      color:  颜色 (string 如 '#e74c3c' 或 function(value,percent) 返回颜色)
//      key:    标识 (string, 用于跨 passage 动画记忆, 可选)
//      debug:  是否显示数值 (boolean, 默认 false)
//    SM.ui.stateBar.resetKey(key)  -- 清除指定 key 的动画记忆
//    SM.ui.stateBar.resetAll()     -- 清除全部动画记忆
//
//  依赖: 纯 CSS + DOM, 无框架依赖
//  消费方: 隐都潜流 (战斗UI), 任何需要状态条的模块
// ==================================================================
(function () {
  'use strict';

  if (window.SusatoModel && window.SusatoModel.moduleOff && window.SusatoModel.moduleOff('state-bar')) return;

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (SM.ui && SM.ui._stateBarV1) return;

  // 动画记忆: key -> lastPercent
  var _memory = {};
  // 是否首次渲染 (用于入场动画)
  var _initialized = false;

  // 注入 CSS (一次性)
  var _cssInjected = false;
  function _injectCSS() {
    if (_cssInjected) return;
    _cssInjected = true;
    var style = document.createElement('style');
    style.textContent =
      '.sm-state-bar {' +
        'display:flex; flex-direction:column; gap:4px;' +
        'padding:4px 0;' +
      '}' +
      '.sm-state-bar-row {' +
        'display:flex; align-items:center; gap:6px;' +
        'font-size:0.82rem;' +
      '}' +
      '.sm-state-bar-label {' +
        'min-width:50px; color:var(--stat-label,#aaa);' +
      '}' +
      '.sm-state-bar-track {' +
        'flex:1; height:10px; border-radius:5px;' +
        'background:rgba(255,255,255,0.08);' +
        'position:relative; overflow:hidden;' +
      '}' +
      '.sm-state-bar-fill {' +
        'position:absolute; top:0; left:0; height:100%;' +
        'border-radius:5px;' +
        'transition: width 0.6s cubic-bezier(0.25,0.8,0.25,1.2);' +
      '}' +
      '.sm-state-bar-lag {' +
        'position:absolute; top:0; left:0; height:100%;' +
        'border-radius:5px; opacity:0.35;' +
        'transition: width 1.2s ease-out;' +
      '}' +
      '.sm-state-bar-fill.shine {' +
        'animation: sm-bar-shine 1.5s ease-in-out infinite;' +
      '}' +
      '.sm-state-bar-fill.pulse {' +
        'animation: sm-bar-pulse 0.6s ease-in-out infinite;' +
      '}' +
      '.sm-state-bar-debug {' +
        'font-size:0.7rem; color:#666; min-width:70px; text-align:right;' +
      '}' +
      '@keyframes sm-bar-shine {' +
        '50% { filter: brightness(1.5); }' +
      '}' +
      '@keyframes sm-bar-pulse {' +
        '50% { filter: brightness(2); transform: scaleY(1.3); }' +
      '}';
    document.head.appendChild(style);
  }

  // 计算颜色 (支持 string 和 function)
  function _resolveColor(colorDef, value, percent) {
    if (typeof colorDef === 'function') {
      try { return colorDef(value, percent); } catch (e) { return '#888'; }
    }
    return colorDef || '#888';
  }

  // 计算视觉等级 (用于特效)
  function _visualLevel(percent, thresholds) {
    // thresholds: [{lt:30, level:1}, {lt:10, level:2}]
    var level = 0;
    for (var i = 0; i < thresholds.length; i++) {
      var t = thresholds[i];
      if (t.gt !== undefined) {
        if (percent > t.gt && level < t.level) level = t.level;
      }
      if (t.lt !== undefined) {
        if (percent < t.lt && t.level > level) level = t.level;
      }
    }
    return level;
  }

  // 核心: 双元素 lag-fill 动画
  function _animate(trackEl, fillEl, key, percent, color) {
    var lastPercent = _memory[key];
    var isFirst = !_initialized || lastPercent === undefined;

    if (isFirst) {
      lastPercent = 0;
    }

    // 清理旧 lag
    var oldLag = trackEl.querySelector('.sm-state-bar-lag');
    if (oldLag) oldLag.remove();

    var lagEl = document.createElement('div');
    lagEl.className = 'sm-state-bar-lag';
    lagEl.style.background = color;

    fillEl.style.background = color;

    if (isFirst) {
      // 入场: 从 0 开始，lag 先到，fill 延迟到
      fillEl.style.width = '0%';
      lagEl.style.width = '0%';
      trackEl.appendChild(lagEl);
      trackEl.appendChild(fillEl);

      requestAnimationFrame(function () {
        requestAnimationFrame(function () {
          lagEl.style.width = percent + '%';
          setTimeout(function () {
            fillEl.style.width = percent + '%';
            _memory[key] = percent;
          }, 400);
        });
      });
      return;
    }

    // 已有记忆: fill 从旧值开始，lag 取较大值
    fillEl.style.width = lastPercent + '%';
    lagEl.style.width = Math.max(lastPercent, percent) + '%';

    trackEl.appendChild(lagEl);
    trackEl.appendChild(fillEl);

    requestAnimationFrame(function () {
      requestAnimationFrame(function () {
        fillEl.style.width = percent + '%';
        lagEl.style.width = percent + '%';
        _memory[key] = percent;
      });
    });
  }

  SM.ui = SM.ui || {};
  SM.ui._stateBarV1 = true;

  SM.ui.stateBar = function (containerEl, bars) {
    if (!containerEl || !Array.isArray(bars) || bars.length === 0) return;
    _injectCSS();

    var container = document.createElement('div');
    container.className = 'sm-state-bar';

    for (var i = 0; i < bars.length; i++) {
      var bar = bars[i];
      var value = Math.max(0, Math.round(bar.value || 0));
      var max = Math.max(1, Math.round(bar.max || 100));
      var percent = Math.min(100, Math.round((value / max) * 100));
      var color = _resolveColor(bar.color, value, percent);

      var row = document.createElement('div');
      row.className = 'sm-state-bar-row';

      // 标签
      var label = document.createElement('span');
      label.className = 'sm-state-bar-label';
      label.textContent = bar.label || '';
      row.appendChild(label);

      // 轨道
      var track = document.createElement('div');
      track.className = 'sm-state-bar-track';

      // 填充
      var fill = document.createElement('div');
      fill.className = 'sm-state-bar-fill';

      // 特效等级 (shine=低危闪烁, pulse=高危脉动)
      if (bar.thresholds) {
        var level = _visualLevel(percent, bar.thresholds);
        if (level >= 1) fill.classList.add('shine');
        if (level >= 2) fill.classList.add('pulse');
      }

      // 动画
      var key = bar.key || ('bar-' + i);
      _animate(track, fill, key, percent, color);

      row.appendChild(track);

      // 数值调试
      if (bar.debug) {
        var debugEl = document.createElement('span');
        debugEl.className = 'sm-state-bar-debug';
        debugEl.textContent = value + '/' + max;
        row.appendChild(debugEl);
      }

      container.appendChild(row);
    }

    containerEl.appendChild(container);
    _initialized = true;
  };

  SM.ui.stateBar.resetKey = function (key) {
    delete _memory[key];
  };

  SM.ui.stateBar.resetAll = function () {
    _memory = {};
    _initialized = false;
  };
})();
