// ==================================================================
// 时装系统（框架版）—— 基于 SusatoModel.renderer.onCompile
//
// 渲染走 susato-core 的 onCompile 钩子（抽象层），不直接硬刚本体 compile。
// susato-core 由主 mod 提供且带 load-once 守卫（单例），无双份加载问题。
// 保留套装存取（save/load/modify，纯 twee）。
//
// 我不想修复了，要是能看到大概率是被独立出来了。
// 那你该遭罪啦，哈哈哈哈O(∩_∩)O
// ==================================================================
(function () {
  'use strict';

  window.SusatoModel = window.SusatoModel || {};
  var SL = window.SusatoModel.clothingLayers = window.SusatoModel.clothingLayers || {};

  // 全部槽位（现在可以正确渲染所有子图层了）
  var ALL_SLOTS = [
    'upper', 'lower', 'under_upper', 'under_lower',
    'over_upper', 'over_lower', 'head', 'over_head',
    'face', 'neck', 'hands', 'handheld', 'legs', 'feet'
  ];

  // ========== 初始化 ==========
  function init() {
    if (typeof V === 'undefined') return;
    if (!V.worn_layers) V.worn_layers = {};
    ALL_SLOTS.forEach(function (s) {
      if (!V.worn_layers[s]) V.worn_layers[s] = [];
    });
  }

  // ========== API ==========
  SL.removeAll = function () {
    if (!V.worn_layers) return;
    Object.keys(V.worn_layers).forEach(function (slot) {
      var layers = V.worn_layers[slot];
      if (!layers || !layers.length) return;
      for (var i = layers.length - 1; i >= 0; i--) {
        if (layers[i] && layers[i].index > 0) {
          if (!V.wardrobe[slot]) V.wardrobe[slot] = [];
          V.wardrobe[slot].push(layers[i]);
        }
      }
      V.worn_layers[slot] = [];
    });
  };

  // 直接按位置删——原物品推回衣柜
  SL.removeAt = function (slot, pos) {
    try {
      var layers = V.worn_layers[slot];
      if (!layers || pos < 0 || pos >= layers.length) return null;
      var item = layers[pos];
      // 直接用 V.wardrobe 而非 selectWardrobe()，和参考 mod 一致
      if (!V.wardrobe[slot]) V.wardrobe[slot] = [];
      V.wardrobe[slot].push(item);
      layers.splice(pos, 1);
      return item;
    } catch (e) { return null; }
  };

  SL.togglePrimaryHidden = function (slot) {
    try {
      var item = V.worn[slot];
      if (!item || item.index === 0) return;
      item._hidden = !item._hidden;
    } catch (e) {}
  };

  SL.toggleHidden = function (slot, pos) {
    try {
      var layers = V.worn_layers[slot];
      if (!layers || pos < 0 || pos >= layers.length) return;
      layers[pos]._hidden = !layers[pos]._hidden;
    } catch (e) {}
  };

  SL.getCount = function (slot) {
    var layers = V.worn_layers && V.worn_layers[slot];
    return layers ? layers.length : 0;
  };

  // 所有槽位叠穿物品总数（供衣柜开关 UI 显示"一键褪光(N)"）
  SL.getTotalCount = function () {
    var n = 0;
    try {
      if (V.worn_layers) Object.keys(V.worn_layers).forEach(function (s) {
        var a = V.worn_layers[s];
        if (Array.isArray(a)) n += a.length;
      });
    } catch (e) {}
    return n;
  };
  // ========== 套装存取 ==========
  // 将当前层栈序列化为 {slot: [name1, name2], ...}，只存物品名
  SL.getStackingOutfit = function () {
    var stacking = {};
    try {
      if (!V.worn_layers) return stacking;
      Object.keys(V.worn_layers).forEach(function (slot) {
        var items = V.worn_layers[slot];
        if (!Array.isArray(items) || items.length === 0) return;
        stacking[slot] = [];
        items.forEach(function (item) {
          if (item && item.name) stacking[slot].push(item.name);
        });
      });
    } catch (e) {}
    return stacking;
  };


  // ========== 深拷贝图层 ==========
  function deepCopyLayer(layer) {
    if (typeof jQuery !== 'undefined') return jQuery.extend(true, {}, layer);
    return JSON.parse(JSON.stringify(layer));
  }

  // ========== 核心：通过 SusatoModel.renderer.onCompile 注入叠穿逻辑 ==========
  // 走抽象层，不直接覆写本体 compile。susato-core 单例（load-once 守卫）保证
  // 钩子注册进唯一实例、由唯一的 compile 包装器执行。
  (function () {
    var SR = SusatoModel && SusatoModel.renderer;
    if (!SR) return; // susato-core 未加载（主 mod 应先提供）

    SR.onCompile(function (layerSpecs, options, model) {
      if (options.lights) return;
      if (options.root === 'img/sex/') return;
      // 只处理主立绘，跳过战斗/NPC/光照等模型
      if (model.name && model.name !== 'main') return;
      if (!V || !V.worn_layers) return;
      if (!V.susato_layering_enabled) return;

      try {
        // 过滤主装备隐藏的槽位
        var visibleSpecs = layerSpecs;
        ALL_SLOTS.forEach(function (s) {
          if (V.worn[s] && V.worn[s]._hidden) {
            visibleSpecs = visibleSpecs.filter(function (l) {
              if (!l || !l.name) return true;
              return l.name !== s && l.name.indexOf(s + '_') !== 0;
            });
          }
        });

        // 建索引（从原始 layerSpecs 构建，确保隐藏主装备后叠穿图层仍能找到模板）
        var specIndex = {};
        for (var i = 0; i < layerSpecs.length; i++) {
          if (layerSpecs[i] && layerSpecs[i].name) {
            specIndex[layerSpecs[i].name] = i;
          }
        }

        var result = visibleSpecs.slice();
        var slots = Object.keys(V.worn_layers);

        for (var si = 0; si < slots.length; si++) {
          var slot = slots[si];
          var items = V.worn_layers[slot];
          if (!Array.isArray(items) || items.length === 0) continue;

          // 收集该槽位的所有子图层名
          var subLayerNames = [];
          for (var k = 0; k < layerSpecs.length; k++) {
            var ls = layerSpecs[k];
            if (!ls || !ls.name) continue;
            var ln = ls.name;
            if (ln === slot || (ln.length > slot.length + 1 && ln.indexOf(slot + '_') === 0)) {
              subLayerNames.push(ln);
            }
          }
          if (subLayerNames.length === 0) continue;

        for (var ii = 0; ii < items.length; ii++) {
          var item = items[ii];
          if (item._hidden) continue;  // 玩家选择不渲染

          // 准备 wornEntry
          var wornEntry;
          try {
            wornEntry = getClothingOptionsItem(slot, item);
          } catch (e) {
            if (!item.setup || !item.setup.variable) {
              item.setup = (setup.clothes[slot] && setup.clothes[slot][item.index]) || {};
            }
            if (typeof item.integrity !== 'string') item.integrity = 'full';
            if (!item.colour) item.colour = 'white';
            var fallback = {};
            fallback[slot] = item;
            wornEntry = fallback;
          }
          if (!wornEntry || !wornEntry[slot]) continue;

          var originalWorn = options.worn[slot];
          var filterKey = 'worn_' + slot;
          var accFilterKey = filterKey + '_acc';
          var originalFilter = options.filters[filterKey];
          var originalAccFilter = options.filters[accFilterKey];

          options.worn[slot] = wornEntry[slot];

          // 主装备锁胸时，层栈物品的 breasts 子图层应隐藏
          var primaryBreastOff = false;
          if (slot === 'upper' || slot === 'under_upper' || slot === 'over_upper') {
            var pw = V.worn[slot];
            if (pw && pw.setup && pw.setup.breast_img !== undefined) {
              var pbi = pw.setup.breast_img;
              if (pbi === 0) {
                primaryBreastOff = true;
              } else if (typeof pbi === 'object') {
                var allNull = true;
                var pbiVals = Object.values(pbi);
                for (var pv = 0; pv < pbiVals.length; pv++) {
                  if (pbiVals[pv] !== null) { allNull = false; break; }
                }
                if (allNull) primaryBreastOff = true;
              }
            }
          }

          // 生成颜色 filter（对主 filter 和 acc filter 各算一次，缓存复用）
          var colourFilter = null;
          var accColourFilter = null;
          if (typeof setClothingFilter === 'function') {
            setClothingFilter(options, slot, options.worn[slot], options.worn[slot].setup, '', 'colour_sidebar', 'colour');
            colourFilter = options.filters[filterKey];
            setClothingFilter(options, slot, options.worn[slot], options.worn[slot].setup, '_acc', 'accessory_colour_sidebar', 'accColour');
            accColourFilter = options.filters[accFilterKey];
          }

          // 遍历该槽位所有子图层
          for (var sl = 0; sl < subLayerNames.length; sl++) {
            var origName = subLayerNames[sl];

            // 主装备锁胸时，跳过 breasts 相关子图层
            if (primaryBreastOff && origName.indexOf('breast') !== -1) continue;

            var specPos = specIndex[origName];
            if (specPos === undefined) continue;

            var templateLayer = layerSpecs[specPos];
            var baseLayer = model.layers[origName];
            if (!baseLayer) continue;

            var newLayer = deepCopyLayer(templateLayer);
            newLayer.name = origName + '_stack_' + (item.variable || ii);
            newLayer.z = (templateLayer.z || 0) + (ii + 1) * 0.01;

            // 清除模板图层的颜色，防止主装备颜色染到叠穿物品
            delete newLayer.blend;
            delete newLayer.blendMode;

            // 调用原图层 showfn 决定可见性，不复用模板的 show 值
            var shouldShow = true;
            if (typeof baseLayer.showfn === 'function') {
              try {
                shouldShow = baseLayer.showfn(options);
              } catch (e) { shouldShow = true; }
            }
            newLayer.show = !!shouldShow;

            // 不显示的图层不保留主装备的 src（可能指向错误图片）
            if (!newLayer.show) {
              newLayer.src = '';
              result.push(newLayer);
              continue;
            }

            // 重置 src，防止 srcfn 不可用时沿用主装备的图
            newLayer.src = '';

            // filtersfn
            if (typeof baseLayer.filtersfn === 'function') {
              newLayer.filters = baseLayer.filtersfn(options);
            }
            // wornfn
            if (typeof baseLayer.wornfn === 'function') {
              newLayer.worn = baseLayer.wornfn(options);
            }
            // srcfn —— 用叠穿物品自己的图；返回空则保持空字符串
            if (typeof baseLayer.srcfn === 'function') {
              var layeredSrc = baseLayer.srcfn(options);
              if (layeredSrc) newLayer.src = layeredSrc;
            }

            // 颜色烘焙：此时 newLayer 已清除模板颜色，只染叠穿物品的颜色
            var isAccLayer = origName.indexOf('_acc') !== -1;
            var cf = isAccLayer ? accColourFilter : colourFilter;
            if (cf && cf.blend && typeof Renderer !== 'undefined' && Renderer.mergeLayerData) {
              Renderer.mergeLayerData(newLayer, cf, true);
            }

            result.push(newLayer);
          }

          // 还原
          options.worn[slot] = originalWorn;
          options.filters[filterKey] = originalFilter;
          options.filters[accFilterKey] = originalAccFilter;
        }
      }

        return result;
      } catch (e) {
        // 任何异常都回退到原版渲染
        return;
      }
    });
  })();

  // ========== 手动存取：衣柜 UI 按钮触发 ==========
  // 不再自动检测 outfit 切换。玩家手动点"保存/载入"。
  // 从 stacking 数据恢复层栈（保留供外部调用）
  SL.restoreStacking = function (data) {
    try {
      if (!V.wardrobe) V.wardrobe = {};
      data = data || {};
      ALL_SLOTS.forEach(function (s) {
        if (V.worn_layers[s] && V.worn_layers[s].length) {
          if (!V.wardrobe[s]) V.wardrobe[s] = [];
          for (var i = V.worn_layers[s].length - 1; i >= 0; i--) {
            V.wardrobe[s].push(V.worn_layers[s][i]);
          }
        }
        V.worn_layers[s] = [];
      });
      Object.keys(data).forEach(function (slot) {
        if (slot === '_primary') return;
        var entries = data[slot];
        if (!Array.isArray(entries) || !entries.length) return;
        if (!V.wardrobe[slot]) V.wardrobe[slot] = [];
        for (var i = 0; i < entries.length; i++) {
          var entry = entries[i];
          var itemName = typeof entry === 'string' ? entry : entry.n;
          var hidden = entry.h || false;
          var idx = -1;
          for (var j = 0; j < V.wardrobe[slot].length; j++) {
            if (V.wardrobe[slot][j] && V.wardrobe[slot][j].name === itemName) { idx = j; break; }
          }
          if (idx >= 0) {
            if (!V.worn_layers[slot]) V.worn_layers[slot] = [];
            var item = clone(V.wardrobe[slot][idx]);
            if (hidden) item._hidden = true;
            V.worn_layers[slot].push(item);
            V.wardrobe[slot].splice(idx, 1);
          }
        }
      });
      if (data._primary) {
        Object.keys(data._primary).forEach(function (slot) {
          if (V.worn[slot]) V.worn[slot]._hidden = true;
        });
      }
    } catch (e) {}
  };


  // 数据初始化。compile 钩子已在上方通过 SR.onCompile 注册。
  if (typeof $ !== 'undefined') {
    $(document).one(':storyready', function () { init(); });
  } else {
    init();
  }
})();
