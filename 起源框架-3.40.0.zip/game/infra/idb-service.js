// ==================================================================
//  idb-service v1.0 -- IndexedDB 通用存储封装
//  替代各处手写 localStorage，提供 store 注册 + transaction 封装。
//
//  API:
//    SM.idb.registerStore(name, opts)  -- 注册 object store (opts.keyPath, opts.indexes)
//    SM.idb.open()                     -- 打开数据库 (返回 Promise)
//    SM.idb.put(store, value)          -- 写入 (自动序列化)
//    SM.idb.get(store, key)            -- 读取 (自动反序列化)
//    SM.idb.delete(store, key)         -- 删除
//    SM.idb.getAll(store)              -- 全量读取
//    SM.idb.transaction(stores, mode, fn) -- 事务封装
//
//  依赖: 无外部依赖。浏览器 IndexedDB API。
//  消费方: 起源框架各模块需要持久化存储时统一使用。
// ==================================================================
(function () {
  'use strict';

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (SM.idb && SM.idb._inited) return;

  var DB_NAME = 'susato-framework';
  var DB_VERSION = 1;
  var _db = null;
  var _stores = {};       // name -> { keyPath, indexes: [{name, keyPath, unique}] }
  var _openPromise = null;

  function _upgrade(e) {
    var db = e.target.result;
    for (var name in _stores) {
      if (Object.prototype.hasOwnProperty.call(_stores, name)) {
        var cfg = _stores[name];
        var store = db.objectStoreNames.contains(name)
          ? e.target.transaction.objectStore(name)
          : db.createObjectStore(name, { keyPath: cfg.keyPath || 'id' });
        if (cfg.indexes) {
          for (var i = 0; i < cfg.indexes.length; i++) {
            var idx = cfg.indexes[i];
            try { if (!store.indexNames.contains(idx.name)) store.createIndex(idx.name, idx.keyPath || idx.name, { unique: !!idx.unique }); }
            catch (ignore) {}
          }
        }
      }
    }
  }

  function _getDB() {
    if (_db) return Promise.resolve(_db);
    if (_openPromise) return _openPromise;
    _openPromise = new Promise(function (resolve, reject) {
      try {
        var req = indexedDB.open(DB_NAME, DB_VERSION);
        req.onupgradeneeded = _upgrade;
        req.onsuccess = function (e) {
          _db = e.target.result;
          _db.onclose = function () { _db = null; };
          resolve(_db);
        };
        req.onerror = function () { reject(new Error('IndexedDB open failed')); };
        req.onblocked = function () { reject(new Error('IndexedDB blocked')); };
      } catch (e) { reject(e); }
    });
    return _openPromise;
  }

  SM.idb = {
    _inited: true,

    registerStore: function (name, opts) {
      if (!name) return false;
      _stores[name] = opts || {};
      // 版本递增以触发 onupgradeneeded
      DB_VERSION++;
      _db = null; // 强制重连
      _openPromise = null;
      return true;
    },

    open: function () { return _getDB(); },

    put: function (storeName, value) {
      return _getDB().then(function (db) {
        return new Promise(function (resolve, reject) {
          try {
            var tx = db.transaction(storeName, 'readwrite');
            var store = tx.objectStore(storeName);
            var req = store.put(value);
            req.onsuccess = function () { resolve(req.result); };
            req.onerror = function () { reject(req.error); };
          } catch (e) { reject(e); }
        });
      });
    },

    get: function (storeName, key) {
      return _getDB().then(function (db) {
        return new Promise(function (resolve, reject) {
          try {
            var tx = db.transaction(storeName, 'readonly');
            var store = tx.objectStore(storeName);
            var req = store.get(key);
            req.onsuccess = function () { resolve(req.result); };
            req.onerror = function () { reject(req.error); };
          } catch (e) { reject(e); }
        });
      });
    },

    delete: function (storeName, key) {
      return _getDB().then(function (db) {
        return new Promise(function (resolve, reject) {
          try {
            var tx = db.transaction(storeName, 'readwrite');
            var store = tx.objectStore(storeName);
            var req = store.delete(key);
            req.onsuccess = function () { resolve(); };
            req.onerror = function () { reject(req.error); };
          } catch (e) { reject(e); }
        });
      });
    },

    getAll: function (storeName) {
      return _getDB().then(function (db) {
        return new Promise(function (resolve, reject) {
          try {
            var tx = db.transaction(storeName, 'readonly');
            var store = tx.objectStore(storeName);
            var req = store.getAll();
            req.onsuccess = function () { resolve(req.result || []); };
            req.onerror = function () { reject(req.error); };
          } catch (e) { reject(e); }
        });
      });
    },

    transaction: function (storeNames, mode, fn) {
      return _getDB().then(function (db) {
        return new Promise(function (resolve, reject) {
          try {
            var tx = db.transaction(storeNames, mode || 'readwrite');
            var result = fn(tx);
            tx.oncomplete = function () { resolve(result); };
            tx.onerror = function () { reject(tx.error); };
          } catch (e) { reject(e); }
        });
      });
    }
  };

  // 初始化默认 store
  SM.idb.registerStore('config', { keyPath: 'id' });
})();
