// ui-addon.js — UI 图标 / 改脸 热切换框架 v2
// 统一导入: 玩家打一个 zip, 里面 face/ 放改脸图, icon/ 放 UI 图标,
// JSZip 解包 → IndexedDB 存 Blob → 内存 blob URL map → 分别走对应管线。
//
// zip 结构约定:
//   face/                → 改脸 (走 model-addon 的 onCompile 管线)
//     └── img/           → mirror 本体 img/ 结构
//         └── face/...
//   icon/                → UI 图标 (走 <<icon>> 宏拦截)
//     └── img/
//         ├── ui/        → mirror 本体 img/ui/
//         └── misc/icon/ → mirror 本体 img/misc/icon/
//
// 错误提示:
//   - 无 face/ 和 icon/ → "未识别到 face/ 或 icon/ 目录, 请检查 zip 结构"
//   - 有目录但无图片 → "face/ 下无图片文件" / "icon/ 下无图片文件"
//   - JSZip 不存在 → "JSZip 不可用"
//   - IndexedDB 不可用 → "IndexedDB 不可用"
//
// API:
//   UI.importZip(file, cb)          // cb(err, result)  result = {face, icon}
//   UI.resolveFace(relPath)         // → blobUrl 或 null (供 model-addon 调用)
//   UI.resolveIcon(relPath)         // → blobUrl 或 null
//   UI.select(id)                   // '' = 默认
//   UI.list()                       // [{id, name, type, count}]
//   UI.current()                    // 当前 id
//   UI.deletePack(id)
//   UI.render()                     // 面板

(function () {
  'use strict';
  if (window.SusatoModel && window.SusatoModel.moduleOff && window.SusatoModel.moduleOff('ui-addon')) return;
  try {

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (SM.uiIcons) return;
  var UI = SM.uiIcons = {};

  var SEL_KEY = 'susato_ui_icons_selected';
  var MANIFEST_KEY = 'susato_ui_manifest';
  var IDB_NAME = 'susato_ui_packs';
  var IDB_VER = 1;

  var _registry = {};       // id → {id, name, type:'face'|'icon', count}
  var _order = [];
  var _blobIcons = {};      // relPath → blobUrl  (UI 图标)
  var _blobFaces = {};      // relPath → blobUrl  (改脸)
  var _selected = '';
  var _loaded = false;

  function _idbOpen(cb) {
    if (typeof indexedDB === 'undefined') { cb(null); return; }
    try {
      var r = indexedDB.open(IDB_NAME, IDB_VER);
      r.onupgradeneeded = function () {
        if (!r.result.objectStoreNames.contains('files')) r.result.createObjectStore('files');
      };
      r.onsuccess = function () { cb(r.result); };
      r.onerror = function () { cb(null); };
    } catch (e) { cb(null); }
  }

  function _loadManifest() {
    try { var v = localStorage.getItem(MANIFEST_KEY); return v ? JSON.parse(v) : { packs: [] }; } catch (e) { return { packs: [] }; }
  }
  function _saveManifest(m) {
    try { localStorage.setItem(MANIFEST_KEY, JSON.stringify(m)); } catch (e) {}
  }

  // ========== 载入包到内存 ==========
  function _loadPackIntoMemory(id, cb) {
    _clearBlobs();
    _idbOpen(function (db) {
      if (!db) { _loaded = true; if (cb) cb(false); return; }
      try {
        var tx = db.transaction('files', 'readonly');
        var store = tx.objectStore('files');
        var prefix = id + '/';
        var range = IDBKeyRange.bound(prefix, prefix + '￿');
        var req = store.openCursor(range);
        req.onsuccess = function () {
          var cursor = req.result;
          if (cursor) {
            var fullKey = cursor.key;
            var relPath = fullKey.slice(prefix.length);
            var blobUrl = URL.createObjectURL(cursor.value);
            // 按前缀路由到对应 map
            if (relPath.indexOf('face/') === 0) {
              _blobFaces[relPath] = blobUrl;
            } else {
              _blobIcons[relPath] = blobUrl;
            }
            cursor.continue();
          } else {
            db.close(); _loaded = true;
            if (cb) cb(true);
          }
        };
        req.onerror = function () { db.close(); _loaded = true; if (cb) cb(false); };
      } catch (e) { db.close(); _loaded = true; if (cb) cb(false); }
    });
  }

  function _clearBlobs() {
    for (var k in _blobIcons) { if (Object.prototype.hasOwnProperty.call(_blobIcons, k)) try { URL.revokeObjectURL(_blobIcons[k]); } catch (e) {} }
    for (var k in _blobFaces) { if (Object.prototype.hasOwnProperty.call(_blobFaces, k)) try { URL.revokeObjectURL(_blobFaces[k]); } catch (e) {} }
    _blobIcons = {}; _blobFaces = {};
  }

  // ========== 公开 API: resolveFace / resolveIcon ==========
  UI.resolveFace = function (relPath) { return _blobFaces[relPath] || null; };
  UI.resolveIcon = function (relPath) { return _blobIcons[relPath] || null; };

  // ========== 导入 zip ==========
  UI.importZip = function (file, cb) {
    if (typeof JSZip === 'undefined') { if (cb) cb('JSZip 不可用'); return; }
    if (!file) { if (cb) cb('未选择文件'); return; }

    JSZip.loadAsync(file).then(function (zip) {
      var faceEntries = [], iconEntries = [];

      zip.forEach(function (relPath, entry) {
        if (entry.dir) return;
        if (!/\.(png|jpg|jpeg|gif|svg|webp)$/i.test(relPath)) return;

        if (relPath.indexOf('face/') === 0) {
          faceEntries.push({ path: relPath, entry: entry });
        } else if (relPath.indexOf('icon/') === 0) {
          iconEntries.push({ path: relPath, entry: entry });
        }
        // 其他路径静默忽略
      });

      // 校验
      if (!faceEntries.length && !iconEntries.length) {
        if (cb) cb('未识别到 face/ 或 icon/ 目录。\n\nzip 结构应为:\n  face/img/...  (改脸)\n  icon/img/...  (UI图标)');
        return;
      }

      var packId = _guessPackName(faceEntries.concat(iconEntries));
      var faceCount = faceEntries.length;
      var iconCount = iconEntries.length;
      var total = faceCount + iconCount;
      var errors = [];

      if (!faceCount) errors.push('face/ 下无图片文件');
      if (!iconCount) errors.push('icon/ 下无图片文件');

      // 写入 IDB
      _idbOpen(function (db) {
        if (!db) { if (cb) cb('IndexedDB 不可用'); return; }
        try {
          var tx = db.transaction('files', 'readwrite');
          var store = tx.objectStore('files');
          var done = 0;
          var allEntries = faceEntries.concat(iconEntries);

          for (var i = 0; i < allEntries.length; i++) {
            (function (e) {
              var relPath = _extractRel(e.path);
              // 加类型前缀以区分 face/icon
              var key = packId + '/' + relPath;
              e.entry.async('blob').then(function (blob) {
                store.put(blob, key);
                done++;
              });
            })(allEntries[i]);
          }

          tx.oncomplete = function () {
            db.close();
            // 注册包
            var reg = _registry[packId];
            if (!reg) {
              reg = { id: packId, name: packId, type: 'both', faceCount: 0, iconCount: 0 };
              _registry[packId] = reg;
              _order.push(packId);
            }
            reg.faceCount = (reg.faceCount || 0) + faceCount;
            reg.iconCount = (reg.iconCount || 0) + iconCount;

            // 更新清单
            var m = _loadManifest();
            var found = false;
            for (var mi = 0; mi < m.packs.length; mi++) {
              if (m.packs[mi].id === packId) {
                m.packs[mi].faceCount = reg.faceCount;
                m.packs[mi].iconCount = reg.iconCount;
                found = true; break;
              }
            }
            if (!found) m.packs.push({ id: packId, name: packId, faceCount: reg.faceCount, iconCount: reg.iconCount });
            _saveManifest(m);

            // 载入内存
            _loadPackIntoMemory(packId, function (ok) {
              // 向 model-addon 注册 (face 图片走 Canvas 管线)
              if (faceCount) {
                try {
                  if (SM.model && SM.model.registerBlobPack) {
                    SM.model.registerBlobPack(packId, packId, UI.resolveFace);
                  }
                } catch (e) {}
              }
              // 通知 model-addon 重绘
              if (SM.model && typeof SM.model.select === 'function') {
                try { SM.model.select(SM.model.current()); } catch (e) {}
              }
              if (cb) {
                var msg = '导入完成: ' + packId;
                if (faceCount) msg += '\n改脸: ' + faceCount + ' 文件';
                if (iconCount) msg += '\nUI 图标: ' + iconCount + ' 文件';
                if (errors.length) msg += '\n\n警告: ' + errors.join(', ');
                cb(null, { id: packId, name: packId, faceCount: faceCount, iconCount: iconCount, errors: errors });
              }
            });
          };
          tx.onerror = function () { db.close(); if (cb) cb('IDB 写入失败'); };
        } catch (e) { db.close(); if (cb) cb(e.message); }
      });
    }).catch(function (e) { if (cb) cb('zip 解析失败: ' + (e.message || e)); });
  };

  function _guessPackName(entries) {
    if (!entries.length) return '未命名';
    var first = entries[0].path;
    // 去掉 face/ 或 icon/ 前缀取第一段目录名
    var s = first;
    if (s.indexOf('face/') === 0) s = s.slice(5);
    else if (s.indexOf('icon/') === 0) s = s.slice(5);
    var slash = s.indexOf('/');
    if (slash > 0) {
      var prefix = s.slice(0, slash);
      if (prefix && prefix !== 'img') return prefix;
    }
    return '图标包';
  }

  function _extractRel(fullPath) {
    // face/img/face/default/eyes.png → face/face/default/eyes.png
    // icon/img/ui/science.png     → ui/science.png
    var s = fullPath;
    if (s.indexOf('face/') === 0) {
      s = s.slice(5);
      if (s.indexOf('img/') === 0) s = s.slice(4);
      return 'face/' + s;
    }
    if (s.indexOf('icon/') === 0) {
      s = s.slice(5);
      if (s.indexOf('img/') === 0) s = s.slice(4);
      return s;
    }
    return s;
  }

  // ========== 公开 API (不变) ==========
  UI.select = function (id) {
    if (id) { localStorage.setItem(SEL_KEY, id); }
    else { localStorage.removeItem(SEL_KEY); _clearBlobs(); }
    _selected = id || '';
    // 同步 model-addon: face 走 Canvas, icon 走 <<icon>>
    if (SM.model && SM.model.select) {
      try {
        var reg = _registry[id];
        if (reg && reg.faceCount) SM.model.select(id); else SM.model.select('');
      } catch (e) {}
    }
    try { if (typeof Engine !== 'undefined') { Engine.restart(); return; } } catch (e) {}
    try { location.reload(); } catch (e) {}
  };

  UI.list = function () {
    var r = [];
    for (var i = 0; i < _order.length; i++) {
      var p = _registry[_order[i]];
      r.push({ id: p.id, name: p.name, faceCount: p.faceCount || 0, iconCount: p.iconCount || 0 });
    }
    return r;
  };

  UI.current = function () { return _selected || ''; };
  UI.isLoaded = function () { return _loaded; };

  // ========== <<icon>> 宏拦截 ==========
  function _rewriteArgs(args) {
    for (var i = 0; i < args.length; i++) {
      if (typeof args[i] !== 'string') continue;
      if (/^(https?:|data:|blob:|\/)/.test(args[i])) continue;
      var key;
      if (args[i].indexOf('/') >= 0) {
        key = 'misc/icon/' + args[i];
      } else {
        key = 'ui/' + args[i];
      }
      var blobUrl = _blobIcons[key];
      if (blobUrl) args[i] = blobUrl;
    }
  }

  function _tryPatchMacro() {
    if (!_selected) return;
    if (typeof Macro === 'undefined') return;
    try {
      var def = Macro.get('icon');
      if (!def || def._susatoUIPatched) return;
      var orig = def.handler;
      if (typeof orig !== 'function') { if (typeof def === 'function') orig = def; else return; }
      Macro.delete('icon');
      Macro.add('icon', {
        handler: function () { _rewriteArgs(this.args); return orig.apply(this, arguments); },
        _susatoUIPatched: true
      });
      console.log('[ui-addon] <<icon>> 已拦截, 包:', _selected, Object.keys(_blobIcons).length + '图标');
    } catch (e) { console.warn('[ui-addon] 宏拦截失败:', e); }
  }

  // ========== 删除 ==========
  UI.deletePack = function (id) {
    if (!id) return;
    if (_selected === id) { UI.select(''); }
    // 从 model-addon 注销
    try { if (SM.model) { SM.model.select(''); delete SM.model._registry[id]; if (SM.model._order) SM.model._order.splice(SM.model._order.indexOf(id), 1); } } catch (e) {}
    delete _registry[id];
    _order.splice(_order.indexOf(id), 1);
    var m = _loadManifest();
    m.packs = m.packs.filter(function (p) { return p.id !== id; });
    _saveManifest(m);
    _idbOpen(function (db) {
      if (!db) return;
      try {
        var tx = db.transaction('files', 'readwrite');
        var store = tx.objectStore('files');
        var range = IDBKeyRange.bound(id + '/', id + '/￿');
        var req = store.openCursor(range);
        req.onsuccess = function () {
          var cursor = req.result;
          if (cursor) { cursor.delete(); cursor.continue(); } else db.close();
        };
      } catch (e) { db.close(); }
    });
  };

  // ========== 面板 ==========
  UI.render = function () {
    var host = document.getElementById('susato-ui-icons-list');
    if (!host) return;
    host.innerHTML = '';

    var current = UI.current();
    var list = UI.list();

    // 导入按钮
    var importRow = document.createElement('div');
    importRow.style.cssText = 'margin-bottom:8px;';
    var importBtn = document.createElement('button');
    importBtn.textContent = '导入 zip (改脸 + 图标)';
    importBtn.style.cssText = 'font-size:12px;padding:5px 14px;background:var(--850);border:1px solid var(--gold);color:var(--gold);border-radius:4px;cursor:pointer;width:100%;';
    importBtn.onclick = function () {
      var input = document.createElement('input');
      input.type = 'file'; input.accept = '.zip';
      input.onchange = function () {
        var f = input.files && input.files[0];
        if (!f) return;
        importBtn.textContent = '导入中...'; importBtn.disabled = true;
        UI.importZip(f, function (err, result) {
          importBtn.textContent = '导入 zip (改脸 + 图标)'; importBtn.disabled = false;
          if (err) { alert('导入失败\n\n' + err); UI.render(); return; }
          if (result.errors && result.errors.length) {
            alert('导入完成 (有警告)\n\n' + result.errors.join('\n'));
          }
          UI.select(result.id);
        });
      };
      input.click();
    };
    importRow.appendChild(importBtn);
    host.appendChild(importRow);

    // 默认
    var dRow = document.createElement('div');
    dRow.style.cssText = 'display:flex;align-items:center;justify-content:space-between;padding:6px 8px;margin:2px 0;border-radius:4px;' + (!current ? 'border:1px solid var(--gold);background:var(--850);' : '');
    dRow.appendChild(_el('span', '默认（起源美化）', 'font-size:13px;'));
    if (current) {
      var dBtn = _btn('切换', function () { UI.select(''); });
      dRow.appendChild(dBtn);
    } else {
      dRow.appendChild(_el('span', '当前', 'font-size:10px;color:var(--gold);'));
    }
    host.appendChild(dRow);

    if (!list.length) {
      var empty = _el('div', '暂无导入包。点上方按钮导入一个 zip。\n\nzip 结构: face/img/...  (改脸)\n          icon/img/...  (UI图标)', 'font-size:11px;color:var(--500);padding:8px;white-space:pre-line;');
      host.appendChild(empty);
      return;
    }

    for (var li = 0; li < list.length; li++) {
      (function (pack) {
        var active = pack.id === current;
        var row = document.createElement('div');
        row.style.cssText = 'display:flex;align-items:center;justify-content:space-between;padding:6px 8px;margin:2px 0;border-radius:4px;' + (active ? 'border:1px solid var(--gold);background:var(--850);' : '');
        var info = document.createElement('div');
        info.style.cssText = 'display:flex;flex-direction:column;flex:1;';
        info.appendChild(_el('span', pack.name, 'font-size:13px;'));
        var tags = [];
        if (pack.faceCount) tags.push('改脸:' + pack.faceCount);
        if (pack.iconCount) tags.push('图标:' + pack.iconCount);
        info.appendChild(_el('span', tags.join('  '), 'font-size:10px;color:var(--500);'));
        row.appendChild(info);
        var right = document.createElement('div');
        right.style.cssText = 'display:flex;align-items:center;gap:4px;';
        if (active) {
          right.appendChild(_el('span', '当前', 'font-size:10px;color:var(--gold);'));
        } else {
          right.appendChild(_btn('切换', function () { UI.select(pack.id); }));
        }
        var xBtn = document.createElement('span');
        xBtn.textContent = 'x'; xBtn.title = '删除';
        xBtn.style.cssText = 'font-size:11px;color:var(--600);cursor:pointer;padding:0 4px;';
        xBtn.onclick = function (ev) { ev.stopPropagation(); if (confirm('删除 "' + pack.name + '"？')) { UI.deletePack(pack.id); UI.render(); } };
        right.appendChild(xBtn);
        row.appendChild(right);
        host.appendChild(row);
      })(list[li]);
    }
  };

  function _el(tag, text, css) { var e = document.createElement(tag); e.textContent = text; if (css) e.style.cssText = css; return e; }
  function _btn(text, fn) { var b = document.createElement('button'); b.textContent = text; b.style.cssText = 'font-size:11px;padding:2px 10px;background:var(--850);border:1px solid var(--700);color:var(--000);border-radius:3px;cursor:pointer;'; b.onclick = fn; return b; }

  // ========== 启动 ==========
  function _init() {
    var m = _loadManifest();
    if (m.packs) {
      for (var i = 0; i < m.packs.length; i++) {
        var p = m.packs[i];
        if (!p || !p.id) continue;
        _registry[p.id] = { id: p.id, name: p.name || p.id, faceCount: p.faceCount || 0, iconCount: p.iconCount || 0 };
        _order.push(p.id);
      }
    }
    _selected = localStorage.getItem(SEL_KEY) || '';
    if (_selected) {
      _loadPackIntoMemory(_selected, function (ok) {
        if (ok) {
          // 向 model-addon 注册已导入的 face 包
          var reg = _registry[_selected];
          if (reg && reg.faceCount) {
            try { if (SM.model && SM.model.registerBlobPack) SM.model.registerBlobPack(_selected, reg.name, UI.resolveFace); } catch (e) {}
            try { if (SM.model && SM.model.select) SM.model.select(_selected); } catch (e) {}
          }
          console.log('[ui-addon] 包已载入:', _selected, 'face:' + Object.keys(_blobFaces).length, 'icon:' + Object.keys(_blobIcons).length);
        }
      });
    } else { _loaded = true; }
    _tryPatchMacro();
    console.log('[ui-addon] 已加载, ' + _order.length + ' 个包, 当前:', _selected || '默认');
  }

  _init();

  } catch (e) { console.warn('[ui-addon] 初始化异常:', e); }
})();
