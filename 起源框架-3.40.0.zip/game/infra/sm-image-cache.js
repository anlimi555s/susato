// ==================================================================
//  sm-image-cache v1.0 -- Promise 图片缓存与候选链加载
//  吸收自 DoL Plus (game/03-JavaScript/02-Helpers/image-cache.js).
//  缓存 + 回退: 从候选路径列表依次尝试, 直到加载成功。
//
//  API:
//   SM.imageCache.load(src)         -> Promise<Image>
//     尝试加载图片。如果 window.ImagePack 存在则使用其候选链,
//     否则直接加载 src。结果缓存在 Map 中, 后续调用返回同一 Promise。
//
//   SM.imageCache.get(src)          -> Image|null
//     同步获取已缓存的图片。未加载返回 null。
//
//   SM.imageCache.clear()           -> void
//     清空所有缓存。
//
//   SM.imageCache.prefetch(srcs)    -> Promise<Image[]>
//     预加载一组图片, 返回 Promise.all。
//
//  依赖: 无 (如果 window.ImagePack 存在自动使用回退链, 否则退化到直接加载)
//  消费方: 渲染器 / UI 面板
// ==================================================================
(function () {
  'use strict';

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (SM.imageCache) return;

  var _cache = new Map();

  function _getCandidates(src) {
    try {
      if (window.ImagePack && typeof window.ImagePack.getCandidates === 'function') {
        return window.ImagePack.getCandidates(src);
      }
    } catch (e) {}
    return [src];
  }

  function _getCacheKey(src) {
    try {
      if (window.ImagePack && typeof window.ImagePack.getCacheKey === 'function') {
        return window.ImagePack.getCacheKey(src);
      }
    } catch (e) {}
    return src;
  }

  function load(src) {
    if (!src) {
      return Promise.reject(new Error('SM.imageCache.load: src must be a non-empty string'));
    }

    var cacheKey = _getCacheKey(src);
    var existing = _cache.get(cacheKey);
    if (existing) return existing;

    var candidates = _getCandidates(src);
    var candidateIndex = 0;
    var resolvePromise, rejectPromise;
    var promise = new Promise(function (resolve, reject) {
      resolvePromise = resolve;
      rejectPromise = reject;
    });

    var img = new Image();
    _cache.set(cacheKey, promise);

    img.onload = function () { resolvePromise(img); };
    img.onerror = function () {
      candidateIndex++;
      if (candidateIndex < candidates.length) {
        img.src = candidates[candidateIndex];
      } else {
        _cache.delete(cacheKey);
        rejectPromise(new Error('SM.imageCache: failed to load image at path "' + src + '"'));
      }
    };
    img.src = candidates[candidateIndex];

    return promise;
  }

  function get(src) {
    if (!src) return null;
    var cacheKey = _getCacheKey(src);
    var entry = _cache.get(cacheKey);
    // 如果缓存的是 Promise（尚未 resolve），返回 null
    if (entry instanceof Promise) return null;
    return entry || null;
  }

  function clear() {
    _cache.clear();
  }

  function prefetch(srcs) {
    if (!Array.isArray(srcs)) srcs = [srcs];
    return Promise.all(srcs.map(function (s) { return load(s).catch(function () { return null; }); }));
  }

  SM.imageCache = Object.freeze({
    load: load,
    get: get,
    clear: clear,
    prefetch: prefetch
  });
})();
