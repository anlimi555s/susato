// rules.js — mod 生态校验规则数据（单一事实源）
// 消费方: 整合包构建器 builder.html(内联) + 起源管理器 game/rules.js(副本)
// 修改本文件后需同步两处。纯数据, 无逻辑。
(function () {
  'use strict';
  if (typeof window !== 'undefined' && window.SusatoRules) return;

  var RULES = {
    version: 1,

    // 互斥对: 两个 mod 不应同时安装。type: hard=阻止构建/红色告警, warn=黄色提示
    // versionA/versionB 为可选 semver 范围, 省略表示任意版本
    mutualExclusion: [
      {
        nameA: '起源框架',
        nameB: '寿里美化拓展-起源管理器',
        reason: '管理器已升格为起源框架基座, 旧管理器包退役, 同装会双份面板与钩子',
        type: 'hard'
      },
      {
        nameA: '起源框架',
        nameB: '起源框架-寿里美化包', versionB: '<=2.8',
        reason: '旧版大包(<=2.8)自带整套框架层, 与基座同装单例互抢/注入双份, 请换 v2.9+ 内容包',
        type: 'hard'
      },
      {
        nameA: '起源框架-寿里美化包', versionA: '>=2.7 <=2.8',
        nameB: '寿里美化拓展-人模切换',
        reason: '旧版大包(2.7-2.8)内置人模切换, 与独立包同装会在镜子里出现两个入口。v2.9+ 内容包已不含人模切换, v3.0+ 基座也不内置, 独立包成为唯一人模切换功能来源, 不再与任何包互斥',
        type: 'hard'
      },
      {
        nameA: '起源框架-寿里美化包',
        nameB: 'susato-model ZH',
        reason: '同一个 mod 的新旧两代包, 同装图片补丁全部双份冲突',
        type: 'hard'
      }
    ],

    // 旧包名: 检测到即提示换新
    oldNames: [
      { oldName: '寿里美化拓展-起源管理器', newName: '起源框架', reason: '2026-07-17 管理器升格为框架基座, 旧管理器不再维护' },
      { oldName: 'susato-model ZH', newName: '起源框架-寿里美化包', reason: '2026-07-16 改名, 旧包不再维护' },
      { oldName: 'susato-model EN (International)', newName: '(暂无, EN 区重做中)', reason: '英文区旧包已暂弃' },
      { oldName: 'KatherineHouse', newName: '隐都潜流', reason: '2026-07-16 改名, 旧包不再维护' }
    ],

    // 顺序契约: name 必须排在 afterNames 中每个已安装 mod 之后
    orderContracts: [
      { name: '起源框架-寿里美化包', afterNames: ['起源框架'], reason: '内容包的衣物/发型注册依赖基座框架先建立 API' },
      { name: '隐都潜流', afterNames: ['起源框架', '起源框架-寿里美化包'], reason: '内容 mod 依赖框架的 addon 与运行时' },
      { name: '寿里美化拓展-人模切换', afterNames: ['起源框架'], reason: '人模切换依赖框架的 onCompile 钩子与 SusatoTextAddon' }
    ],

    // 起源框架功能模块开关清单(管理器 模块开关页签)
    // lock=true 不可关(仅作在册记录, 不渲染开关行); warn 为关闭时的额外提示文字
    // group: framework=基座功能 / pack=美化功能(住在内容包, 内容包缺席时不渲染)
    // 铁律: 每个 lock=false 条目的 id 必须与对应模块 IIFE 顶部 moduleOff('<id>') 守卫一致(仿真守着)
    packMod: '起源框架-寿里美化包',
    modules: [
      { id: 'susato-core', group: 'framework', name: '渲染器核心', nameEn: 'Renderer Core', lock: true, desc: '图层注入与编译钩子管道, 一切功能的地基', descEn: 'Layer injection and compile hook pipeline, foundation of all features' },
      { id: 'state-addon', group: 'framework', name: '运行时地基', nameEn: 'Runtime Foundation', lock: true, desc: '变量托管/统一消息/日界调度, 其他模块依赖', descEn: 'Variable management, unified notifications, daily scheduling' },
      { id: 'text-addon', group: 'framework', name: '文本注入引擎', nameEn: 'Text Injection Engine', lock: true, desc: 'SusatoTextAddon, 各 mod 的界面注入都靠它', descEn: 'SusatoTextAddon, passage text injection for all mods' },
      { id: 'clothing-addon', group: 'framework', name: '衣服注册框架', nameEn: 'Clothing Registry', lock: true, desc: '存档穿着注册衣物时关闭会导致崩溃', descEn: 'Disabling while wearing registered clothing will crash saves' },
      { id: 'clothing-data', group: 'framework', name: '衣服数据', nameEn: 'Clothing Data', lock: true, desc: '同上, 与衣服注册框架一体', descEn: 'Clothing definitions, coupled with clothing-addon' },
      { id: 'hair-addon', group: 'framework', name: '发型注册框架', nameEn: 'Hair Registry', lock: true, desc: '存档使用注册发型时关闭会异常', descEn: 'Disabling while using registered hairstyles may cause errors' },
      { id: 'skill', group: 'framework', name: '技能注册框架', nameEn: 'Skill Registry', lock: false, warn: '内容 mod 注册的技能将不生效(存档变量保留)', warnEn: 'Custom skills from content mods will stop working (save vars preserved)', desc: '自定义技能注册与升级提示', descEn: 'Custom skill registration and level-up notifications' },
      { id: 'economy-addon', group: 'framework', name: '经济框架', nameEn: 'Economy Framework', lock: false, warn: '隐都潜流银行/贷款等结算将停摆', warnEn: 'Bank/loan settlement from Undercurrent will halt', desc: '周期结算与账本', descEn: 'Periodic settlement and ledger' },
      { id: 'clothing-layering', group: 'pack', name: '时装叠穿', nameEn: 'Clothing Layering', lock: false, warn: '衣柜叠穿面板与叠层渲染停用(已保存的叠穿方案保留)', warnEn: 'Layering panel and render disabled (saved outfits preserved)', desc: '衣柜多层穿搭与渲染(通用衣柜能力)', descEn: 'Multi-layer wardrobe with stacking render' },
      { id: 'npc-addon', group: 'framework', name: 'NPC 关系框架', nameEn: 'NPC Relation Framework', lock: false, warn: '内容 mod 注册的关系条将不显示(如隐都潜流警局信任)', warnEn: 'Registered NPC relation bars will disappear (e.g. police trust)', desc: '社交页 NPC 关系条注册与渲染', descEn: 'NPC relation bar registration and rendering on Social page' },
      { id: 'righthand', group: 'pack', name: '右手置顶', nameEn: 'Right Hand Priority', lock: false, warn: '右手/持物图层回到本体默认层级', warnEn: 'Right hand/held item layers return to default z-order', desc: '右手与持物渲染置顶修正', descEn: 'Right hand and held item z-index fix' },
      { id: 'decorations', group: 'pack', name: '前景背景装饰', nameEn: 'Foreground/Background Decor', lock: false, warn: '侧栏前景背景按钮与装饰图层停用(配置保留)', warnEn: 'Sidebar deco buttons and layers disabled (config preserved)', desc: '人物立绘的前景背景装饰系统', descEn: 'Character foreground/background decoration system' },
      { id: 'model-addon', group: 'pack', name: '人模切换', nameEn: 'Model Switch', lock: false, warn: '镜子内人模切换入口消失, 回到默认人模', warnEn: 'Mirror model switch entry removed, reverts to default', desc: '游戏内人模热切换(镜子入口)', descEn: 'In-game character model hot-swap via mirror' },
      { id: 'breast-system', group: 'pack', name: '胸部渲染系统', nameEn: 'Breast Rendering', lock: false, warn: '胸围贴图提升与锁胸配置不生效, 回退本体渲染', warnEn: 'Breast image promotion and lock config disabled', desc: '胸部贴图提升与胸差/锁胸配置', descEn: 'Breast image promotion, size variant and lock config' },
      { id: 'ear-z-fix', group: 'pack', name: '耳朵层级修正', nameEn: 'Ear Z-Index Fix', lock: false, warn: '耳朵回到 basehead 被头发遮住', warnEn: 'Ears return to basehead, hidden by hair', desc: '耳朵 Z 层级提升到 ears(132.5) 穿过头发显示', descEn: 'Ear z-index raised to 132.5 to render above hair' },
      { id: 'palette', group: 'framework', name: '主题工坊', nameEn: 'Theme Workshop', lock: false, warn: '自定义主题与背景图停用，回退默认配色', warnEn: 'Custom themes and wallpapers disabled, reverts to default', desc: '主题工坊配色方案与背景图', descEn: 'Color themes and background wallpapers' },
      { id: 'ui-addon', group: 'framework', name: 'UI图标切换', nameEn: 'UI Icon Switch', lock: false, warn: '自定义UI图标停用，回退默认图标', warnEn: 'Custom UI icons disabled, reverts to default', desc: 'UI图标导入与切换', descEn: 'UI icon import and switching' },
      { id: 'character-addon', group: 'framework', name: '统一角色系统', nameEn: 'Character System', lock: true, desc: '角色身份协调层，脸型/身体部件/变形管线', descEn: 'Character identity coordination: face, body parts, transformation pipeline' },
      { id: 'named-npc', group: 'framework', name: '具名NPC基类', nameEn: 'Named NPC Base', lock: true, desc: 'NamedNPC 代词/身体描述/模板导出，内容NPC从此继承', descEn: 'NamedNPC: pronouns, body desc, template export for content NPCs' },
      { id: 'action-parser', group: 'framework', name: '动作解析引擎', nameEn: 'Action Parser', lock: false, warn: '战斗动作图标分类将不可用', warnEn: 'Combat action icon classification will be unavailable', desc: '战斗动作文本正则解析与分类', descEn: 'Combat action text regex parsing and classification' },
    { id: 'combat-layout', group: 'framework', name: '战斗分屏布局', nameEn: 'Combat Split Layout', lock: false, warn: '战斗页面恢复默认滚动布局', warnEn: 'Combat page reverts to default scroll layout', desc: '战斗叙事与选项左右分栏', descEn: 'Combat narrative and action split view' },
    { id: 'audio', group: 'framework', name: '音频系统', nameEn: 'Audio System', lock: false, warn: '游戏音频(音乐/环境音/音效)将停用', warnEn: 'Game audio (music/ambience/sfx) will be disabled', desc: '音频播放、Pack管理与设置面板', descEn: 'Audio playback, pack management and settings panel' },
    { id: 'encounter', group: 'framework', name: '声明式遭遇系统', nameEn: 'Declarative Encounter', lock: false, warn: '结构化遭遇(条件对话/动作提示)将不可用', warnEn: 'Structured encounters (conditional dialog/action prompts) will be unavailable', desc: '条件匹配表+文本变体池+状态效果+冷却控制', descEn: 'Condition match table + text variant pool + stat effects + cooldown control' },
    { id: 'combat', group: 'framework', name: '战斗动作框架', nameEn: 'Combat Action Framework', lock: false, warn: '自定义战斗动作(拳击馆等)将不可用', warnEn: 'Custom combat actions (boxing gym etc.) will be unavailable', desc: '战斗动作注册与选项注入', descEn: 'Combat action registration and option injection' },
      { id: 'hook-system', group: 'framework', name: '零补丁钩子系统', nameEn: 'Zero-Patch Hook System', lock: true, desc: '宏拦截+函数代理，不碰源码注入逻辑', descEn: 'Macro interception and function proxying, inject logic without source patching' },
      { id: 'scene-system', group: 'framework', name: '叙事场景系统', nameEn: 'Scene Narrative System', lock: true, desc: '结构化场景/幕/阶段/分支管理，复杂剧情内容基座', descEn: 'Structured scene/episode/phase/branch management for complex narratives' },
      { id: 'tab-manager', group: 'framework', name: '标签页管理器', nameEn: 'Tab Manager', lock: false, warn: '管理器面板与其他设置面板的标签页组织功能停用', warnEn: 'Tab organization for manager and settings panels disabled', desc: '标签页注册/排序/收藏/隐藏/持久化', descEn: 'Tab registration, sorting, favorites, hide/show with persistence' },
      { id: 'state-bar', group: 'framework', name: '状态条组件', nameEn: 'State Bar Widget', lock: false, warn: '动画状态条组件不可用', warnEn: 'Animated state bar widget unavailable', desc: '双元素 lag-fill 动画状态条，战斗/属性可视化', descEn: 'Dual-element lag-fill animated state bar for combat/stat visualization' }
    ],

    // 联网更新配置: jsDelivr 为主通道 (CORS 全开, 国内可达, 单文件 20MB 硬上限——
    // 超限包由发布脚本切分卷, 管理器下载后拼接), raw GitHub 为降级通道(国内常不可达)。
    // 更新源文件必须提交进仓库分支(git 文件树), Release 附件 jsDelivr 不服务。
    // 缓存事实: jsDelivr 对分支(@main)文件的 CDN 缓存是 12 小时(s-maxage=43200),
    // 且删库重建会污染其 分支->commit 解析缓存(purge 清不掉)。因此管理器优先经
    // GitHub API 解析 main 最新 commit, 用 @<sha> 锁定拉取(URL 唯一, 推完即生效);
    // API 不可达时回退 @分支(此时 versions.json 依赖发布侧 purge)。
    update: {
      user: 'anlimi555s',
      repo: 'AetherCore',
      branch: 'main',
      manifestFile: 'versions.json',
      // main 最新 commit 查询地址(GitHub API, 本机与国内实测可达; 匿名限额 60 次/时, 单次检查足够)
      apiCommit: function () {
        var u = RULES.update;
        return 'https://api.github.com/repos/' + u.user + '/' + u.repo + '/commits/' + u.branch;
      },
      // 下载地址序列: 有 sha 时 commit 锁定地址优先, 分支地址殿后兜底; 无 sha 时同旧行为
      urls: function (file, sha) {
        var u = RULES.update;
        var out = [];
        if (sha) {
          out.push('https://cdn.jsdelivr.net/gh/' + u.user + '/' + u.repo + '@' + sha + '/' + file);
          out.push('https://raw.githubusercontent.com/' + u.user + '/' + u.repo + '/' + sha + '/' + file);
        }
        out.push('https://cdn.jsdelivr.net/gh/' + u.user + '/' + u.repo + '@' + u.branch + '/' + file);
        out.push('https://raw.githubusercontent.com/' + u.user + '/' + u.repo + '/' + u.branch + '/' + file);
        return out;
      },
      // 远程公告 URL：返回 HTML 片段，管理器更新页 fetch 后渲染
      // 改公告不需发版，改仓库里的 notice.html 即可
      noticeUrl: function () {
        var u = RULES.update;
        return "https://cdn.jsdelivr.net/gh/" + u.user + "/" + u.repo + "@" + u.branch + "/notice.html";
      }
    }
  };

  if (typeof window !== 'undefined') window.SusatoRules = RULES;
  if (typeof module !== 'undefined' && module.exports) module.exports = RULES;
})();
