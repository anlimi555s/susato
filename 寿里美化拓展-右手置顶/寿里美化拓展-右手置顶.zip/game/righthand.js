// ==================================================================
// 他妈的，能不能不要一天天把代码写的那么脏，那么差，
// 知不知道我们做 mod 的、实现想法的人写的有多难，真是的。
//   —— 冲着 DoL 本体这块渲染代码：右臂那组衣物的 z 散绑在
//      armsidle / under_upper_arms / over_upper_arms / 共享 zarms / zupperright
//      五六个不同来源；袖层还多是工厂函数生成，源码正则根本枚举不到；
//      连 cum_leftarm、hands_left_detail 这种左手层都莫名其妙去判 arm_right。
//      「让右手高于衣服」这么个直觉需求，硬逼出下面这套运行时遍历+重映射。
// ==================================================================
// 右手渲染高于衣物 —— JS 框架版（v3：通用重映射，覆盖全部右臂衣物）
// ------------------------------------------------------------------
// 目标：让垂在身侧的「右手」连同其上的一切衣物(裸臂/内衣袖/上装袖/外套袖/手套/纹身/cum)
//       整组渲染在下装(裙/裤/袜)之上，且彼此保持本体原有的内部前后顺序。只动右侧。
//
// 本体把右臂那组图层的 idle z 分散绑在 armsidle(30)/under_upper_arms(32)/upper_arms(89)/
// over_upper_arms(103.9)/zarms(≤~104) 等——全都 < arms_cover(105)、又低于下装，所以右手被盖住。
// 之前只抬「裸臂+上袖」会漏掉手套/内衣/外套/连体衣手部(它们各用别的 z)。
//
// 通用解法：运行时遍历模型模板的图层，凡「右臂组」的层，把它 idle 时算出的 z 用
//   newZ = arms_cover + 原z/1000
// 重映射。除以 1000 是单调变换 → 完整保留本体内部顺序(裸臂<内衣<上装<外套<手套…)，
// 又把整组压进 [105.03, 105.11] 这个窄带——高于下装(≤103.3)、低于头发/头部，一次到位。
// cover/hold 姿态本体已在衣物上，原样不动。
//
// 时序：模型懒创建、构造时 clone(layers) 保留函数引用，故在 :storyready(任何立绘渲染前)
//       改模板 layers[k].zfn，之后每次 new CanvasModel 克隆都带上。
// ------------------------------------------------------------------
(function () {
  function apply() {
    try {
      if (typeof Renderer === "undefined" || !Renderer.CanvasModels || !Renderer.CanvasModels.main) return false;
      var main = Renderer.CanvasModels.main;
      var Z = (typeof ZIndices !== "undefined") ? ZIndices
            : (typeof window !== "undefined" ? window.ZIndices : null);
      if (!Z || !main.layers || typeof Z.arms_cover !== "number") return false;
      if (main._rightHandAboveClothes) return true; // 幂等

      var L = main.layers;
      var base = Z.arms_cover; // 105

      // 右臂组图层识别(键名)：裸臂 / *_rightarm(含上装/内衣/外套袖 + cum) /
      //   hands_right* 手套 / *_fitted_right(_acc) 贴身内衣 / 右肩纹身。
      // 排除：right_iris(眼)、writing_right_cheek(脸)、writing_right_thigh/leg(腿)、
      //       follower_*(随从)、以及一切 left。
      function isRightArm(k) {
        return k === "rightarm"
          || /_rightarm(_acc|_fitted)?$/.test(k)
          || /^hands_right/.test(k)
          || /_fitted_right(_acc)?$/.test(k)
          || k === "writing_right_shoulder";
      }

      Object.keys(L).forEach(function (k) {
        if (!isRightArm(k)) return;
        var layer = L[k];
        if (!layer || layer._rhacWrapped) return;
        var origZfn = (typeof layer.zfn === "function") ? layer.zfn : null;
        var origZ = layer.z;
        layer.zfn = function (o) {
          var z = origZfn ? origZfn.call(this, o) : origZ;
          // cover/hold：本体已把该组抬到衣物上，原样返回
          if (o && (o.arm_right === "cover" || o.arm_right === "hold")) return z;
          // idle：单调压到裸臂之上、保留内部顺序
          return (typeof z === "number") ? (base + z / 1000) : z;
        };
        layer._rhacWrapped = true;
      });

      main._rightHandAboveClothes = true;
      return true;
    } catch (e) { return false; }
  }

  // 先即时尝试(本体脚本通常已定义 main)，未就绪则退到 storyready(仍在任何立绘渲染前)。
  if (!apply()) {
    if (typeof $ !== "undefined") $(document).one(":storyready", apply);
  }
})();
