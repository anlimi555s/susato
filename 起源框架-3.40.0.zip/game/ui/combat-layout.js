// ==================================================================
//  combat-layout v1.6 -- 战斗分屏布局
//  左右 50/50 分屏。手机默认原版。按钮可切换，刷新记住选择。
// ==================================================================
(function () {
  'use strict';

  if (window.SusatoModel && window.SusatoModel.moduleOff && window.SusatoModel.moduleOff('combat-layout')) return;

  var SM = window.SusatoModel = window.SusatoModel || {};
  SM.ui = SM.ui || {};
  if (SM.ui._combatLayoutV1) return;

  var MOBILE_MAX = 640;

  function isMobile() {
    return window.innerWidth <= MOBILE_MAX || (window.screen && window.screen.width <= MOBILE_MAX);
  }
  var _active = false;
  var _observer = null;
  var _dynamicObserver = null;

  // ================================================================
  //  战斗检测
  // ================================================================
  function isInCombat() {
    try { if (typeof V !== 'undefined' && V.combat === 1) return true; } catch (e) {}
    return !!document.getElementById('listContainer');
  }

  // ================================================================
  //  精灵检测
  // ================================================================
  function isSpriteElement(el) {
    if (!el || el.nodeType !== 1) return false;
    if (el.classList && el.classList.contains('combat-grid')) return true;
    if (el.classList && el.classList.contains('d-flex') && el.classList.contains('flex-row')) {
      if (el.querySelector('.combat-grid, .combat-main, .combat-centre, canvas')) return true;
    }
    if (el.className && typeof el.className === 'string') {
      if (el.className.indexOf('combat-main') >= 0 ||
          el.className.indexOf('combat-centre') >= 0 ||
          el.className.indexOf('combat-close') >= 0) return true;
    }
    var canvases = el.querySelectorAll ? el.querySelectorAll('canvas') : [];
    if (!canvases.length && el.tagName === 'CANVAS') canvases = [el];
    for (var i = 0; i < canvases.length; i++) {
      if (canvases[i].width > 100 || canvases[i].height > 100) return true;
    }
    return false;
  }

  // ================================================================
  //  布局
  // ================================================================
  function setupCombatUI() {
    var passage = document.querySelector('.passage');
    var listContainer = document.getElementById('listContainer');
    if (!passage || !listContainer) return false;
    if (passage.classList.contains('combatui-combat-active')) return true;

    var wrapper = document.createElement('div');
    wrapper.className = 'combatui-combat-wrapper';

    var spritePanel = document.createElement('div');
    spritePanel.className = 'combatui-sprite-panel';

    var container = document.createElement('div');
    container.className = 'combatui-combat-container';

    var narrativePanel = document.createElement('div');
    narrativePanel.className = 'combatui-passage-panel';

    var actionPanel = document.createElement('div');
    actionPanel.className = 'combatui-action-panel';

    // 遍历 passage 子节点
    var spriteNodes = [];
    var narrativeNodes = [];
    var node = passage.firstChild;
    while (node) {
      var next = node.nextSibling;
      if (node === listContainer) break;
      if (node === wrapper || node === container || node === spritePanel) { node = next; continue; }
      if (isSpriteElement(node)) { spriteNodes.push(node); }
      else { narrativeNodes.push(node); }
      node = next;
    }

    for (var si = 0; si < spriteNodes.length; si++) {
      try { spritePanel.appendChild(spriteNodes[si]); } catch (e) {}
    }
    for (var ni = 0; ni < narrativeNodes.length; ni++) {
      try { narrativePanel.appendChild(narrativeNodes[ni]); } catch (e) {}
    }

    try { actionPanel.appendChild(listContainer); } catch (e) { return false; }

    // replaceAction 整体移到动作面板
    var ra = document.getElementById('replaceAction');
    if (ra) { try { actionPanel.insertBefore(ra, listContainer); } catch (e) {} }

    container.appendChild(narrativePanel);
    container.appendChild(actionPanel);

    var stabilitySlot = document.createElement('div');
    stabilitySlot.className = 'combatui-stability-slot';
    stabilitySlot.id = 'combatui-stability-slot';
    var oxygenSlot = document.createElement('div');
    oxygenSlot.className = 'combatui-oxygen-slot';
    oxygenSlot.id = 'combatui-oxygen-slot';

    if (spritePanel.children.length > 0) wrapper.appendChild(spritePanel);
    wrapper.appendChild(stabilitySlot);
    wrapper.appendChild(oxygenSlot);
    wrapper.appendChild(container);

    passage.insertBefore(wrapper, passage.firstChild);
    passage.classList.add('combatui-combat-active');

    removePipeSeparators(narrativePanel);
    removePipeSeparators(actionPanel);
    enhanceListControls();
    watchDynamicContent(passage, narrativePanel, spritePanel, stabilitySlot, oxygenSlot);
    findAndMoveStability(stabilitySlot);
    findAndMoveOxygen(oxygenSlot);

    _active = true;
    document.body.classList.add('combatui-active');
    return true;
  }

  function cleanupCombatLayout() {
    disconnectObservers();
    var wrapper = document.querySelector('.combatui-combat-wrapper');
    var passage = document.querySelector('.passage');
    if (!wrapper || !passage) { _active = false; return; }

    var listContainer = document.getElementById('listContainer');
    var replaceAction = document.getElementById('replaceAction');

    if (listContainer && listContainer.parentNode !== passage) {
      try { passage.insertBefore(listContainer, passage.firstChild); } catch (e) {}
    }
    if (replaceAction && replaceAction.parentNode !== passage) {
      try { passage.insertBefore(replaceAction, passage.firstChild); } catch (e) {}
    }

    passage.classList.remove('combatui-combat-active');
    wrapper.remove();
    _active = false;
    document.body.classList.remove('combatui-active');
  }

  // ================================================================
  //  管道清理
  // ================================================================
  function removePipeSeparators(container) {
    if (!container) return;
    var walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT, null);
    var toRemove = [];
    var node;
    while ((node = walker.nextNode())) {
      var t = node.textContent.trim();
      if (t === '|' || t === '' || /^\|[\s\|]*$/.test(t)) toRemove.push(node);
    }
    for (var i = 0; i < toRemove.length; i++) {
      try { toRemove[i].remove(); } catch (e) {}
    }
  }

  function enhanceListControls() {
    var lc = document.getElementById('listContainer');
    if (!lc || lc.classList.contains('combatui-lists-enhanced')) return;
    lc.classList.add('combatui-lists-enhanced');
    lc.classList.remove('grid-radio', 'grid-lists');
    if (lc.querySelector('.radioControl')) lc.classList.add('grid-radio');
    else if (lc.querySelector('.listsControl') || lc.querySelector('.limitedListsControl')) lc.classList.add('grid-lists');
  }

  // ================================================================
  //  稳定性 / 氧气
  // ================================================================
  function findAndMoveStability(slot) {
    if (!slot) return;
    var el = document.getElementById('combatExtendedStabilityCaption');
    if (!el || slot.contains(el)) return;
    try { slot.innerHTML = ''; slot.appendChild(el); slot.classList.add('has-content'); } catch (e) {}
  }
  function findAndMoveOxygen(slot) {
    if (!slot) return;
    var el = document.getElementById('oxygencaption') || document.getElementById('oxygen-caption');
    if (!el || slot.contains(el)) return;
    try { slot.innerHTML = ''; slot.appendChild(el); slot.classList.add('has-content'); } catch (e) {}
  }
  function checkAndMoveStability(passage, slot) {
    var el = document.getElementById('combatExtendedStabilityCaption');
    if (el && !slot.contains(el) && passage.contains(el)) findAndMoveStability(slot);
  }
  function checkAndMoveOxygen(passage, slot) {
    var el = document.getElementById('oxygencaption') || document.getElementById('oxygen-caption');
    if (el && !slot.contains(el) && passage.contains(el)) findAndMoveOxygen(slot);
  }

  // ================================================================
  //  动态监视
  // ================================================================
  function watchDynamicContent(passage, narrativePanel, spritePanel, stabilitySlot, oxygenSlot) {
    findAndMoveStability(stabilitySlot);
    findAndMoveOxygen(oxygenSlot);
    checkAndMoveStability(passage, stabilitySlot);
    checkAndMoveOxygen(passage, oxygenSlot);

    if (_dynamicObserver) { _dynamicObserver.disconnect(); _dynamicObserver = null; }

    _dynamicObserver = new MutationObserver(function (mutations) {
      for (var mi = 0; mi < mutations.length; mi++) {
        var m = mutations[mi];
        if (m.type !== 'childList' || !m.addedNodes.length) continue;
        if (m.target !== passage) continue;

        for (var ai = 0; ai < m.addedNodes.length; ai++) {
          var added = m.addedNodes[ai];
          if (added.classList) {
            if (added.classList.contains('combatui-combat-wrapper') ||
                added.classList.contains('combatui-combat-container') ||
                added.classList.contains('combatui-passage-panel') ||
                added.classList.contains('combatui-action-panel') ||
                added.classList.contains('combatui-sprite-panel') ||
                added.classList.contains('combatui-stability-slot') ||
                added.classList.contains('combatui-oxygen-slot')) continue;
          }
          if (added.id === 'combatExtendedStabilityCaption') { findAndMoveStability(stabilitySlot); continue; }
          if (added.id === 'oxygencaption' || added.id === 'oxygen-caption') { findAndMoveOxygen(oxygenSlot); continue; }
          if (added.id === 'replaceAction') {
            var ap = document.querySelector('.combatui-action-panel');
            var lc = document.getElementById('listContainer');
            if (ap && lc) try { ap.insertBefore(added, lc); } catch (e) {}
            continue;
          }
          if (isSpriteElement(added)) { try { spritePanel.appendChild(added); } catch (e) {} }
          else if (added.nodeType === 1 || added.nodeType === 3) {
            if (added.nodeType === 3) {
              var txt = (added.textContent || '').toLowerCase();
              if (txt.indexOf('stability') >= 0 || !txt.trim()) continue;
            }
            try { narrativePanel.appendChild(added); } catch (e) {}
          }
        }
      }
      checkAndMoveStability(passage, stabilitySlot);
      checkAndMoveOxygen(passage, oxygenSlot);
    });
    _dynamicObserver.observe(passage, { childList: true });
  }

  // ================================================================
  //  Observer
  // ================================================================
  function disconnectObservers() {
    if (_observer) { _observer.disconnect(); _observer = null; }
    if (_dynamicObserver) { _dynamicObserver.disconnect(); _dynamicObserver = null; }
  }
  function startObserver() {
    disconnectObservers();
    var passage = document.querySelector('.passage');
    if (!passage) return;
    _observer = new MutationObserver(function () {
      if (isInCombat()) {
        if (SM.defer) { SM.defer(function () { if (isInCombat()) setupCombatUI(); }); }
        else { setTimeout(function () { if (isInCombat()) setupCombatUI(); }, 50); }
      }
    });
    _observer.observe(passage, { childList: true, subtree: true });
  }

  // ================================================================
  //  API
  // ================================================================
  SM.ui.combatLayout = { isActive: function () { return _active; } };
  SM.ui._combatLayoutV1 = true;

  // ================================================================
  //  生命周期
  // ================================================================
  function init() {
    if (typeof $ !== 'undefined') {
      $(document).on(':passageend', function () {
        disconnectObservers();
        cleanupCombatLayout();
        if (isMobile() || !isInCombat()) return;
        var delay = SM.defer || function (fn) { setTimeout(fn, 50); };
        delay(function () { setupCombatUI(); startObserver(); });
      });
      $(document).on(':passageend', function () {
        if (!isInCombat()) { disconnectObservers(); cleanupCombatLayout(); }
      });
    }
  }

  if (SM.onInit) { SM.onInit(init); } else { init(); }

  if (SM.modules) {
    SM.modules.register('combat-layout', function () { init(); return SM.ui.combatLayout; }, { deps: ['susato-core'], exposed: false });
  }
})();
