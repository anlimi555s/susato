// ==================================================================
//  npc-addon v1.1 -- NPC 关系注册 + 自定义状态
//  注册自定义关系条到 Social 页面 + 声明式 NPC 状态维度。
//
//  API:
//    SusatoModel.npc.register({id, name, variable, icon, preText, visible, states})
//    SusatoModel.npc.list() / count() / get(id)
//
//    SusatoModel.npc.addStats({ statName: { min, max, default } })
//      声明 NPC 自定义状态维度（对标 maplebirch npc.addStats）
//    SusatoModel.npc.stat(npcName, statName) -- 读取某个 NPC 的某个状态值
//    SusatoModel.npc.setStat(npcName, statName, value) -- 设值（自动 clamp）
//
//  依赖: state-addon.js (变量托管)、susato-core.js (SusatoTextAddon 注入)
//  消费方: 隐都潜流 (警局信任度、拳馆尊敬值)
// ==================================================================
(function () {
  'use strict';
  if (window.SusatoModel && window.SusatoModel.moduleOff && window.SusatoModel.moduleOff('npc-addon')) return;

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (SM.npc && SM.npc.register) return; // load-once 守卫（检查具体 API 而非命名空间）

  var _registry = {};
  var _order = [];
  var _statsDefs = {}; // statName -> {min, max, default}

  function _initVar(cfg) {
    try {
      if (!cfg.variable) return;
      if (SM.vars) { SM.vars.define(cfg.variable, 0); return; }
      if (typeof State !== 'undefined' && State.variables && State.variables[cfg.variable] === undefined) {
        State.variables[cfg.variable] = 0;
      }
    } catch (e) {}
  }

  function _clamp(v, min, max) {
    if (v < min) return min;
    if (v > max) return max;
    return v;
  }

  SM.npc = {
    register: function (cfg) {
      if (!cfg || !cfg.id || _registry[cfg.id]) return false;
      if (!cfg.variable || !Array.isArray(cfg.states) || !cfg.states.length) return false;
      _registry[cfg.id] = cfg;
      _order.push(cfg.id);
      _initVar(cfg);
      return true;
    },
    get: function (id) { return _registry[id]; },
    list: function () {
      var out = [];
      for (var i = 0; i < _order.length; i++) {
        var cfg = _registry[_order[i]];
        try { if (cfg.visible && !cfg.visible()) continue; } catch (e) { continue; }
        out.push(cfg);
      }
      return out;
    },
    count: function () { return SM.npc.list().length; },

    // ---- 自定义状态 ----
    addStats: function (statsObj) {
      if (!statsObj || typeof statsObj !== 'object') return;
      for (var k in statsObj) {
        if (Object.prototype.hasOwnProperty.call(statsObj, k)) {
          var def = statsObj[k];
          if (_statsDefs[k]) continue;
          _statsDefs[k] = {
            min: def.min !== undefined ? def.min : 0,
            max: def.max !== undefined ? def.max : 100,
            default: def.default !== undefined ? def.default : 0
          };
        }
      }
    },

    stat: function (npcName, statName) {
      var def = _statsDefs[statName];
      if (!def) return 0;
      try {
        var V = (typeof State !== 'undefined' && State.variables) ? State.variables : null;
        if (!V) return def.default;
        var key = '_npcStat_' + npcName + '_' + statName;
        if (V[key] === undefined) V[key] = def.default;
        return V[key];
      } catch (e) { return def.default; }
    },

    setStat: function (npcName, statName, value) {
      var def = _statsDefs[statName];
      if (!def) return;
      try {
        var V = (typeof State !== 'undefined' && State.variables) ? State.variables : null;
        if (!V) return;
        var key = '_npcStat_' + npcName + '_' + statName;
        V[key] = _clamp(value, def.min, def.max);
      } catch (e) {}
    },

    // 列出已注册的状态维度
    listStats: function () {
      return Object.keys(_statsDefs).map(function (k) {
        var d = _statsDefs[k];
        return { name: k, min: d.min, max: d.max, default: d.default };
      });
    },
  };

  // 兜底: 注册可能早于 state-addon 就绪, storyready 再补一次变量托管
  if (typeof $ !== 'undefined') {
    $(document).one(':storyready', function () {
      for (var i = 0; i < _order.length; i++) _initVar(_registry[_order[i]]);
    });
  }
})();
