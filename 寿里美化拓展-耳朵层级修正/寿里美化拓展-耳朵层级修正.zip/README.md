# 耳朵层级修正 · 后发上刘海下

让兽耳（狼耳 / 猫耳 / 狐耳，含牛耳）穿过头发正常显示。

## 问题

DoL 0.5.10.12 里，兽耳的默认渲染层级是 `basehead`（z=5），会被头发完全盖住——戴着头发时兽耳看不见。

## 修法

一条 ReplacePatcher 补丁，把兽耳默认层级从 `basehead`(5) 提到 `ears`(132.5)：

```
canvasmodel-main.js
  return ZIndices.basehead;  →  return ZIndices.ears;
```

`ears`(132.5) 天生夹在前侧发 `hair_forward`(132) 与刘海 `front_hair`(133) 之间，是本体为「耳朵穿过头发」预留的位置——所以效果是**后发之上、刘海之下**。

## 作用范围

命中 `genlayer_ears` 里未自带 zfn 的耳朵层：狼耳 / 猫耳 / 狐耳，以及牛耳左耳、牛铃（它们的静态 z 是死代码，被 zfn 覆盖）。战斗特写走独立渲染器，不受影响。

## 依赖

- ModLoader
- ReplacePatcher ^1.0.0

## 兼容

适配 Degrees of Lewdity 0.5.10.12。纯代码补丁，独立可用，不含图片。

## 致谢

画家K
