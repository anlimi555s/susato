// ==================================================================
//  combat-extended v1.0 -- 战斗扩展系统
//  吸收自 DoL Plus Combat Extended (game/base-combat/ + game/04-Variables/variables-modUpdate.twee).
//  提供稳定性/闪避/格挡/反击/佯攻/钩拳/缠斗/敌人AI/动态难度缩放的纯JS实现。
//  内容 mod 可通过 Twee <<run>> 调用，或直接 JS 调用。
//
//  API:
//   配置 (在 modupdate 中初始化):
//     SM.combat.init(state)
//      初始化 $combatExtended 全部默认值 (42 个属性)。
//      应在 mod 的 variables-modUpdate 等效位置调用。
//
//   战斗流程 (每回合按顺序调用):
//     SM.combat.startFight(state)          -- 站立战斗开始时调用, 设置 stability=100
//     SM.combat.resetRound(state)          -- 每回合开始重置 active 状态
//     SM.combat.checkDefense(state, cfg)   -- 玩家防御判定(被动/主动闪避+反击), 返回防御结果
//     SM.combat.checkEnemy(state, cfg)     -- 敌人AI判定(闪避/格挡/反击), 返回敌人行动
//     SM.combat.wound(state, amount)       -- 玩家受击, 扣 stability
//     SM.combat.restore(state, amount)     -- 玩家恢复 stability
//     SM.combat.isStable(state)            -- 是否仍站稳 (stability > 0)
//
//   缩放:
//     SM.combat.scaleEnemy(state, days, defeats) -- 计算动态难度缩放, 返回缩放因子
//     SM.combat.getEnemyDodge(state, index)      -- 获取指定敌人的闪避值
//
//   依赖: SM (window.SusatoModel)
//   消费方: 隐都潜流 (拳击馆), 内容 mod
//
//   注意: 这些是纯计算函数, 不操作 DOM。
//   实际战斗流程仍需 Twee 宏驱动 SugarCube 的 combat 管道。
// ==================================================================
(function () {
  'use strict';

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (SM.combat && SM.combat._flowV1) return;

  // ================================================================
  //  默认值定义
  // ================================================================
  var DEFAULTS = {
    // 开关
    standingFights: 0,
    standingFightStart: 1,
    footworkToggle: 0,
    strikingToggle: 0,
    kickingToggle: 0,
    brawlingToggle: 0,
    reverseRape: 0,
    reverseRapeStart: 0,
    reverseRapeEnd: 0,
    reverseRapeInit: 0,

    // 玩家战斗状态
    stability: 0,
    stabilityLost: 0,
    passiveDodging: 0,
    activeDodging: 0,
    activeDodgingActive: 0,
    dodgeSuccess: 0,
    blocking: 0,
    blockingActive: 0,
    countering: 0,
    counteringActive: 0,
    counterSuccess: 0,
    feinting: 0,
    feintingActive: 0,
    hookpunching: 0,
    hookpunchingActive: 0,
    brawling: 0,

    // 闪避配置
    uncappedDodgeChance: 0,
    dodgeChanceCap: 90,

    // 敌人AI
    enemyPassiveDodging: 0,
    enemyActiveDodging: 0,
    enemyFeinting: 0,
    enemyBlocking: 0,
    enemyCountering: 0,
    enemyCounterSuccess: 0,
    enemyMartialArts: 0,
    enemyMartialArtsScaling: 'random',
    enemyMartialArtsLevelScalingMult: 50,
    enemyBaseDodgeChance: 1,
    enemyBaseDodgeChanceMult: 2,

    // 动态难度
    enemyLevelDayScaling: 0,
    enemyLevelDayScalingMult: 1,
    enemyHealthDayScaling: 0,
    enemyHealthDayScalingMult: 5,
    enemyDayScaling: 7,
    enemyInfiniteDayScaling: 0,
    enemyDayScalingLimit: 20,
    enemyLevelDefeatScaling: 0,
    enemyLevelDefeatScalingMult: 1,
    enemyHealthDefeatScaling: 0,
    enemyHealthDefeatScalingMult: 5,
    enemyDefeatScaling: 10,
    enemyInfiniteDefeatScaling: 0,
    enemyDefeatScalingLimit: 20,

    // 技能
    footwork: 0,
    striking: 0,
    kicking: 0
  };

  // ================================================================
  //  工具函数
  // ================================================================

  function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }

  function rand(max) {
    return Math.floor(Math.random() * (max || 100));
  }

  // 从 state 安全读取
  function getV(state) {
    if (state && state.variables) return state.variables;
    try {
      if (typeof V !== 'undefined') return V;
    } catch (e) {}
    return {};
  }

  // ================================================================
  //  初始化
  // ================================================================

  function init(state) {
    var V = getV(state);
    if (!V.combatExtended) V.combatExtended = {};
    var ce = V.combatExtended;
    var keys = Object.keys(DEFAULTS);
    for (var i = 0; i < keys.length; i++) {
      var k = keys[i];
      if (ce[k] === undefined) ce[k] = DEFAULTS[k];
    }
    return ce;
  }

  // ================================================================
  //  战斗流程
  // ================================================================

  function startFight(state) {
    var V = getV(state);
    var ce = V.combatExtended || {};
    if (ce.standingFightStart) {
      ce.standingFightStart = 0;
      ce.stability = 100;
      ce.stabilityLost = 0;
    }
  }

  function resetRound(state) {
    var V = getV(state);
    var ce = V.combatExtended || {};
    ce.activeDodgingActive = 0;
    ce.blockingActive = 0;
    ce.counteringActive = 0;
    ce.feintingActive = 0;
    ce.hookpunchingActive = 0;
    ce.dodgeSuccess = 0;
    ce.counterSuccess = 0;
    if (ce.enemyActiveDodging !== undefined) ce.enemyActiveDodgingActive = 0;
    if (ce.enemyBlocking !== undefined) ce.enemyBlockingActive = 0;
    if (ce.enemyCountering !== undefined) ce.enemyCounteringActive = 0;
  }

  // ================================================================
  //  闪避/反击计算 (核心)
  // ================================================================

  /**
   * 计算玩家防御结果。
   * cfg: { skills: { dance, skulduggery }, bodySize, enemyCount, isDisabled }
   * 返回: { passiveDodge, activeDodge, dodgeSuccess, counterSuccess }
   */
  function checkDefense(state, cfg) {
    cfg = cfg || {};
    var V = getV(state);
    var ce = V.combatExtended || {};

    // bodySize 闪避修正
    var bodyDodge = 0;
    var bs = cfg.bodySize;
    if (bs === undefined) bs = V.bodysize;
    if (bs >= 4) bodyDodge = -35;
    else if (bs === 3) bodyDodge = -20;
    else if (bs === 2.5) bodyDodge = -10;
    else if (bs === 2) bodyDodge = 0;
    else if (bs === 1) bodyDodge = 15;
    else if (bs === 0) bodyDodge = 30;
    else bodyDodge = 45;

    // 舞蹈闪避
    var danceSkill = cfg.skills ? (cfg.skills.dance || 0) : 0;
    var danceDodge = Math.round(danceSkill / 40);

    // 缠斗闪避
    var brawlingDodge = 0;
    if (ce.brawlingToggle === 1) {
      var eCount = cfg.enemyCount || 1;
      brawlingDodge = Math.round((ce.brawling || 0) * eCount * (eCount / 16) / 100);
    }

    // 基础闪避值
    var baseDodge = danceDodge + bodyDodge + brawlingDodge;

    // 被动闪避
    var passiveResult = 0;
    if (ce.passiveDodging === 1) {
      var pdChance = baseDodge;
      if (!ce.uncappedDodgeChance) pdChance = clamp(pdChance, 0, ce.dodgeChanceCap || 90);
      if (ce.stabilityLost) pdChance = Math.round(pdChance / 2);
      if (pdChance >= rand(100)) passiveResult = 2;
      else if (pdChance >= rand(80)) passiveResult = 1;
    }

    // 主动闪避
    var activeResult = 0;
    if (ce.activeDodgingActive === 1) {
      var adChance = baseDodge * 2;
      if (!ce.uncappedDodgeChance) adChance = clamp(adChance, 0, ce.dodgeChanceCap || 90);
      if (ce.stabilityLost) adChance = Math.round(adChance / 2);
      if (adChance >= rand(100)) activeResult = 2;
      else if (adChance >= rand(80)) activeResult = 1;
    }

    // 反击
    var counterResult = 0;
    if (ce.countering === 1 && ce.counteringActive >= 1) {
      var sk = cfg.skills ? (cfg.skills.skulduggery || 0) : 0;
      var ccChance = 100 * (0.25 * (sk / 1000) * ce.counteringActive);
      if (ce.stabilityLost) ccChance = Math.round(ccChance / 2);
      if (ccChance >= rand(100)) counterResult = 2;
      else if (ccChance >= rand(80)) counterResult = 1;
    }

    // 应用结果 (仅在玩家可行动时)
    var disabled = cfg.isDisabled;
    if (!disabled) {
      ce.counterSuccess = counterResult;
      ce.dodgeSuccess = Math.max(passiveResult, activeResult);
    }

    return {
      baseChance: baseDodge,
      passiveDodge: passiveResult,
      activeDodge: activeResult,
      dodgeSuccess: Math.max(passiveResult, activeResult),
      counterSuccess: counterResult
    };
  }

  // ================================================================
  //  稳定性
  // ================================================================

  function wound(state, amount) {
    var V = getV(state);
    var ce = V.combatExtended || {};
    var loss = amount || 0;
    // 步法减免
    if (ce.footworkToggle === 1 && loss < 0) {
      loss = loss * (1 - 0.8 * ((ce.footwork || 0) / 2000));
    }
    ce.stability = clamp((ce.stability || 0) + loss, 0, 100);
    // 检查是否失去平衡
    if (ce.stability <= 0 && ce.standingFightStart === 0 && !ce.stabilityLost) {
      ce.stabilityLost = 1;
    }
    return ce.stability;
  }

  function restore(state, amount) {
    var V = getV(state);
    var ce = V.combatExtended || {};
    ce.stability = clamp((ce.stability || 0) + (amount || 0), 0, 100);
    if (ce.stability > 0) ce.stabilityLost = 0;
    return ce.stability;
  }

  function isStable(state) {
    var V = getV(state);
    var ce = V.combatExtended || {};
    return ce.stability > 0 && ce.stabilityLost !== 1;
  }

  // ================================================================
  //  敌人AI
  // ================================================================

  /**
   * 敌人AI判定。返回敌人本回合的行动列表。
   * cfg: { anger, enemyCount }
   */
  function checkEnemy(state, cfg) {
    cfg = cfg || {};
    var V = getV(state);
    var ce = V.combatExtended || {};
    var actions = [];
    var anger = cfg.anger !== undefined ? cfg.anger : 100;

    if (ce.enemyActiveDodging === 1) {
      actions.push('dodge');
      if (anger < 100) actions.push('nothing');
    }
    if (ce.enemyBlocking === 1) {
      actions.push('block');
      if (anger < 100) actions.push('nothing');
    }
    if (ce.enemyCountering === 1) {
      actions.push('counter');
      if (anger < 100) actions.push('nothing');
    }

    // 随机选择行动
    if (actions.length > 0) {
      var pick = actions[Math.floor(Math.random() * actions.length)];
      return { action: pick, all: actions };
    }
    return { action: 'nothing', all: [] };
  }

  /**
   * 获取指定敌人的基础闪避值
   */
  function getEnemyDodge(state, index) {
    var V = getV(state);
    var ce = V.combatExtended || {};
    var base = ce.enemyBaseDodgeChance || 1;
    var mult = ce.enemyBaseDodgeChanceMult || 2;
    return base * mult;
  }

  // ================================================================
  //  动态难度缩放
  // ================================================================

  /**
   * 计算动态难度缩放。
   * days: 当前天数 (Time.days)
   * defeats: 总击败数
   * 返回: { levelMult, healthMult }
   */
  function scaleEnemy(state, days, defeats) {
    var V = getV(state);
    var ce = V.combatExtended || {};
    var levelMult = 1;
    var healthMult = 1;

    // 天数缩放
    if (ce.enemyLevelDayScaling === 1) {
      var dayTicks = Math.floor((days || 0) / (ce.enemyDayScaling || 7));
      if (!ce.enemyInfiniteDayScaling) {
        dayTicks = Math.min(dayTicks, ce.enemyDayScalingLimit || 20);
      }
      levelMult += dayTicks * (ce.enemyLevelDayScalingMult || 1);
    }
    if (ce.enemyHealthDayScaling === 1) {
      var hTicks = Math.floor((days || 0) / (ce.enemyDayScaling || 7));
      if (!ce.enemyInfiniteDayScaling) {
        hTicks = Math.min(hTicks, ce.enemyDayScalingLimit || 20);
      }
      healthMult += hTicks * (ce.enemyHealthDayScalingMult || 5);
    }

    // 击败缩放
    if (ce.enemyLevelDefeatScaling === 1) {
      var defTicks = Math.floor((defeats || 0) / (ce.enemyDefeatScaling || 10));
      if (!ce.enemyInfiniteDefeatScaling) {
        defTicks = Math.min(defTicks, ce.enemyDefeatScalingLimit || 20);
      }
      levelMult += defTicks * (ce.enemyLevelDefeatScalingMult || 1);
    }
    if (ce.enemyHealthDefeatScaling === 1) {
      var dhTicks = Math.floor((defeats || 0) / (ce.enemyDefeatScaling || 10));
      if (!ce.enemyInfiniteDefeatScaling) {
        dhTicks = Math.min(dhTicks, ce.enemyDefeatScalingLimit || 20);
      }
      healthMult += dhTicks * (ce.enemyHealthDefeatScalingMult || 5);
    }

    return { levelMult: levelMult, healthMult: healthMult };
  }

  // ================================================================
  //  暴露 API — 合并到已有 SM.combat 不覆盖
  // ================================================================

  var flowAPI = {
    init: init,
    startFight: startFight,
    resetRound: resetRound,
    checkDefense: checkDefense,
    checkEnemy: checkEnemy,
    wound: wound,
    restore: restore,
    isStable: isStable,
    scaleEnemy: scaleEnemy,
    getEnemyDodge: getEnemyDodge,
    defaults: DEFAULTS
  };

  if (SM.combat) {
    for (var _k in flowAPI) {
      if (Object.prototype.hasOwnProperty.call(flowAPI, _k)) {
        SM.combat[_k] = flowAPI[_k];
      }
    }
  } else {
    SM.combat = flowAPI;
  }
  SM.combat._flowV1 = true;

  // ================================================================
  //  自动初始化 (storyready 时)
  // ================================================================
  if (SM.events) {
    SM.events.on(':storyready', function () {
      try {
        if (typeof State !== 'undefined' && State.variables) {
          init(State);
        }
      } catch (e) {}
    });
  }
})();
