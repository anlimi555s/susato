/* SusatoTextAddon - 运行在 ModLoader 加载期的文本注入 addon (v2.0.0: 起源框架双名注册)
 *
 * 加载方式: 起源框架 boot.json 的 scriptFileList_inject_early (inject_early 阶段为普通脚本, 非 JsRunner 单表达式)
 * 应用时机: AddonPluginHookPoint.afterPreload —— 结构性晚于 ModI18N(earlyload) 与 TweeReplacer(afterPatchModToGame),
 *           看到的是全部文本补丁完成后的最终 passage 文本
 *
 * 消费者用法 (子 mod boot.json):
 *   "addonPlugin": [{
 *     "modName": "起源框架",                                旧名 "起源框架-寿里美化包" 仍兼容(shim 别名注册)
 *     "addonName": "SusatoTextAddon",
 *     "modVersion": "^3.0.0",
 *     "params": [
 *       { "passage": "High Street",
 *         "anchor": "<<if $avery_fate is \"ascended\">>",   锚点(或用 anchorAny 数组, 依次尝试, 首个命中生效 -- 双语双锚点用这个)
 *         "position": "before",                             before/after/replace/prepend/append (prepend/append 不需要锚点)
 *         "content": "...要注入的 twee 文本..." }
 *     ]
 *   }]
 *
 * 与 TweeReplacer 的差异:
 *   1. 匹配的是最终文本(ModI18N 翻译后), anchorAny 可同时写英文原文与中文译文, 一份 zip 双区通吃
 *   2. 失败不静默: 全部失败条目收集在 window.SusatoTextAddon.failures, storyready 时 console.error 汇总
 *   3. 自检: 内置向 StoryCaption 追加注释标记, 应用后回读验证写入链路
 *
 * 双名注册结构:
 *   主 hookPoint  挂 "起源框架"           — registerMod(只认新名) + afterPreload 应用 + storyready 汇报
 *   shim hookPoint 挂 "起源框架-寿里美化包" — 只有 registerMod(只认旧名), 无生命周期钩子(避免 applyAll 双触发)
 *   两者共享同一 ops 数组; 应用前按 (passage|position|anchor|content) 去重, 防新旧双包同装双注入
 */
(function () {
    'use strict';
    var NAME = 'SusatoTextAddon';
    var OWNER = '起源框架';
    var OWNER_LEGACY = '起源框架-寿里美化包';
    var VERSION = '2.0.0';
    var MARKER = '/*SusatoTextAddon-selfcheck*/';

    if (typeof window === 'undefined' || !window.modSC2DataManager) {
        if (typeof console !== 'undefined') console.error(NAME + ': modSC2DataManager 不存在, addon 未注册');
        return;
    }
    if (window.SusatoTextAddon && window.SusatoTextAddon._loaded) {
        // 旧副本(残留 zip)已抢单例: 它只注册了旧名。为新名消费者补一条转发注册,
        // 声明转投旧实例的 ops(contentFile 无法转发, 响亮报错提示清理旧包)。
        try {
            var old = window.SusatoTextAddon;
            var apm0 = window.modSC2DataManager.getAddonPluginManager();
            var hasNew = false;
            try { hasNew = !!(apm0.getAddonPlugin && apm0.getAddonPlugin(OWNER, NAME)); } catch (e0) {}
            if (!hasNew && typeof old.addOps === 'function') {
                apm0.registerAddonPlugin(OWNER, NAME, {
                    registerMod: function (an, mod) {
                        try {
                            var lst = (mod && mod.bootJson && mod.bootJson.addonPlugin) || [];
                            for (var i = 0; i < lst.length; i++) {
                                var p = lst[i];
                                if (p.modName === OWNER && p.addonName === NAME && Object.prototype.toString.call(p.params) === '[object Array]') {
                                    var plain = [];
                                    for (var k = 0; k < p.params.length; k++) {
                                        if (p.params[k] && typeof p.params[k].contentFile === 'string' && typeof p.params[k].content !== 'string') {
                                            console.error(NAME + ': 旧版 addon 接管中, contentFile 条目无法转发 [' + mod.name + '] ' + p.params[k].contentFile + ' — 请从 Mod Loader 移除旧的 起源框架-寿里美化包/旧管理器 包');
                                        } else plain.push(p.params[k]);
                                    }
                                    old.addOps(mod.name, plain);
                                }
                            }
                        } catch (e1) {}
                        return Promise.resolve();
                    }
                });
                console.warn(NAME + ': 检测到旧版实例接管(v' + old.version + '), 已为"' + OWNER + '"补转发注册 — 建议移除旧包后重进');
            }
        } catch (e) {}
        return; // load-once
    }

    var state = {
        _loaded: true,
        version: VERSION,
        ops: [],          // {from, op}
        failures: [],     // {from, passage, reason, detail}
        appliedCount: 0,
        dedupedCount: 0,
        applied: false,
        selfCheckOk: null
    };
    window.SusatoTextAddon = state;

    function log(msg) {
        try { console.log(NAME + ': ' + msg); } catch (e) {}
        try { window.modSC2DataManager.getModLoadController().getLog().log('[' + NAME + '] ' + msg); } catch (e) {}
    }
    function logErr(msg) {
        try { console.error(NAME + ': ' + msg); } catch (e) {}
        try { window.modSC2DataManager.getModLoadController().getLog().error('[' + NAME + '] ' + msg); } catch (e) {}
    }

    // 供 JS 侧运行时注册(inject_early/earlyload 阶段调用有效, afterPreload 之后无效)
    state.addOps = function (fromName, opList) {
        try {
            if (state.applied) { logErr('addOps 太晚, afterPreload 已执行 (' + fromName + ')'); return false; }
            (opList || []).forEach(function (op) { state.ops.push({ from: String(fromName || 'js'), op: op }); });
            return true;
        } catch (e) { return false; }
    };

    function fail(from, op, reason, detail) {
        state.failures.push({ from: from, passage: op && op.passage, reason: reason, detail: detail || '' });
    }

    function applyOne(sc, from, op) {
        if (!op || typeof op.passage !== 'string') { fail(from, op, 'bad-op', '缺 passage'); return false; }
        var pp = sc.passageDataItems.map.get(op.passage);
        if (!pp) { fail(from, op, 'passage-missing', '合并后的游戏数据中无此段落'); return false; }
        if (typeof op.content !== 'string') { fail(from, op, 'bad-op', '缺 content'); return false; }
        var position = op.position || 'before';
        var text = pp.content;

        if (position === 'prepend') { pp.content = op.content + '\n' + text; return true; }
        if (position === 'append') { pp.content = text + '\n' + op.content; return true; }

        // 选锚点: anchor 单个, 或 anchorAny 依次尝试首个命中
        var candidates = [];
        if (typeof op.anchor === 'string') candidates.push(op.anchor);
        if (Object.prototype.toString.call(op.anchorAny) === '[object Array]') candidates = candidates.concat(op.anchorAny);
        if (!candidates.length) { fail(from, op, 'bad-op', '缺 anchor/anchorAny'); return false; }
        var anchor = null, at = -1;
        for (var i = 0; i < candidates.length; i++) {
            var idx = text.indexOf(candidates[i]);
            if (idx >= 0) { anchor = candidates[i]; at = idx; break; }
        }
        if (anchor === null) { fail(from, op, 'anchor-miss', '全部锚点候选(' + candidates.length + ')均未命中'); return false; }

        var newText;
        if (position === 'replace') newText = op.content;
        else if (position === 'after') newText = anchor + '\n' + op.content;
        else newText = op.content + '\n' + anchor; // before(默认)
        // indexOf + slice 拼接, 避开 String.replace 的 $ 特殊序列
        pp.content = text.slice(0, at) + newText + text.slice(at + anchor.length);
        return true;
    }

    // 双包同装(基座+旧大包 2.8)时同一条注入会以不同 from 各到一份 —— 按内容键去重, 保首条
    function dedupOps(list) {
        var seen = {};
        var out = [];
        for (var i = 0; i < list.length; i++) {
            var op = list[i].op || {};
            var key = [op.passage, op.position || 'before', op.anchor || '',
                (op.anchorAny || []).join('|'), op.content || '', op.contentFile || ''].join('');
            if (seen[key]) { state.dedupedCount++; continue; }
            seen[key] = true;
            out.push(list[i]);
        }
        return out;
    }

    function applyAll() {
        if (state.applied) return;
        state.applied = true;
        try {
            var dm = window.modSC2DataManager;
            var scOld = dm.getSC2DataInfoAfterPatch();
            var sc = scOld.cloneSC2DataInfo();

            // 内置自检: 向 StoryCaption 末尾追加注释标记(twee 块注释, 不渲染任何内容)
            var selfOp = { passage: 'StoryCaption', position: 'append', content: MARKER };
            var selfTarget = sc.passageDataItems.map.get('StoryCaption') ? selfOp : null;

            var todo = dedupOps(state.ops);
            if (selfTarget) todo.push({ from: NAME, op: selfTarget });

            var applied = 0;
            for (var i = 0; i < todo.length; i++) {
                if (applyOne(sc, todo[i].from, todo[i].op)) applied++;
            }
            state.appliedCount = applied;

            if (applied > 0) {
                sc.passageDataItems.back2Array();
                window.modUtils.replaceFollowSC2DataInfo(sc, scOld);
            }

            // 回读验证: 重新从 DOM 建缓存, 确认标记已落盘
            if (selfTarget) {
                try {
                    var fresh = dm.getSC2DataInfoAfterPatch();
                    var cap = fresh.passageDataItems.map.get('StoryCaption');
                    state.selfCheckOk = !!(cap && cap.content.indexOf(MARKER) >= 0);
                } catch (e) { state.selfCheckOk = false; }
            }

            log('afterPreload 应用完成: 成功 ' + applied + ' 条(含自检), 失败 ' + state.failures.length + ' 条, 去重 ' + state.dedupedCount + ' 条, 自检=' + state.selfCheckOk);
            if (state.failures.length) {
                for (var k = 0; k < state.failures.length; k++) {
                    var f = state.failures[k];
                    logErr('注入失败 [' + f.from + '] passage[' + f.passage + '] ' + f.reason + ' ' + f.detail);
                }
            }
        } catch (e) {
            logErr('applyAll 异常: ' + (e && e.message ? e.message : e));
        }
    }

    // registerMod 工厂: 只收集 boot.json 中 modName === matchName 的声明块
    // (主/旧名各只认自己, 消费者若同时声明两个名字也不会重复收集)
    function makeRegisterMod(matchName) {
        return function (addonName, mod, modZip) {
            // op.contentFile: 运行时从该 mod zip 读文件作为 content(源文件保持单一数据源, 不用内联进 boot.json)
            var reads = [];
            try {
                var list = (mod && mod.bootJson && mod.bootJson.addonPlugin) || [];
                for (var i = 0; i < list.length; i++) {
                    var p = list[i];
                    if (p.modName === matchName && p.addonName === NAME && Object.prototype.toString.call(p.params) === '[object Array]') {
                        for (var k = 0; k < p.params.length; k++) {
                            var op = p.params[k];
                            if (op && typeof op.contentFile === 'string' && typeof op.content !== 'string') {
                                reads.push((function (op2) {
                                    var f = null;
                                    try { f = modZip && modZip.zip && modZip.zip.file(op2.contentFile); } catch (e) {}
                                    if (!f) { fail(mod.name, op2, 'contentFile-missing', op2.contentFile); return Promise.resolve(); }
                                    return f.async('string').then(function (text) {
                                        op2 = Object.assign({}, op2);
                                        op2.content = String(text).replace(/\r\n/g, '\n').replace(/\n$/, '');
                                        state.ops.push({ from: mod.name, op: op2 });
                                    }, function (e) {
                                        fail(mod.name, op2, 'contentFile-read-error', op2.contentFile);
                                    });
                                })(op));
                                continue;
                            }
                            state.ops.push({ from: mod.name, op: op });
                        }
                        log('registerMod(' + matchName + '): 收到 [' + mod.name + '] ' + p.params.length + ' 条注入声明');
                    }
                }
            } catch (e) { logErr('registerMod 异常: ' + (e && e.message ? e.message : e)); }
            return Promise.all(reads);
        };
    }

    try {
        var apm = window.modSC2DataManager.getAddonPluginManager();
        // 主注册: 新名, 带生命周期
        apm.registerAddonPlugin(OWNER, NAME, {
            registerMod: makeRegisterMod(OWNER),
            afterPreload: function () {
                applyAll();
                return Promise.resolve();
            },
            whenSC2StoryReady: function () {
                // SC2 已启动: 汇总一次状态, 便于游戏内开控制台核对
                log('storyready 状态: ops=' + state.ops.length + ' applied=' + state.appliedCount + ' failures=' + state.failures.length + ' selfCheck=' + state.selfCheckOk);
                if (state.selfCheckOk === false) logErr('自检失败: afterPreload 阶段写 passage 未生效, 请回退到 preload 方案');
                return Promise.resolve();
            }
        });
        // 别名 shim: 旧名, 只收声明(旧消费者 boot.json 零修改兼容); 无生命周期钩子, 不会二次 applyAll
        apm.registerAddonPlugin(OWNER_LEGACY, NAME, {
            registerMod: makeRegisterMod(OWNER_LEGACY)
        });
        log('已注册 addon (' + OWNER + ' + 旧名 ' + OWNER_LEGACY + ' / ' + NAME + ' v' + VERSION + ')');
    } catch (e) {
        logErr('registerAddonPlugin 异常: ' + (e && e.message ? e.message : e));
    }

    // ================================================================
    //  GenesisAddon —— 子 mod 脚本加载
    //  对标 maplebirch maplebirchAddon。子 mod 在 boot.json 声明：
    //    { "modName": "起源框架", "addonName": "GenesisAddon",
    //      "params": { "script": ["game/my.js"] } }
    //  框架从子 mod zip 读文件并执行，纳入 ModuleSystem 管理体系。
    // ================================================================
    var GENESIS_ADDON = 'GenesisAddon';
    var _genesisScripts = []; // [{from, path}]

    apm.registerAddonPlugin(OWNER, GENESIS_ADDON, {
        registerMod: function (addonName, mod, modZip) {
            try {
                var list = (mod && mod.bootJson && mod.bootJson.addonPlugin) || [];
                for (var i = 0; i < list.length; i++) {
                    var p = list[i];
                    if (p.modName !== OWNER || p.addonName !== GENESIS_ADDON) continue;
                    var params = p.params || {};
                    var scripts = params.script || [];
                    for (var k = 0; k < scripts.length; k++) {
                        var filePath = scripts[k];
                        try {
                            var f = modZip && modZip.zip && modZip.zip.file(filePath);
                            if (!f) {
                                logErr('GenesisAddon: [' + mod.name + '] 文件不存在: ' + filePath);
                                continue;
                            }
                            var content = f.asText ? f.asText() : '';
                            if (!content) {
                                logErr('GenesisAddon: [' + mod.name + '] 文件为空: ' + filePath);
                                continue;
                            }
                            // 用 eval 执行（和 scriptFileList 一样在全局作用域）
                            eval(content);
                            _genesisScripts.push({ from: mod.name, path: filePath });
                            log('GenesisAddon: [' + mod.name + '] 已加载 ' + filePath);
                        } catch (e2) {
                            logErr('GenesisAddon: [' + mod.name + '] 执行失败 ' + filePath + ': ' + (e2.message || e2));
                        }
                    }
                }
            } catch (e) {
                logErr('GenesisAddon: registerMod 异常: ' + (e && e.message ? e.message : e));
            }
            return Promise.resolve();
        }
    });
    log('已注册 addon (' + OWNER + ' / ' + GENESIS_ADDON + ')');

})();
