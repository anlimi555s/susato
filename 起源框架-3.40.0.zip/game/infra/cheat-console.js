// ==================================================================
//  cheat-console v1.0 -- 开发者控制台
//  JS + Twine 双向执行。对标 maplebirch CheatConsole。
//  仅 $debug is 1 时可用。
//
//  API:
//   SusatoModel.console.open() -- 打开控制台面板
//   SusatoModel.console.execJS(code) -- 执行 JS 并返回结果
//   SusatoModel.console.execTwine(code) -- 执行 Twine 并返回结果
//
// 依赖: susato-core.js (SM.ui.openPanel)
// ==================================================================

(function () {
  'use strict';

  var SM = window.SusatoModel;
  if (!SM || SM.console) return;

  function _debugEnabled() {
    try { return !!(typeof V !== 'undefined' && V.debug); } catch (e) { return false; }
  }

  SM.console = {
    open: function () {
      if (!_debugEnabled()) {
        if (typeof SM.notify === 'function') SM.notify('控制台仅在 debug 模式下可用', 'red');
        return;
      }
      if (typeof SM.ui === 'object' && typeof SM.ui.openPanel === 'function') {
        SM.ui.openPanel('susatoConsole', { title: '开发者控制台', className: 'susato-console' });
      }
    },

    execJS: function (code) {
      if (!code) return { success: false, error: '空代码' };
      try {
        var result = eval(code);
        return { success: true, result: result, message: String(result) };
      } catch (e) {
        return { success: false, error: e.message || String(e) };
      }
    },

    execTwine: function (code) {
      if (!code) return { success: false, error: '空代码' };
      try {
        var frag;
        if (typeof Wikifier !== 'undefined') {
          frag = new Wikifier(document.createDocumentFragment(), String(code));
        } else if (typeof $ !== 'undefined') {
          frag = $(document.createDocumentFragment()).wiki(String(code));
        } else {
          return { success: false, error: 'Wikifier 不可用' };
        }
        return { success: true, message: 'Twine 已执行' };
      } catch (e) {
        return { success: false, error: e.message || String(e) };
      }
    }
  };
})();
