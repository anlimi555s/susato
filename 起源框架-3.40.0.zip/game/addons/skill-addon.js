// ==================================================================
//  skill-addon v1.0 — 技能运行时注册框架
//  注册自定义技能，自动处理变量初始化、currentSkillValue 接入、
//  SugarCube 宏创建、UI 注入和每日升级通知。
//
//  API:
//    SusatoModel.skill.add({id, name, icon, max, detailed, daily, hidden, states, modifier, description})
//      id         变量名（同时作为 <<id>> 宏名）
//      name       显示名
//      max        最大值（默认 1000）
//      detailed   使用详细等级表 F/F+/D/D+（默认 true），false 为基础表 F/D/C/B/A/S
//      daily      启用每日升级追踪（默认 true）
//      hidden     不在 UI 显示（默认 false）
//      states     自定义等级表（可选）
//      modifier   自定义修正函数 function(value)
//
//  依赖: susato-core.js (SusatoModel.onInit)、state-addon.js (变量托管)
//  消费方: 隐都潜流 (weaponCombat/hacking)
// ==================================================================
(function () {
  'use strict';
  if (window.SusatoModel && window.SusatoModel.moduleOff && window.SusatoModel.moduleOff('skill')) return; // 模块开关(起源管理器), 刷新后生效

  window.SusatoModel = window.SusatoModel || {};
  var SS = window.SusatoModel.skill = window.SusatoModel.skill || {};

  // ==================== 默认等级表 ====================
  var DETAILED_GRADES = [
    { requiredValue: 0,    level: '无',  color: 'red' },
    { requiredValue: 1,    level: 'F',   color: 'pink' },
    { requiredValue: 100,  level: 'F+',  color: 'pink' },
    { requiredValue: 200,  level: 'D',   color: 'purple' },
    { requiredValue: 300,  level: 'D+',  color: 'purple' },
    { requiredValue: 400,  level: 'C',   color: 'blue' },
    { requiredValue: 500,  level: 'C+',  color: 'blue' },
    { requiredValue: 600,  level: 'B',   color: 'lblue' },
    { requiredValue: 700,  level: 'B+',  color: 'lblue' },
    { requiredValue: 800,  level: 'A',   color: 'teal' },
    { requiredValue: 900,  level: 'A+',  color: 'teal' },
    { requiredValue: 1000, level: 'S',   color: 'green' }
  ];

  var BASIC_GRADES = [
    { requiredValue: 0,    level: '无',  color: 'red' },
    { requiredValue: 1,    level: 'F',   color: 'pink' },
    { requiredValue: 200,  level: 'D',   color: 'purple' },
    { requiredValue: 400,  level: 'C',   color: 'blue' },
    { requiredValue: 600,  level: 'B',   color: 'lblue' },
    { requiredValue: 800,  level: 'A',   color: 'teal' },
    { requiredValue: 1000, level: 'S',   color: 'green' }
  ];

  // 每日通知用的等级名和颜色（S=1...F+=10）
  var MSG_GRADES = ['S', 'A+', 'A', 'B+', 'B', 'C+', 'C', 'D+', 'D', 'F+'];
  var MSG_COLORS = ['green', 'teal', 'teal', 'lblue', 'lblue', 'blue', 'blue', 'purple', 'purple', 'pink'];

  // ==================== 内部状态 ====================
  var _registry = {};
  var _flushed = false;

  // ==================== 注册 ====================
  // 在 :storyready flush 前：排队，flush 时一起生效
  // flush 后：立即生效
  SS.add = function (config) {
    if (!config || !config.id) return false;
    if (_registry[config.id]) return false;

    // 填默认值
    config.max = config.max || 1000;
    config.detailed = config.detailed !== false;
    config.daily = config.daily !== false;
    config.states = config.states || (config.detailed ? DETAILED_GRADES : BASIC_GRADES);

    _registry[config.id] = config;

    if (_flushed) {
      _applyOne(config);
    }
    return true;
  };

  // ==================== 单技能生效 ====================
  function _applyOne(config) {
    var id = config.id;

    // 初始化 V 变量：state-addon 在场时走 vars 托管（旧档自动补缺），缺席回退直改
    try {
      var SMv = window.SusatoModel;
      if (SMv && SMv.vars) {
        SMv.vars.define(id, 0);
        if (config.daily) SMv.vars.define(id + 'day', 0);
      } else if (typeof V !== 'undefined') {
        if (!(id in V)) V[id] = 0;
        if (config.daily && !(id + 'day' in V)) V[id + 'day'] = 0;
      }
    } catch (e) {}

    // 创建 SugarCube 宏 <<id amount>>
    _createMacro(config);
  }

  function _createMacro(config) {
    try {
      // 优先用 DefineMacro（DoL 全局），回退 Macro.add（SugarCube 标准）
      if (typeof DefineMacro === 'function') {
        DefineMacro(config.id, function (amount) {
          if (typeof V === 'undefined' || V.statFreeze) return;
          amount = Number(amount);
          if (isNaN(amount)) return;
          if (amount) {
            var max = config.max || 1000;
            V[config.id] = Math.clamp(V[config.id] + amount, 0, max);
          }
        });
      } else if (typeof Macro !== 'undefined' && Macro.add) {
        Macro.add(config.id, {
          handler: function () {
            if (typeof V === 'undefined' || V.statFreeze) return;
            var amount = this.args.length > 0 ? Number(this.args[0]) : 0;
            if (isNaN(amount)) return;
            if (amount) {
              var max = config.max || 1000;
              V[config.id] = Math.clamp(V[config.id] + amount, 0, max);
            }
          }
        });
      }
    } catch (e) {}
  }

  // ==================== currentSkillValue 补丁 ====================
  function _patchCurrentSkillValue() {
    if (typeof window.currentSkillValue === 'undefined') return;
    if (window.currentSkillValue._susatoPatched) return;

    var _orig = window.currentSkillValue;
    window.currentSkillValue = function (skill, disableModifiers) {
      var reg = _registry[skill];
      if (reg) {
        var result = V[skill] || 0;
        if (typeof reg.modifier === 'function' && (!disableModifiers || disableModifiers < 2)) {
          try { result = reg.modifier(result); } catch (e) {}
        }
        return Math.floor(result);
      }
      return _orig(skill, disableModifiers);
    };
    window.currentSkillValue._susatoPatched = true;
  }

  // ==================== UI 渲染 ====================
  function _getCurrentState(config) {
    var val = V[config.id] || 0;
    var states = config.states;
    var level = 0;
    for (var i = 0; i < states.length; i++) {
      if (val >= states[i].requiredValue) level = i;
    }
    return { level: level, value: val };
  }

  function _calcPercent(config, state) {
    var val = V[config.id] || 0;
    var states = config.states;
    if (state.level >= states.length - 1) {
      if (config.max && val >= states[state.level].requiredValue) {
        return Math.floor(100 * (val - states[state.level].requiredValue) / (config.max - states[state.level].requiredValue));
      }
      return 100;
    }
    var curReq = states[state.level].requiredValue;
    var nextReq = states[state.level + 1].requiredValue;
    return Math.floor(100 * (val - curReq) / (nextReq - curReq));
  }

  function _renderSkillBox(config) {
    var state = _getCurrentState(config);
    var st = config.states[state.level];
    var percent = _calcPercent(config, state);
    var barWidth = Math.clamp(percent, 0, 100);

    var box = document.createElement('div');
    box.className = 'characteristic-box';
    box.setAttribute('data-susato-skill', config.id);

    // 顶行
    var topLine = document.createElement('div');
    topLine.className = 'characteristic-top-line';

    // 图标（可选）
    if (config.icon) {
      var img = document.createElement('img');
      img.className = 'characteristic-icon';
      img.src = 'img/' + config.icon + '.png';
      topLine.appendChild(img);
    }

    // 标题
    var title = document.createElement('span');
    title.className = 'characteristic-title';
    title.textContent = config.name;
    topLine.appendChild(title);

    // 等级（和原生一致：0级显示等级名"无"但不显示百分比）
    if (st && st.level) {
      var levelSpan = document.createElement('span');
      levelSpan.className = 'characteristic-level';

      var gradeSpan = document.createElement('span');
      gradeSpan.className = st.color;
      gradeSpan.textContent = st.level;
      levelSpan.appendChild(gradeSpan);

      if (state.level > 0) {
        var small = document.createElement('small');
        small.className = 'grade-percent black';
        small.textContent = percent + '%';
        levelSpan.appendChild(document.createTextNode(' '));
        levelSpan.appendChild(small);
      }

      topLine.appendChild(levelSpan);
    }

    box.appendChild(topLine);

    // 描述
    if (config.description) {
      var desc = document.createElement('span');
      desc.className = 'characteristic-description ' + (st ? st.color : '');
      desc.textContent = config.description;
      box.appendChild(desc);
    }

    // 进度条
    var meter = document.createElement('div');
    meter.className = 'meter';
    var bar = document.createElement('div');
    bar.className = (st ? st.color + 'bar' : 'goldbar');
    bar.style.width = barWidth + '%';
    meter.appendChild(bar);
    box.appendChild(meter);

    return box;
  }

  // DefineMacroS(<<customSkills>>) 处理主渲染, 禁用 DOM 注入避免双渲染

  // ==================== 每日追踪 ====================
  function _checkDaily() {
    try {
      if (typeof V === 'undefined' || V.statFreeze) return;
    } catch (e) { return; }

    var ids = Object.keys(_registry);
    for (var i = 0; i < ids.length; i++) {
      var config = _registry[ids[i]];
      if (!config.daily) continue;

      var id = config.id;
      var val = V[id] || 0;
      var dayVal = V[id + 'day'] || 0;

      // 从高往低检查 10 个阈值: 1000, 900, ..., 100
      for (var t = 0; t < 10; t++) {
        var threshold = 1000 - t * 100;
        if (val >= threshold && dayVal < threshold) {
          V[id + 'message'] = t + 1; // 1=S ... 10=F+
          break;
        }
      }
    }
  }

  function _displayMessages() {
    try {
      if (typeof V === 'undefined') return;
    } catch (e) { return; }

    var ids = Object.keys(_registry);
    for (var i = 0; i < ids.length; i++) {
      var config = _registry[ids[i]];
      if (!config.daily) continue;

      var id = config.id;
      var msgVar = id + 'message';

      if (!V[msgVar]) continue;

      var gradeIdx = V[msgVar] - 1;
      var grade = MSG_GRADES[gradeIdx] || '?';
      var color = MSG_COLORS[gradeIdx] || 'white';

      // 升级提示：state-addon 在场时走统一消息系统，缺席回退自建 DOM
      var SMn = window.SusatoModel;
      if (SMn && typeof SMn.notify === 'function') {
        var styleOk = { gold: 1, red: 1, teal: 1, green: 1, blue: 1 };
        SMn.notify('你的' + config.name + '提升到了 ' + grade + '。', styleOk[color] ? color : 'gold');
        if (typeof SMn.notifyFlush === 'function') SMn.notifyFlush(); // 当页立即可见
      } else {
        try {
          if (typeof $ !== 'undefined') {
            var wrapper = document.createElement('div');
            var gold = document.createElement('span');
            gold.className = 'gold';
            gold.textContent = '你的' + config.name + '提升到了 ';
            var gradeEl = document.createElement('span');
            gradeEl.className = color;
            gradeEl.textContent = grade + '.';
            wrapper.appendChild(gold);
            wrapper.appendChild(gradeEl);

            var content = document.getElementById('passage-content');
            if (content && content.firstChild) {
              content.insertBefore(wrapper, content.firstChild);
            } else if (content) {
              content.appendChild(wrapper);
            }
          }
        } catch (e) {}
      }

      delete V[msgVar];
      V[id + 'day'] = V[id];
    }
  }

  // ==================== Flush ====================
  function _flush() {
    _patchCurrentSkillValue();

    // 应用所有已注册技能
    var ids = Object.keys(_registry);
    for (var i = 0; i < ids.length; i++) {
      _applyOne(_registry[ids[i]]);
    }

    // 挂事件（只挂一次）
    if (typeof $ !== 'undefined') {
      // 日结算（离开页面时）
      $(document).on(':passageend', function () {
        try { _checkDaily(); } catch (e) {}
        try { _displayMessages(); } catch (e) {}
      });
    }

    _flushed = true;

    // 切换为直接模式
    SS.add = function (config) {
      if (!config || !config.id) return false;
      if (_registry[config.id]) return false;

      config.max = config.max || 1000;
      config.detailed = config.detailed !== false;
      config.daily = config.daily !== false;
      config.states = config.states || (config.detailed ? DETAILED_GRADES : BASIC_GRADES);

      _registry[config.id] = config;
      _applyOne(config);
      return true;
    };
  }

  // SugarCube 宏: <<customSkills>> — 返回 HTML, 由 SusatoTextAddon 注入到 Characteristics
  function _defineMacro() {
    try {
      if (typeof DefineMacroS !== 'function') return;
      DefineMacroS('customSkills', function () {
        var ids = Object.keys(_registry);
        if (!ids.length) return '';
        var h = '';
        for (var i = 0; i < ids.length; i++) {
          var cfg = _registry[ids[i]];
          if (cfg.hidden) continue;
          var desc = cfg.description;
          cfg.description = null; // 不在 Characteristics 页显示描述
          h += _renderSkillBox(cfg).outerHTML;
          cfg.description = desc;
        }
        return h;
      });
    } catch (e) {}
  }

  // ==================== 挂 susato-core 共享 init 管道 ====================
  var SM = window.SusatoModel || {};
  SM._initHooks = SM._initHooks || [];
  SM._initHooks.push(function () {
    try { _flush(); } catch (e) {}
    try { _defineMacro(); } catch (e) {}
  });
})();
