// ==================================================================
//  rand v1.0 -- 可控随机数系统
//  种子 + 历史 + 回溯。用于需要可复现随机的场景（如银行劫案地下房间生成）。
//
//  API:
//   var rng = SusatoModel.rand.create(seed)
//   rng.int(max)  -- [0, max) 整数
//   rng.float()   -- [0, 1) 浮点
//   rng.pick(arr) -- 从数组中随机取一个元素
//   rng.shuffle(arr) -- Fisher-Yates 洗牌（返回新数组）
//   rng.reset(seed) -- 重置种子
//   rng.back(n)   -- 回溯 n 步
//
// 依赖: 无
// ==================================================================

(function () {
  'use strict';

  var SM = window.SusatoModel;
  if (!SM) return;

  // Mulberry32 PRNG
  function mulberry32(a) {
    return function () {
      a |= 0; a = a + 0x6D2B79F5 | 0;
      var t = Math.imul(a ^ a >>> 15, 1 | a);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }

  function RandSystem(seed) {
    this._history = [];
    this._index = 0;
    this.reset(seed);
  }

  RandSystem.prototype.reset = function (seed) {
    if (seed === undefined) seed = Date.now();
    if (typeof seed === 'number') seed = Math.floor(seed);
    else seed = String(seed).split('').reduce(function (a, c) { return a + c.charCodeAt(0); }, 0);
    this._seed = seed;
    this._next = mulberry32(seed);
    this._history = [];
    this._index = 0;
  };

  RandSystem.prototype.float = function () {
    var v = this._next();
    this._history.length = this._index;
    this._history.push(v);
    this._index++;
    return v;
  };

  RandSystem.prototype.int = function (max) {
    return Math.floor(this.float() * max);
  };

  RandSystem.prototype.pick = function (arr) {
    if (!arr || !arr.length) return undefined;
    return arr[this.int(arr.length)];
  };

  RandSystem.prototype.shuffle = function (arr) {
    var out = arr.slice();
    for (var i = out.length - 1; i > 0; i--) {
      var j = this.int(i + 1);
      var t = out[i]; out[i] = out[j]; out[j] = t;
    }
    return out;
  };

  RandSystem.prototype.back = function (n) {
    if (typeof n !== 'number' || n < 1) n = 1;
    this._index = Math.max(0, this._index - n);
    this.reset(this._seed);
    for (var i = 0; i < this._index; i++) this._next();
  };

  Object.defineProperty(RandSystem.prototype, 'history', {
    get: function () { return this._history.slice(); }
  });

  Object.defineProperty(RandSystem.prototype, 'index', {
    get: function () { return this._index; }
  });

  SM.rand = {
    create: function (seed) { return new RandSystem(seed); }
  };
})();
