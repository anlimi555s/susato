// ==================================================================
//  npc-base v1.0 -- 具名 NPC 基类
//  对标 maplebirch NamedNPC：代词/身体描述/类型/状态统一管理。
//  隐都潜流的维托/迪冷/尤里从此继承，不再手写模板。
//
//  API:
//    new SM.NamedNPC(config)         -- 创建具名 NPC
//    npc.pronoun(type)               -- 代词: 'he'/'she'/'they' -> '他'/'她'/'ta'
//    npc.bodyDesc()                  -- 身体描述快照
//    npc.toTemplate()                -- 导出 DoL NPC 模板 (V.NPCName 格式)
//    npc.get(key)                    -- 取属性
//    npc.set(key, value)             -- 设属性
//
//  依赖: 无。纯数据结构。
//  消费方: 隐都潜流 (维托/迪冷/尤里), 后续内容 mod
// ==================================================================
(function () {
  'use strict';

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (SM.NamedNPC) return;

  var PRONOUN_MAP = {
    m: { sub: 'he', obj: 'him', poss: 'his', refl: 'himself', cn: { sub: '他', obj: '他', poss: '他的' } },
    f: { sub: 'she', obj: 'her', poss: 'her', refl: 'herself', cn: { sub: '她', obj: '她', poss: '她的' } },
    n: { sub: 'they', obj: 'them', poss: 'their', refl: 'themself', cn: { sub: 'ta', obj: 'ta', poss: 'ta的' } }
  };

  function NamedNPC(config) {
    this._data = config || {};
    if (!this._data.pronoun) this._data.pronoun = 'm';
  }

  NamedNPC.prototype = {
    // 代词
    pronoun: function (type) {
      var p = PRONOUN_MAP[this._data.pronoun] || PRONOUN_MAP.m;
      return p[type || 'sub'] || '';
    },

    // 身体描述快照 (从 DoL State 读取)
    bodyDesc: function () {
      try {
        if (typeof State === 'undefined' || !State.variables) return {};
        var V = State.variables;
        var name = this._data.nam || this._data.name || '';
        var idx = V[name];
        if (!idx) return {};
        return {
          eyeColour: idx.eyeColour, hairColour: idx.hairColour,
          skincolour: idx.skincolour, breastsize: idx.breastsize,
          penis: idx.penis, vagina: idx.vagina
        };
      } catch (e) { return {}; }
    },

    // 导出 DoL NPC 模板 (可直接赋给 V.NPCName)
    toTemplate: function () {
      var c = this._data;
      return {
        nam: c.nam || c.name || '',
        title: c.title || '',
        type: c.type || 'human',
        pronoun: c.pronoun || 'm',
        teen: c.teen || 0, adult: c.adult || 1,
        init: c.init !== undefined ? c.init : 1,
        intro: c.intro !== undefined ? c.intro : 1,
        love: c.love || 0, dom: c.dom || 0, lust: c.lust || 0,
        rage: c.rage || 0, trust: c.trust || 0, trauma: c.trauma || 0,
        state: c.state || '',
        eyeColour: c.eyeColour || 0, hairColour: c.hairColour || 0,
        skincolour: c.skincolour || 0, desc: c.desc || 0,
        breastsdesc: c.breastsdesc || 0, breastsize: c.breastsize || 0,
        breastfeed: c.breastfeed || 0,
        penis: c.penis || 'none', vagina: c.vagina || 'none',
        chastity: c.chastity || { penis: '', vagina: '', anus: '' },
        virginity: c.virginity || { oral: true, vaginal: true, penile: true, anal: true, kiss: true, handholding: true },
        pregnancy: c.pregnancy || {}, pregnancyAvoidance: c.pregnancyAvoidance || 0,
        location: c.location || {}, skills: c.skills || {},
        pronouns: c.pronouns || {}, traits: c.traits || []
      };
    },

    // 读写属性
    get: function (key) { return this._data[key]; },
    set: function (key, value) { this._data[key] = value; return this; },

    // 身份
    get name() { return this._data.name || this._data.nam || ''; },
    get title() { return this._data.title || ''; },
    get type() { return this._data.type || 'human'; }
  };

  // 工厂
  SM.NamedNPC = function (config) { return new NamedNPC(config); };
  SM.NamedNPC.PRONOUN_MAP = PRONOUN_MAP;
})();
