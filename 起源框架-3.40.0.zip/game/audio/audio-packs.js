// ==================================================================
//  audio-packs v1.0 -- 音频包管理与触发器求值
//  吸收 Breeze of Lewdity 音频包系统:
//    包定义/加载/卸载/启用/禁用
//    触发器条件求值与分发
//    简写引用解析
//    路径解析 (支持相对路径/URL/IDB)
//    SugarCube 宏拦截 ($set/endcombat)
//    生命周期钩子 (:passageinit / :passagedisplay / :passageend)
//
//  包数据结构:
//    { name, version, description, folder, source, icon, enabled, shorthand, data }
//    data 中每个条目:
//    { if, do, else, music, ambience, sfx }
//    music/ambience/sfx 可以是 string / { url, volume, pitch, loop, ... } / Array
//
//  不包含: 音频播放核心/DSL条件解析/YouTube播放器
//  (分别由 audio-core.js / audio-dsl.js / audio-youtube.js 提供)
//
//  API:
//    SM.audio.packs.load(packDef)          -- 加载一个包
//    SM.audio.packs.unload(name)           -- 卸载一个包
//    SM.audio.packs.enable(name, bool)     -- 启用/禁用一个包
//    SM.audio.packs.list()                 -- 列出所有包 ({name,version,description,enabled,count})
//    SM.audio.packs.evaluate()             -- 求值所有包触发器 (由 :passageend 自动调用)
//    SM.audio.packs.evaluateTriggers()     -- evaluate 别名
//    SM.audio.packs.getMacroState()        -- 获取宏追踪状态
//
//  依赖: SM.audio (audio-core), SM.audio.dsl (audio-dsl)
//  消费方: 游戏集成层
// ==================================================================
(function () {
  'use strict';

  if (window.SusatoModel && window.SusatoModel.moduleOff && window.SusatoModel.moduleOff('audio')) return;

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (!SM.audio) return;
  if (SM.audio.packs) return;

  SM.audio.packs = {};

  // ==================================================================
  //  内部状态
  // ==================================================================

  var _packs = [];              // Array<PackDef>
  var _packIndex = {};          // Map<name, PackDef>

  // 活跃 URL 追踪: 记录上一轮和本轮播放的非 SFX 音频 URL
  // 用于在 passage 切换时自动停止过时的音频
  var _previousUrls = {};
  var _activeUrls = {};

  // 每轮求值只允许一首音乐播放 (首个写到 music 字段的包优先)
  // 避免多个包同时输出音乐造成叠放
  var _musicStarted = false;

  // 宏追踪状态 — 拦截 <<set>> 和 <<endcombat>>
  var _isEnemyEjaculating = false;
  var _isCombatEnd = false;
  var _lastAction = '';
  var _lastPassage = '';

  var _MAX_SHORTHAND_DEPTH = 20;

  // ==================================================================
  //  包数据管理
  // ==================================================================

  /**
   * 包定义结构:
   *   name:        string  唯一名称 (必须)
   *   version:     string  语义版本号, 默认 "1.0.0"
   *   description: string  描述文本
   *   folder:      string  音频文件所在目录 (相对于 ./audio/packs/)
   *   source:      string  远程更新来源 URL
   *   icon:        string  图标路径
   *   enabled:     boolean 是否启用, 默认 true
   *   shorthand:   object  简写映射表 { key: value }
   *   data:        array   触发器条目列表 (必须)
   *
   *  data 条目结构:
   *   { if, do, else, music, ambience, sfx }
   *
   *   if:     string   DSL 条件表达式 (可选)
   *   do:     any      条件真时执行的条目 (可选)
   *   else:   any      条件假时执行的条目 (可选)
   *   music:   string|object|Array  音乐音频描述 (可选)
   *   ambience:string|object|Array  环境音频描述 (可选)
   *   sfx:    string|object|Array    音效描述 (可选)
   *
   *   music/ambience/sfx 值可以是:
   *     string            路径或简写引用
   *     { url, volume, ... }   对象描述
   *     Array<string|object>   随机选取数组中的一个元素
   */

  function validatePack(packDef) {
    if (!packDef || typeof packDef !== 'object') return false;
    if (typeof packDef.name !== 'string' || packDef.name.length === 0) return false;
    if (!packDef.data || !(packDef.data instanceof Array)) return false;
    return true;
  }

  SM.audio.packs.load = function (packDef) {
    if (!validatePack(packDef)) {
      console.warn('[SM.audio.packs] 包定义无效:', packDef);
      return false;
    }

    // 覆盖已有同名包
    if (_packIndex.hasOwnProperty(packDef.name)) {
      var existing = _packIndex[packDef.name];
      var idx = _packs.indexOf(existing);
      if (idx !== -1) _packs.splice(idx, 1);
      delete _packIndex[packDef.name];
    }

    var pack = {
      name:        packDef.name,
      version:     packDef.version || '1.0.0',
      description: packDef.description || '',
      folder:      packDef.folder || '',
      source:      packDef.source || '',
      icon:        packDef.icon || '',
      enabled:     packDef.hasOwnProperty('enabled') ? !!packDef.enabled : true,
      shorthand:   packDef.shorthand || {},
      data:        packDef.data || []
    };

    _packs.push(pack);
    _packIndex[pack.name] = pack;
    return true;
  };

  SM.audio.packs.unload = function (name) {
    if (!_packIndex.hasOwnProperty(name)) return false;
    var pack = _packIndex[name];
    var idx = _packs.indexOf(pack);
    if (idx !== -1) _packs.splice(idx, 1);
    delete _packIndex[name];
    return true;
  };

  SM.audio.packs.enable = function (name, bool) {
    if (!_packIndex.hasOwnProperty(name)) return false;
    _packIndex[name].enabled = bool !== false;
    return true;
  };

  SM.audio.packs.list = function () {
    var result = [];
    for (var i = 0; i < _packs.length; i++) {
      var p = _packs[i];
      result.push({
        name:        p.name,
        version:     p.version,
        description: p.description,
        enabled:     p.enabled,
        count:       p.data ? p.data.length : 0
      });
    }
    return result;
  };

  // ==================================================================
  //  路径解析
  // ==================================================================

  /**
   * 将音频文件路径解析为可用的 URL
   *   - 已包含协议 (http/https) 的 URL 直通
   *   - 以 / 或 ./ 开头的绝对/相对路径直通
   *   - 其余路径相对于 pack folder (./audio/packs/{folder}/{path})
   *
   *  TODO: 支持 IDB (IndexedDB) 自定义音源查找
   *   流程: packFolder + path -> IDB hash 查找 -> 返回 blob URL
   */
  function resolvePath(path, packFolder) {
    if (typeof path !== 'string' || path.length === 0) return '';

    // URL (http/https/ftp 等)
    if (path.indexOf('://') !== -1) return path;

    // 以 / 或 ./ 开头的路径 (相对于游戏根目录)
    if (path.charAt(0) === '/' || path.substring(0, 2) === './') return path;

    // 相对 pack folder
    if (packFolder) {
      return './audio/packs/' + packFolder + '/' + path;
    }

    return path;
  }

  // ==================================================================
  //  简写解析
  // ==================================================================

  /**
   * 递归解析 # 开头的简写引用
   *  pack.shorthand 中定义简写到实际路径或对象的映射
   *  嵌套深度限制为 _MAX_SHORTHAND_DEPTH (20)
   */
  function resolveShorthand(value, pack) {
    var depth = 0;
    while (typeof value === 'string' && value.charAt(0) === '#') {
      if (depth >= _MAX_SHORTHAND_DEPTH) {
        console.warn('[SM.audio.packs] 简写嵌套超限:', value);
        return value;
      }
      var key = value.substring(1);
      if (pack.shorthand && pack.shorthand.hasOwnProperty(key)) {
        value = pack.shorthand[key];
      } else {
        console.warn('[SM.audio.packs] 未定义的简写:', value);
        return value;
      }
      depth++;
    }
    return value;
  }

  // ==================================================================
  //  公共求值 API
  // ==================================================================

  /**
   * 求值所有已启用包中的触发器条目
   *
   * 调用时机:
   *   - 由 :passageend 生命周期钩子自动调用
   *   - 也可手动调用 SM.audio.packs.evaluate()
   *
   * 执行流程:
   *   1. 记录上一轮活跃的音频 URL 用于清理
   *   2. 按加载顺序遍历所有启用包
   *   3. 对包 data 中每条条目调用 executeEntry
   *   4. 停止本轮未出现的旧音频
   */
  SM.audio.packs.evaluateTriggers = function () {
    if (!SM.audio.isEnabled()) return;

    // 保存上一轮活跃 URL, 重置本轮追踪
    _previousUrls = _activeUrls;
    _activeUrls = {};
    _musicStarted = false;

    // 遍历所有已启用的包
    for (var i = 0; i < _packs.length; i++) {
      var pack = _packs[i];
      if (!pack.enabled) continue;

      for (var j = 0; j < pack.data.length; j++) {
        executeEntry(pack.data[j], pack);
      }
    }

    // 停止本轮不再活跃的音频 (已切 passage 不需要旧的音景)
    for (var url in _previousUrls) {
      if (_previousUrls.hasOwnProperty(url) && !_activeUrls.hasOwnProperty(url)) {
        SM.audio.stop(url);
      }
    }
  };

  SM.audio.packs.evaluate = SM.audio.packs.evaluateTriggers;

  // ==================================================================
  //  条目执行器
  // ==================================================================

  /**
   * 执行一个触发器条目
   *
   * 处理流程:
   *   1. 简写解析 (string -> resolved value)
   *   2. 数组: 递归处理每个元素
   *   3. if 条件: 条件真时执行 do + playEntry, 条件假时执行 else
   *   4. 无条件: 执行 do (如有) + playEntry
   */
  function executeEntry(entry, pack) {
    // 简写解析 (递归)
    while (typeof entry === 'string') {
      var resolved = resolveShorthand(entry, pack);
      if (resolved === entry && typeof resolved !== 'string') {
        console.warn('[SM.audio.packs] 简写未找到:', entry);
        return;
      }
      entry = resolved;
    }

    // 数组: 依次处理每个元素
    if (entry instanceof Array) {
      for (var ai = 0; ai < entry.length; ai++) {
        executeEntry(entry[ai], pack);
      }
      return;
    }

    // 非对象, 跳过
    if (typeof entry !== 'object' || entry === null) return;

    // 条件求值
    var conditionMet = true;
    if (entry.hasOwnProperty('if')) {
      try {
        conditionMet = !!SM.audio.dsl.evaluateCondition(entry.if);
      } catch (e) {
        conditionMet = false;
      }
    }

    if (conditionMet) {
      if (entry.do) executeEntry(entry.do, pack);
      playEntry(entry, pack);
    } else {
      if (entry.else) executeEntry(entry.else, pack);
    }
  }

  // ==================================================================
  //  音频播放分发
  // ==================================================================

  /**
   * 将条目中的 music/ambience/sfx 分发给 SM.audio.play
   *
   * music 使用 _musicStarted 保证每轮求值仅播放一组音乐
   * (首个遇到的 music 条目胜出)
   * ambience 和 sfx 不受此限制
   */
  function playEntry(entry, pack) {
    if (entry.hasOwnProperty('music') && !_musicStarted) {
      dispatchSlots(entry.music, SM.audio.Type.MUSIC, pack);
      _musicStarted = true;
    }
    if (entry.hasOwnProperty('ambience')) {
      dispatchSlots(entry.ambience, SM.audio.Type.AMBIENCE, pack);
    }
    if (entry.hasOwnProperty('sfx')) {
      dispatchSlots(entry.sfx, SM.audio.Type.SFX, pack);
    }
  }

  function dispatchSlots(slots, type, pack) {
    if (slots instanceof Array) {
      for (var si = 0; si < slots.length; si++) {
        playSlot(slots[si], type, pack);
      }
    } else {
      playSlot(slots, type, pack);
    }
  }

  // ==================================================================
  //  单个音频槽播放
  // ==================================================================

  /**
   * 解析并播放一个音频槽
   *
   * slotDescriptor 可以是:
   *   string              -- 路径/简写 (经 resolvePath 转换)
   *   { url, volume, ... } -- 对象描述
   *   { yt, volume, ... }  -- YouTube video ID
   *
   * 支持的参数:
   *   volume, pitch, loop, loopstart, fadein, fadeout, fadepitch
   *   repeat, start, end, offset, delay
   *
   * 非 SFX 类型的 URL 会被记录到 _activeUrls
   * 用于跨 passage 的活跃音频追踪
   */
  function playSlot(slotDescriptor, type, pack) {
    // 解析简写
    slotDescriptor = resolveShorthand(slotDescriptor, pack);

    var url = '';
    var params = {};

    if (typeof slotDescriptor === 'string') {
      // 纯字符串路径
      url = resolvePath(slotDescriptor, pack.folder);
    } else if (slotDescriptor && typeof slotDescriptor === 'object') {
      // 对象描述: 获取 URL 或 YouTube ID
      if (slotDescriptor.url) {
        url = resolvePath(slotDescriptor.url, pack.folder);
      } else if (slotDescriptor.yt) {
        url = slotDescriptor.yt;
      } else {
        return; // 既无 url 也无 yt
      }

      // 提取参数 (只有明确设置的才传递)
      if (slotDescriptor.volume !== undefined)     params.volume    = Number(slotDescriptor.volume);
      if (slotDescriptor.pitch !== undefined)      params.pitch     = Number(slotDescriptor.pitch);
      if (slotDescriptor.loop !== undefined)       params.loop      = !!slotDescriptor.loop;
      if (slotDescriptor.loopstart !== undefined)  params.loopStart = Number(slotDescriptor.loopstart);
      if (slotDescriptor.fadein !== undefined)     params.fadeIn    = Number(slotDescriptor.fadein);
      if (slotDescriptor.fadeout !== undefined)    params.fadeOut   = Number(slotDescriptor.fadeout);
      if (slotDescriptor.fadepitch !== undefined)  params.fadePitch = Number(slotDescriptor.fadepitch);
      if (slotDescriptor.repeat !== undefined)     params.repeat    = Number(slotDescriptor.repeat);
      if (slotDescriptor.start !== undefined)      params.start     = Number(slotDescriptor.start);
      if (slotDescriptor.end !== undefined)        params.end       = Number(slotDescriptor.end);
      if (slotDescriptor.offset !== undefined)     params.offset    = Number(slotDescriptor.offset);
      if (slotDescriptor.delay !== undefined)      params.delay     = Number(slotDescriptor.delay);
    } else {
      return;
    }

    if (!url || url.length === 0) return;

    // 播放或更新已有音频
    // SM.audio.play 会自动处理:
    //   - 新 URL: 创建 HTMLAudioPlayer
    //   - 已有 URL: 取消 dirty 标记, 更新参数, 重做 fadeIn
    SM.audio.play(type, url, params);

    // 只有循环播放的音频需要跨 passage 追踪
    // SFX 是一次性音效, 播放完毕后自然消亡
    if (type !== SM.audio.Type.SFX) {
      _activeUrls[url] = true;
    }
  }

  // ==================================================================
  //  宏拦截
  // ==================================================================

  /**
   * 包装 SugarCube 宏处理器, 在原有处理前后追加回调
   *
   * 在 :storyready 事件中调用, 此时 SugarCube API 已完整可用
   */
  function addMacroCallback(name, callback) {
    try {
      var macro = SugarCube.Macro.get(name);
      if (!macro) return;
      var originalHandler = macro.handler;
      macro.handler = function () {
        callback(this);
        return originalHandler.apply(this, arguments);
      };
    } catch (e) {
      // SugarCube 尚未就绪
    }
  }

  /**
   * 安装宏拦截:
   *   <<set>>         -- 检测 $ejaculating 变为 1
   *   <<endcombat>>   -- 检测战斗结束
   *
   * 追踪结果存入内部变量, 可通过 getMacroState() 获取
   * 或由 DSL getProperty 扩展引用
   */
  function hookMacros() {
    addMacroCallback('set', function (that) {
      // 检测 <<set $ejaculating to 1>>
      if (that.args && that.args.raw === '$ejaculating to 1') {
        _isEnemyEjaculating = true;
      }
    });
    addMacroCallback('endcombat', function () {
      _isCombatEnd = true;
    });
  }

  // ==================================================================
  //  宏状态查询
  // ==================================================================

  SM.audio.packs.getMacroState = function () {
    return {
      isEnemyEjaculating: _isEnemyEjaculating,
      isCombatEnd: _isCombatEnd,
      lastAction: _lastAction,
      lastPassage: _lastPassage
    };
  };

  // ==================================================================
  //  生命周期钩子
  // ==================================================================

  /**
   * :storyready     -- SugarCube 就绪, 安装宏拦截
   * :passageinit    -- passage 初始化, 重置宏追踪标志
   * :passagedisplay -- passage 渲染完毕, 捕获用户操作
   * :passageend     -- passage 结束, 求值所有包的触发器
   */
  $(document).on(':storyready', function () {
    hookMacros();
  });

  $(document).on(':passageinit', function () {
    _lastPassage = State.variables.passage;
    _isEnemyEjaculating = false;
    _isCombatEnd = false;
  });

  $(document).on(':passagedisplay', function () {
    // 捕获用户点击的选项文本作为 lastAction
    $('.macro-link').on('mousedown', function (data) {
      var value = data.target.innerText;
      if (value.indexOf(')') !== -1) {
        _lastAction = value.split(')').slice(1).join(')').trim();
      } else {
        _lastAction = value.trim();
      }
    });
  });

  $(document).on(':passageend', function () {
    SM.audio.packs.evaluateTriggers();
  });

  // ==================================================================
  //  初始化 + 模块注册
  // ==================================================================

  function init() {
    // 宏拦截和生命周期钩子已经绑定
    // 此处无需额外初始化
  }

  if (typeof SM.modules === 'object' && typeof SM.modules.register === 'function') {
    SM.modules.register('audio-packs', function () {
      init();
      return SM.audio.packs;
    }, { deps: ['audio-core', 'audio-dsl'], phase: 'preInit' });
  }

  init();
})();
